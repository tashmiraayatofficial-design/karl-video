# HANDOFF - Karl Bushby explainer (Remotion)

## 1. Video
- Subject: Karl Bushby's 28-year walk from Punta Arenas (Chile) to Hull (England). Explainer, English on-screen text.
- Duration: 126.668 s = 3801 frames @ 30 fps (voiceover length; SRT ends at 126.48 s).
- Audio: `public/voiceover.mp3` (ElevenLabs "Titan"), SRT `public/subtitles.srt`, user SFX in `public/sfx/`.

## 2. User-selected look
- Style: "Satellite Map Journey" rendered as a realistic 3D daylight globe (NASA Blue Marble, WebGL shader) with
  yellow route line, green danger zone + skull, red position dot, blue label boxes (reference videos supplied by user).
- Colour scheme "Natural Earth Day": bg `#0E2A47`, deep bg `#061423`, hero `#FFD60A`, accent `#3DDC84`, text `#FFFFFF`,
  chip blue `#1A56DB`, danger `#E63946`, ice `#BFE6FF`, swim `#4FD1FF` (all in `src/theme.ts`).
  User rejected "Expedition Night"; wanted a realistic DAYTIME satellite view.
- Aspect ratio: 9:16 (1080x1920). FPS: 30. (Ratio/scheme were proposed as defaults and never contradicted by the user.)
- Fonts: Comix Loud (user file, `public/fonts/ComixLoud.ttf`) for hero text - it is UPPERCASE-ONLY, no lowercase,
  no arrows/bullets. Body text = system sans stack (works offline).

## 3. Scenes (all 20 written and checked as still frames; no MP4 rendered yet)
hook, who, depart, rules, southAmerica, darien, hazards, prison, north, bering, ice, asia, usa, caspian, europe,
channel, arrival, total, ring, recap  (`src/timing.ts` -> `SC`, scene files in `src/scenes/`).
Globe camera path: `src/globe/camera.ts`. Route legs, markers, danger polygon: `src/globe/route.ts`.
SFX events: `src/components/Sfx.tsx`.

## 4. Assumptions / uncertainties
- Route line is ILLUSTRATIVE (joins places named in the script); Darien polygon is coarse; some inferred vertices
  (e.g. China -> Kazakhstan -> Caspian east shore) are not stated in the script.
- Earth texture `public/earth_day.jpg` (8000x4000) was recoloured from the user's NASA Blue Marble (ocean -> daylight blue).
  Deep zooms (Channel, Hull) are soft because 1 texture px ~ 5 km.
- Captions/subtitles are OFF (user decision: no subtitles; the user adds them in CapCut). Code kept behind `captions` flag, default false.
- Photo `public/karl.jpg` is assumed to be Karl Bushby (user-supplied).
- Timing comes only from the SRT cues; chips appear 4 frames before the spoken cue. "[sigh]" tags are removed.
- Final credit shown: "Imagery: NASA Earth Observatory (Blue Marble)".
- Sandbox had NO internet: Remotion was never executed here. Stills were produced with a small shim of the
  `remotion` API (`harness/`) so spring/easing physics differ very slightly from real Remotion.
  Versions pinned in package.json: remotion + @remotion/cli 4.0.504 (run `npx remotion upgrade` if needed).
- Globe uses WebGL2. If the globe is black while rendering, set `Config.setChromiumOpenGlRenderer('swangle')`
  in `remotion.config.ts` (or add `--gl=swangle`).

## 5. Render
- Preview: `npx remotion studio` (voiceover plays in Studio only).
- Render: `npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17`
- Voiceover is OFF by default while rendering. To burn it in: add `--props='{"voiceover":true}'`.
- Draft: add `--scale=0.5`.  Reduce RAM: `--concurrency=2` (each tab holds the 8000x4000 texture).

## 6. Next step
Run the render (or "Render it" in a chat that has internet + Remotion). Then apply any scene changes the user asks for.
Optional stills in a sandbox: `harness/run.sh <frame...>` (needs esbuild, playwright, local http server).
