import {Config} from '@remotion/cli/config';

// The globe is drawn with WebGL. "angle" works on most Windows/macOS machines.
// If the render shows a black/empty globe, switch to 'swangle' (software GL).
Config.setChromiumOpenGlRenderer('angle');
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(95);
Config.setOverwriteOutput(true);
