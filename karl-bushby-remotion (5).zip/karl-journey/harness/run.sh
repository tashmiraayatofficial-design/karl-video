#!/bin/bash
# usage: harness/run.sh <frame> [frame...]   (rebuilds bundle, serves, screenshots)
cd /home/claude/karl && ./harness/build.sh || exit 1
python3 -m http.server 8765 >/dev/null 2>&1 &
SP=$!
sleep 1
export NODE_PATH=/opt/npm-tools/node_modules PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers
timeout 280 node harness/shot.js "$@"
kill $SP 2>/dev/null
