#!/bin/bash
cd /home/claude/karl
export NODE_PATH=/opt/npm-tools/node_modules
/opt/npm-tools/node_modules/.bin/esbuild harness/entry.tsx --bundle --outfile=harness/bundle.js --alias:remotion=./harness/shim.tsx --jsx=automatic --loader:.ts=ts --loader:.tsx=tsx --define:process.env.NODE_ENV='"production"' --log-level=warning
