// Minimal stand-in for the `remotion` package, ONLY for offline still previews in this sandbox.
import React from 'react';

const g = window as any;
g.__pending = 0;
const FrameCtx = React.createContext<number | null>(null);
export const useCurrentFrame = (): number => {
  const c = React.useContext(FrameCtx);
  return c === null ? g.__FRAME : c;
};
export const useVideoConfig = () => ({fps: 30, width: 1080, height: 1920, durationInFrames: 3801, id: 'Main'});
export const Sequence: React.FC<any> = ({from = 0, durationInFrames = Infinity, children}) => {
  const f = useCurrentFrame();
  if (f < from || f >= from + durationInFrames) return null;
  return (
    <FrameCtx.Provider value={f - from}>
      <div style={{position: 'absolute', inset: 0}}>{children}</div>
    </FrameCtx.Provider>
  );
};
export const AbsoluteFill: React.FC<any> = ({children, style}) => (
  <div style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, width: '100%', height: '100%', display: 'flex', flexDirection: 'column', ...style}}>{children}</div>
);
export const Img: React.FC<any> = (p) => <img {...p} />;
export const Audio: React.FC<any> = () => null;
export const staticFile = (p: string) => '/public/' + p;
export const delayRender = (_l?: string) => {
  g.__pending++;
  return g.__pending + Math.random();
};
export const continueRender = (_h: any) => {
  g.__pending--;
};
export const getRemotionEnvironment = () => ({isRendering: false, isStudio: false, isPlayer: false});
export const random = (seed: string | number) => {
  let h = 1779033703 ^ String(seed).length;
  const s = String(seed);
  for (let i = 0; i < s.length; i++) {
    h = Math.imul(h ^ s.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  h = Math.imul(h ^ (h >>> 16), 2246822507) ^ Math.imul(h ^ (h >>> 13), 3266489909);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};

type Ease = (t: number) => number;
const bez = (x1: number, y1: number, x2: number, y2: number): Ease => (x) => {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  let lo = 0, hi = 1, t = x;
  for (let i = 0; i < 40; i++) {
    const cx = 3 * (1 - t) * (1 - t) * t * x1 + 3 * (1 - t) * t * t * x2 + t * t * t;
    if (cx < x) lo = t; else hi = t;
    t = (lo + hi) / 2;
  }
  return 3 * (1 - t) * (1 - t) * t * y1 + 3 * (1 - t) * t * t * y2 + t * t * t;
};
export const Easing = {
  bezier: bez,
  linear: (t: number) => t,
  cubic: (t: number) => t * t * t,
  quad: (t: number) => t * t,
  out: (e: Ease): Ease => (t) => 1 - e(1 - t),
  in: (e: Ease): Ease => e,
  inOut: (e: Ease): Ease => (t) => (t < 0.5 ? e(t * 2) / 2 : 1 - e((1 - t) * 2) / 2),
};
export function interpolate(input: number, inR: number[], outR: number[], o: any = {}): number {
  const eL = o.extrapolateLeft ?? 'extend', eR = o.extrapolateRight ?? 'extend';
  let i = 0;
  while (i < inR.length - 2 && input > inR[i + 1]) i++;
  const a = inR[i], b = inR[i + 1];
  let u = (input - a) / (b - a);
  if (input < inR[0]) { if (eL === 'clamp') u = 0; }
  if (input > inR[inR.length - 1]) { if (eR === 'clamp') u = 1; }
  if (u > 0 && u < 1 && o.easing) u = o.easing(u);
  return outR[i] + (outR[i + 1] - outR[i]) * u;
}
export function spring({frame, fps, config = {}, from = 0, to = 1, delay = 0}: any): number {
  const {damping = 10, mass = 1, stiffness = 100} = config;
  const t = Math.max(0, frame - delay) / fps;
  const w0 = Math.sqrt(stiffness / mass), z = damping / (2 * Math.sqrt(stiffness * mass));
  let v: number;
  if (z < 1) {
    const wd = w0 * Math.sqrt(1 - z * z);
    v = 1 - Math.exp(-z * w0 * t) * (Math.cos(wd * t) + ((z * w0) / wd) * Math.sin(wd * t));
  } else v = 1 - Math.exp(-w0 * t) * (1 + w0 * t);
  return from + (to - from) * v;
}
export const Composition: React.FC<any> = () => null;
export const registerRoot = () => {};
