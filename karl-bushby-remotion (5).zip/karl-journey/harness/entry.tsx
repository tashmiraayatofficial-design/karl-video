import React from 'react';
import {flushSync} from 'react-dom';
import {createRoot} from 'react-dom/client';
import {Main} from '../src/Main';

const g = window as any;
const f = Number(new URLSearchParams(location.search).get('f') ?? 0);
g.__FRAME = f;
const el = document.getElementById('root')!;
const root = createRoot(el);
flushSync(() => root.render(<div style={{position: 'relative', width: 1080, height: 1920, overflow: 'hidden'}}><Main captions /></div>));
const wait = () => {
  if (g.__pending > 0) return setTimeout(wait, 50);
  requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(() => (g.__READY = true), 150)));
};
setTimeout(wait, 100);
