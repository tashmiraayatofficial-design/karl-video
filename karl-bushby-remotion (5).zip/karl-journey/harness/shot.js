const {chromium} = require('playwright');
(async () => {
  const frames = process.argv.slice(2).map(Number);
  const browser = await chromium.launch({args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl']});
  const page = await browser.newPage({viewport: {width: 1080, height: 1920}});
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) console.log('[page]', m.text()); });
  page.on('pageerror', (e) => console.log('[pageerror]', e.message));
  for (const f of frames) {
    await page.goto(`http://localhost:8765/harness/index.html?f=${f}`);
    await page.waitForFunction('window.__READY === true', null, {timeout: 60000}).catch(() => console.log('timeout at', f));
    await page.screenshot({path: `/home/claude/work/still_${f}.png`});
    console.log('shot', f);
  }
  await browser.close();
})();
