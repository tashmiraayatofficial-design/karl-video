import {Config} from '@remotion/cli/config';

// The globe is drawn with WebGL. GitHub runners have no GPU, so use software GL (swangle).
Config.setChromiumOpenGlRenderer('swangle');
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(90);
Config.setCrf(28);
Config.setOverwriteOutput(true);
