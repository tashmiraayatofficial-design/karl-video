import React from 'react';
import {Alert, Clock, Coin, Doc, Gate, Passport} from '../components/Icons';
import {Chip, Count, Hero, Hl, Reveal, Scene, Scrim, withCommas} from '../components/ui';
import {useAbs} from '../hooks';
import {rgba, theme} from '../theme';
import {SC, sec} from '../timing';

/** 13 - Los Angeles to Washington, D.C. */
export const SceneUsa: React.FC = () => (
  <Scene range={SC.usa}>
    <Reveal at={73.28} until={75.1} y={290}>
      <Chip variant="glass" size={52}>EXTRAORDINARY ATTEMPT</Chip>
    </Reveal>
    <Reveal at={75.18} y={290}>
      <Chip variant="danger" size={52} icon={<Passport size={60} />}>RUSSIAN VISA RESTRICTIONS</Chip>
    </Reveal>
    <Reveal at={78.2} y={420} spr="snap">
      <Hero size={170}>
        <Count to={5600} a={78.25} b={79.9} format={withCommas} />
      </Hero>
    </Reveal>
    <Reveal at={79.2} y={690}>
      <Chip variant="blue" size={56}>KILOMETERS WALKED</Chip>
    </Reveal>
  </Scene>
);

/** 14 - Caspian Sea */
export const SceneCaspian: React.FC = () => (
  <Scene range={SC.caspian}>
    <Reveal at={83.22} y={280} spr="snap">
      <Chip variant="blue" size={80}>
        <Hl>2024</Hl>
      </Chip>
    </Reveal>
    <Reveal at={85.14} until={87.0} y={410}>
      <Chip variant="danger" size={50} icon={<Alert size={58} />}>LAND ROUTES TO EUROPE BLOCKED</Chip>
    </Reveal>
    <Reveal at={87.1} y={410} spr="snap">
      <Chip variant="hero" size={50}>SWAM ACROSS THE CASPIAN SEA</Chip>
    </Reveal>
  </Scene>
);

/** 15 - Turkey, Bosphorus, Europe */
export const SceneEurope: React.FC = () => (
  <Scene range={SC.europe}>
    <Reveal at={90.94} y={280}>
      <Chip variant="glass" size={58}>TURKEY → EUROPE</Chip>
    </Reveal>
  </Scene>
);

/** 16 - English Channel */
export const SceneChannel: React.FC = () => (
  <Scene range={SC.channel}>
    <Reveal at={95.54} y={280} spr="snap">
      <Chip variant="blue" size={72}>
        OCT 5, <Hl>2026</Hl>
      </Chip>
    </Reveal>
    <Reveal at={99.34} y={410} spr="snap">
      <Chip variant="hero" size={58}>THE ENGLISH CHANNEL</Chip>
    </Reveal>
    <Reveal at={100.18} y={540}>
      <Chip variant="glass" size={52}>FRANCE → ENGLAND</Chip>
    </Reveal>
  </Scene>
);

/** 17 - Arrival in Hull */
export const SceneArrival: React.FC = () => (
  <Scene range={SC.arrival}>
    <Reveal at={102.18} until={108.8} y={270} spr="snap">
      <Chip variant="blue" size={72}>
        NOV 2, <Hl>2026</Hl>
      </Chip>
    </Reveal>
    <Reveal at={104.06} until={108.8} y={400} spr="snap">
      <Hero size={100}>
        <Count to={28} a={104.1} b={105.2} /> YEARS
      </Hero>
    </Reveal>
    <Reveal at={105.88} until={108.8} y={560}>
      <Chip variant="hero" size={62}>+ 1 DAY</Chip>
    </Reveal>
    <Reveal at={107.0} until={108.8} y={690}>
      <Chip variant="glass" size={50}>AFTER LEAVING CHILE</Chip>
    </Reveal>
  </Scene>
);

/** 18 - 50,000 km */
export const SceneTotal: React.FC = () => (
  <Scene range={SC.total}>
    <Reveal at={112.24} y={290}>
      <Chip variant="glass" size={52}>APPROXIMATELY</Chip>
    </Reveal>
    <Reveal at={112.4} y={380} spr="snap">
      <Hero size={140}>
        <Count to={50000} a={112.45} b={113.9} format={withCommas} />
      </Hero>
    </Reveal>
    <Reveal at={113.16} y={640} spr="snap">
      <Hero size={84} color={theme.colors.text}>KILOMETERS</Hero>
    </Reveal>
  </Scene>
);

/** Ring chart: 15 of 28 segments are "walking" years. */
const Ring: React.FC = () => {
  const f = useAbs();
  const n = 28;
  const R = 300;
  const start = sec(117.7);
  const end = sec(119.2);
  const lit = Math.max(0, Math.min(15, ((f - start) / (end - start)) * 15));
  return (
    <svg width={760} height={760} viewBox="-380 -380 760 760">
      {Array.from({length: n}, (_, i) => {
        const a = (i / n) * Math.PI * 2 - Math.PI / 2;
        const a2 = ((i + 0.82) / n) * Math.PI * 2 - Math.PI / 2;
        const on = i < lit;
        const r1 = R - 34;
        const r2 = R + 34;
        const d = `M${r1 * Math.cos(a)} ${r1 * Math.sin(a)} L${r2 * Math.cos(a)} ${r2 * Math.sin(a)} L${r2 * Math.cos(a2)} ${r2 * Math.sin(a2)} L${r1 * Math.cos(a2)} ${r1 * Math.sin(a2)}Z`;
        return <path key={i} d={d} fill={on ? theme.colors.hero : rgba(theme.colors.text, 0.22)} stroke={on ? theme.colors.ink : 'none'} strokeWidth={2} />;
      })}
    </svg>
  );
};

/** 19 - 15 of 28 years */
export const SceneRing: React.FC = () => (
  <Scene range={SC.ring}>
    <Scrim from={114.9} to={122.16} amount={0.55} />
    <Reveal at={114.9} y={260}>
      <Chip variant="glass" size={52}>THE MOST ASTONISHING FACT</Chip>
    </Reveal>
    <Reveal at={116.24} y={560} spr="soft">
      <div style={{position: 'relative', width: 760, height: 760}}>
        <Ring />
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26}}>
          <Hero size={180}>
            <Count to={15} a={117.7} b={119.2} />
          </Hero>
          <Hero size={52} color={theme.colors.text}>OF 28 YEARS</Hero>
        </div>
      </div>
    </Reveal>
    <Reveal at={120.52} y={1370} spr="snap">
      <Chip variant="green" size={60}>ACTUALLY WALKING</Chip>
    </Reveal>
  </Scene>
);

const Tile: React.FC<{icon: React.ReactNode; label: string}> = ({icon, label}) => (
  <div
    style={{
      width: 470,
      height: 360,
      boxSizing: 'border-box',
      borderRadius: 38,
      background: rgba(theme.colors.bgDeep, 0.72),
      border: `3px solid ${rgba(theme.colors.text, 0.26)}`,
      boxShadow: `0 20px 50px ${rgba(theme.colors.ink, 0.45)}`,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 26,
    }}
  >
    {icon}
    <div style={{fontFamily: theme.fonts.body, fontWeight: 800, fontSize: 46, color: theme.colors.text, textTransform: 'uppercase'}}>{label}</div>
  </div>
);

/** 20 - Recap grid + credit */
export const SceneRecap: React.FC = () => (
  <Scene range={SC.recap} fade={false}>
    <Scrim from={122.16} to={130} amount={0.62} />
    <Reveal at={122.16} y={260}>
      <Chip variant="glass" size={46}>THE REST WAS A BATTLE AGAINST</Chip>
    </Reveal>
    <Reveal at={123.3} x={55} y={380} spr="snap"><Tile icon={<Gate size={170} />} label="BORDERS" /></Reveal>
    <Reveal at={124.38} x={555} y={380} spr="snap"><Tile icon={<Doc size={170} />} label="BUREAUCRACY" /></Reveal>
    <Reveal at={125.2} x={55} y={780} spr="snap"><Tile icon={<Coin size={170} />} label="MONEY" /></Reveal>
    <Reveal at={125.9} x={555} y={780} spr="snap"><Tile icon={<Clock size={170} />} label="TIME" /></Reveal>
    <Reveal at={124.6} y={1700} dir="none" float={false}>
      <div style={{fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 28, letterSpacing: 1, color: theme.colors.muted}}>IMAGERY: NASA EARTH OBSERVATORY (BLUE MARBLE)</div>
    </Reveal>
  </Scene>
);
