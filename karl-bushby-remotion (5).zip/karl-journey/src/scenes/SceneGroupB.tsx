import React from 'react';
import {Alert, Check, Coin, Gate, Passport, River, Snow, Swamp, Tree} from '../components/Icons';
import {Chip, Count, Hero, Hl, Reveal, Scene, Scrim} from '../components/ui';
import {useT} from '../hooks';
import {rgba, theme} from '../theme';
import {SC} from '../timing';
import {Bars, Row} from './common';

/** 7 - Hazards: three icon rows revealed on the spoken words */
export const SceneHazards: React.FC = () => (
  <Scene range={SC.hazards}>
    <Scrim from={36.46} to={41.4} amount={0.35} />
    <Reveal at={36.46} until={40.9} y={270}>
      <Chip variant="glass" size={56}>AFTER BATTLING</Chip>
    </Reveal>
    <Row at={37.24} y={400} dir="left" icon={<Tree size={128} />} title="DENSE FORESTS" />
    <Row at={38.34} y={640} dir="right" icon={<Swamp size={128} />} title="SWAMPS" />
    <Row at={39.14} y={880} dir="left" icon={<River size={128} />} title="DANGEROUS RIVERS" />
    <Reveal at={40.42} y={1140} spr="snap">
      <Chip variant="hero" size={64} icon={<Check size={58} color={theme.colors.ink} />}>REACHED PANAMA</Chip>
    </Reveal>
  </Scene>
);

/** 8 - Prison: bars + counter */
export const ScenePrison: React.FC = () => (
  <Scene range={SC.prison}>
    <Scrim from={41.4} to={44.68} amount={0.55} />
    <Bars at={41.3} />
    <Reveal at={41.76} y={300} spr="snap">
      <Chip variant="danger" size={86}>IMPRISONED</Chip>
    </Reveal>
    <Reveal at={41.9} y={470} spr="snap">
      <Hero size={330}>
        <Count to={18} a={42.2} b={43.1} />
      </Hero>
    </Reveal>
    <Reveal at={43.18} y={930} spr="snap">
      <Hero size={140} color={theme.colors.text}>DAYS</Hero>
    </Reveal>
  </Scene>
);

const COUNTRIES: [string, number][] = [
  ['CENTRAL AMERICA', 45.0],
  ['MEXICO', 46.0],
  ['UNITED STATES', 46.82],
  ['CANADA', 47.9],
  ['ALASKA', 49.76],
];

/** 9 - Panama to Alaska: country checklist builds as each country is named */
export const SceneNorth: React.FC = () => (
  <Scene range={SC.north}>
    {COUNTRIES.map(([name, at], i) => (
      <Reveal key={name} at={at} y={280 + i * 104} dir="left" spr="snap">
        <Chip variant={i === COUNTRIES.length - 1 ? 'hero' : 'glass'} size={50} icon={<Check size={46} color={i === COUNTRIES.length - 1 ? theme.colors.ink : theme.colors.accent} />}>
          {name}
        </Chip>
      </Reveal>
    ))}
  </Scene>
);

/** 10 - Bering Strait */
export const SceneBering: React.FC = () => (
  <Scene range={SC.bering}>
    <Reveal at={51.4} y={270} spr="snap">
      <Chip variant="blue" size={72}>
        MARCH <Hl>2006</Hl>
      </Chip>
    </Reveal>
    <Reveal at={53.04} y={400}>
      <Chip variant="glass" size={50}>WITH DIMITRI KIEFER</Chip>
    </Reveal>
    <Reveal at={55.14} y={1190} spr="snap">
      <Chip variant="hero" size={58}>THE FROZEN BERING STRAIT</Chip>
    </Reveal>
  </Scene>
);

const Chill: React.FC<{a: number}> = ({a}) => {
  const t = useT();
  const o = Math.min(1, Math.max(0, (t - a) / 1.2));
  return <div style={{position: 'absolute', inset: 0, background: rgba(theme.colors.ice, 0.13 * o), mixBlendMode: 'screen'}} />;
};

/** 11 - 14 days: big counter + ice facts */
export const SceneIce: React.FC = () => (
  <Scene range={SC.ice}>
    <Chill a={58.18} />
    <Reveal at={58.18} y={250}>
      <Chip variant="danger" size={58} icon={<Alert size={62} />}>DANGEROUS CROSSING</Chip>
    </Reveal>
    <Reveal at={59.5} y={380} spr="snap">
      <Hero size={330}>
        <Count to={14} a={59.5} b={60.2} />
      </Hero>
    </Reveal>
    <Reveal at={60.32} y={830} spr="snap">
      <Hero size={130} color={theme.colors.text}>DAYS</Hero>
    </Reveal>
    <Reveal at={61.16} y={1050}>
      <Chip variant="glass" size={54} icon={<Snow size={64} />}>SHIFTING SEA ICE</Chip>
    </Reveal>
    <Reveal at={62.14} y={1170}>
      <Chip variant="glass" size={54} icon={<Snow size={64} color={theme.colors.swim} />}>FREEZING OCEAN WATER</Chip>
    </Reveal>
  </Scene>
);

/** 12 - Russia, Mongolia, China + obstacles + STOPPED stamp */
export const SceneAsia: React.FC = () => (
  <Scene range={SC.asia}>
    <Reveal at={64.82} y={290}>
      <Chip variant="blue" size={50}>RUSSIA → MONGOLIA → CHINA</Chip>
    </Reveal>
    <Reveal at={68.04} y={430} dir="left" spr="snap">
      <Chip variant="danger" size={54} icon={<Passport size={62} />}>VISA RESTRICTIONS</Chip>
    </Reveal>
    <Reveal at={68.94} y={550} dir="right" spr="snap">
      <Chip variant="danger" size={54} icon={<Gate size={62} />}>BORDER PROBLEMS</Chip>
    </Reveal>
    <Reveal at={70.04} y={670} dir="left" spr="snap">
      <Chip variant="danger" size={54} icon={<Coin size={62} />}>FINANCIAL DIFFICULTIES</Chip>
    </Reveal>
    <Reveal at={71.4} y={900} spr="snap" float={false}>
      <div style={{transform: 'rotate(-7deg)', border: `10px solid ${theme.colors.danger}`, borderRadius: 18, padding: '10px 36px', background: rgba(theme.colors.bgDeep, 0.6)}}>
        <Hero size={84} color={theme.colors.danger}>STOPPED</Hero>
      </div>
    </Reveal>
  </Scene>
);
