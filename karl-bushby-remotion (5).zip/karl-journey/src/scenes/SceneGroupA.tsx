import React from 'react';
import {Cart, Alert, NoCar, NoHome, Walker, Coin} from '../components/Icons';
import {Chip, Hero, Hl, Reveal, Scene, Scrim} from '../components/ui';
import {useT} from '../hooks';
import {rgba, theme} from '../theme';
import {SC} from '../timing';
import {PhotoCard, Row} from './common';

/** 1 - Hook: kinetic typography */
export const SceneHook: React.FC = () => (
  <Scene range={SC.hook}>
    <Reveal at={0.1} until={1.1} y={330}>
      <Chip variant="glass" size={66}>IMAGINE SPENDING</Chip>
    </Reveal>
    <Reveal at={1.26} until={4.25} y={240} spr="snap">
      <div>
        <Hero size={200}>28</Hero>
        <Hero size={92} color={theme.colors.text}>YEARS</Hero>
      </div>
    </Reveal>
    <Reveal at={2.52} y={1330}>
      <Chip variant="blue" size={62}>
        TRYING TO <Hl>WALK HOME</Hl>
      </Chip>
    </Reveal>
  </Scene>
);

/** 2 - Who: portrait card */
export const SceneWho: React.FC = () => (
  <Scene range={SC.who}>
    <Scrim from={4.36} to={7.78} amount={0.5} />
    <Reveal at={4.36} until={7.6} y={290}>
      <PhotoCard a={4.36} b={7.78} />
    </Reveal>
    <Reveal at={4.6} y={930} spr="snap">
      <Hero size={92}>KARL BUSHBY</Hero>
    </Reveal>
    <Reveal at={5.84} y={1090}>
      <Chip variant="blue" size={52}>FORMER BRITISH PARATROOPER</Chip>
    </Reveal>
  </Scene>
);

/** 3 - Departure: date, start pin, cart, money, destination */
export const SceneDepart: React.FC = () => (
  <Scene range={SC.depart}>
    <Reveal at={7.78} until={18.5} y={270}>
      <Chip variant="blue" size={72}>
        NOV 1, <Hl>1998</Hl>
      </Chip>
    </Reveal>
    <Reveal at={12.28} until={15.2} y={400}>
      <Chip variant="glass" size={52} icon={<Cart size={62} />}>EXPEDITION CART</Chip>
    </Reveal>
    <Reveal at={13.36} until={15.2} y={520}>
      <Chip variant="glass" size={52} icon={<Coin size={60} />}>A FEW HUNDRED DOLLARS</Chip>
    </Reveal>
    <Reveal at={15.32} until={18.5} y={400}>
      <Chip variant="hero" size={58}>DESTINATION: MOTHER'S HOME</Chip>
    </Reveal>
  </Scene>
);

/** 4 - Rules: two glass cards (checklist) */
export const SceneRules: React.FC = () => (
  <Scene range={SC.rules}>
    <Scrim from={18.68} to={25.66} amount={0.5} />
    <Reveal at={18.68} y={270} spr="snap">
      <Hero size={124}>TWO RULES</Hero>
    </Reveal>
    <Row at={19.72} y={540} dir="left" badge="1" h={250} icon={<NoCar size={150} />} title="NO TRANSPORTATION" sub="TO ADVANCE HIS JOURNEY" />
    <Row at={22.42} y={850} dir="right" badge="2" h={250} icon={<NoHome size={150} />} title="NO RETURNING HOME" />
    <Reveal at={24.06} y={1170}>
      <Chip variant="green" size={58} icon={<Walker size={64} color={theme.colors.ink} />}>UNTIL HE ARRIVES ON FOOT</Chip>
    </Reveal>
  </Scene>
);

/** 5 - South America to Colombia */
export const SceneSouthAmerica: React.FC = () => (
  <Scene range={SC.southAmerica}>
    <Reveal at={25.66} until={26.35} y={290}>
      <Chip variant="glass" size={58}>FIRST</Chip>
    </Reveal>
    <Reveal at={26.72} until={27.9} y={290}>
      <Chip variant="blue" size={72}>SOUTH AMERICA</Chip>
    </Reveal>
    <Reveal at={27.96} y={290}>
      <Chip variant="blue" size={72}>
        <Hl>COLOMBIA</Hl>
      </Chip>
    </Reveal>
  </Scene>
);

const Alarm: React.FC<{a: number; b: number}> = ({a, b}) => {
  const t = useT();
  if (t < a || t > b) return null;
  const k = 0.5 + 0.5 * Math.sin((t - a) * 7);
  return <div style={{position: 'absolute', inset: 0, boxShadow: `inset 0 0 220px ${rgba(theme.colors.danger, 0.15 + 0.3 * k)}`}} />;
};

/** 6 - Darien Gap: danger zone */
export const SceneDarien: React.FC = () => (
  <Scene range={SC.darien}>
    <Alarm a={30.3} b={36.2} />
    <Reveal at={30.1} until={33.2} y={270}>
      <Chip variant="blue" size={80}>
        IN <Hl>2001</Hl>
      </Chip>
    </Reveal>
    <Reveal at={30.6} y={410} spr="snap">
      <Chip variant="danger" size={84}>DARIEN GAP</Chip>
    </Reveal>
    <Reveal at={31.88} y={560}>
      <Chip variant="glass" size={54} icon={<Alert size={60} />}>DANGEROUS JUNGLE</Chip>
    </Reveal>
  </Scene>
);
