import React from 'react';
import {Img, spring, staticFile, useVideoConfig} from 'remotion';
import {useAbs, useT} from '../hooks';
import {GlassCard, Reveal} from '../components/ui';
import {rgba, theme} from '../theme';
import {sec} from '../timing';

/** Glass card with an icon on the left and text on the right. */
export const IconRow: React.FC<{icon: React.ReactNode; title: string; sub?: string; h?: number; badge?: string}> = ({icon, title, sub, h = 200, badge}) => (
  <GlassCard h={h}>
    {badge && (
      <div style={{width: 96, height: 96, minWidth: 96, flex: 'none', boxSizing: 'border-box', borderRadius: '50%', background: theme.colors.hero, color: theme.colors.ink, fontFamily: theme.fonts.display, fontSize: 64, lineHeight: '100px', textAlign: 'center'}}>
        {badge}
      </div>
    )}
    <div style={{flex: 'none'}}>{icon}</div>
    <div style={{fontFamily: theme.fonts.body, fontWeight: 800, fontSize: 56, lineHeight: 1.05, color: theme.colors.text, textTransform: 'uppercase'}}>
      {title}
      {sub && <div style={{fontSize: 38, fontWeight: 700, color: theme.colors.muted, marginTop: 8}}>{sub}</div>}
    </div>
  </GlassCard>
);

/** Photo card with slow Ken Burns zoom. */
export const PhotoCard: React.FC<{a: number; b: number}> = ({a, b}) => {
  const t = useT();
  const k = Math.min(1, Math.max(0, (t - a) / (b - a)));
  return (
    <div style={{width: 860, height: 600, borderRadius: 40, overflow: 'hidden', border: `8px solid ${theme.colors.text}`, boxShadow: `0 30px 70px ${rgba(theme.colors.ink, 0.6)}`, position: 'relative'}}>
      <Img src={staticFile('karl.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: '50% 22%', transform: `scale(${1.02 + 0.1 * k})`}} />
      <div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg, transparent 60%, ${rgba(theme.colors.ink, 0.5)})`}} />
    </div>
  );
};

/** Prison bars that slam down (rows of vertical bars). */
export const Bars: React.FC<{at: number}> = ({at}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const n = 8;
  return (
    <div style={{position: 'absolute', inset: 0, overflow: 'hidden'}}>
      {Array.from({length: n}, (_, i) => {
        const p = spring({frame: f - (sec(at) - 4) - i * 2, fps, config: theme.spring.snap});
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: 70 + i * 134,
              top: 0,
              width: 28,
              height: 1920,
              borderRadius: 14,
              background: `linear-gradient(90deg, ${rgba(theme.colors.ink, 0.95)}, ${rgba(theme.colors.muted, 0.55)} 45%, ${rgba(theme.colors.ink, 0.95)})`,
              transform: `translateY(${(1 - Math.min(1, p)) * -1920}px)`,
            }}
          />
        );
      })}
    </div>
  );
};

export const Row: React.FC<{at: number; until?: number; y: number; icon: React.ReactNode; title: string; sub?: string; dir?: 'left' | 'right' | 'up'; badge?: string; h?: number}> = ({at, until, y, icon, title, sub, dir = 'up', badge, h}) => (
  <Reveal at={at} until={until} y={y} dir={dir}>
    <IconRow icon={icon} title={title} sub={sub} badge={badge} h={h} />
  </Reveal>
);
