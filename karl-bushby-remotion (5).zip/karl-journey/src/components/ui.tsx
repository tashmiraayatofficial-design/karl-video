import React from 'react';
import {interpolate, Sequence, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneCtx, useAbs, useT} from '../hooks';
import {rgba, theme} from '../theme';
import {sec} from '../timing';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/** One scene = one <Sequence>. Contents fade out quickly in the last frames (exits are faster than entrances). */
export const Scene: React.FC<{range: readonly [number, number]; fade?: boolean; children?: React.ReactNode}> = ({range, fade = true, children}) => {
  const from = sec(range[0]);
  const dur = sec(range[1]) - from;
  return (
    <Sequence from={from} durationInFrames={dur}>
      <SceneCtx.Provider value={{start: from}}>
        <SceneFade dur={dur} fade={fade}>
          {children}
        </SceneFade>
      </SceneCtx.Provider>
    </Sequence>
  );
};
const SceneFade: React.FC<{dur: number; fade: boolean; children?: React.ReactNode}> = ({dur, fade, children}) => {
  const f = useCurrentFrame();
  const o = fade ? interpolate(f, [dur - 5, dur - 1], [1, 0], clamp) : 1;
  return <div style={{position: 'absolute', inset: 0, opacity: o}}>{children}</div>;
};

type RevealProps = {
  at: number; // seconds (absolute) - the moment the word is SPOKEN; visual lands 4 frames earlier
  until?: number;
  dir?: 'up' | 'down' | 'left' | 'right' | 'none';
  lead?: number;
  y?: number; // if set: absolutely centred horizontally at this top offset
  x?: number;
  spr?: keyof typeof theme.spring;
  float?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
};

/** Entrance (opacity + move + scale via spring), subtle float while on screen, fast exit. */
export const Reveal: React.FC<RevealProps> = ({at, until, dir = 'up', lead = 4, y, x, spr = 'pop', float = true, children, style}) => {
  const abs = useAbs();
  const {fps} = useVideoConfig();
  const fIn = sec(at) - lead;
  const fOut = until === undefined ? Infinity : sec(until);
  if (abs < fIn) return null;
  const p = spring({frame: abs - fIn, fps, config: theme.spring[spr]});
  const ex = abs > fOut ? interpolate(abs, [fOut, fOut + 7], [0, 1], {...clamp, easing: theme.ease.in}) : 0;
  if (ex >= 1) return null;
  const off = (1 - p) * 70;
  const tx = dir === 'left' ? -off : dir === 'right' ? off : 0;
  const ty = dir === 'up' ? off : dir === 'down' ? -off : 0;
  const fl = float ? Math.sin((abs - fIn) / 22) * 3 : 0;
  const inner = (
    <div
      style={{
        opacity: Math.min(1, p * 1.6) * (1 - ex),
        transform: `translate(${tx}px, ${ty - ex * 26 + fl}px) scale(${(0.82 + 0.18 * p) * (1 - 0.06 * ex)})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
  if (y === undefined && x === undefined) return inner;
  return (
    <div style={{position: 'absolute', left: x ?? 0, right: x === undefined ? 0 : undefined, top: y ?? 0, display: 'flex', justifyContent: 'center'}}>
      {inner}
    </div>
  );
};

type Variant = 'blue' | 'hero' | 'danger' | 'glass' | 'green';
const VARS: Record<Variant, {bg: string; fg: string; border?: string}> = {
  blue: {bg: theme.colors.blue, fg: theme.colors.text},
  hero: {bg: theme.colors.hero, fg: theme.colors.ink},
  danger: {bg: theme.colors.danger, fg: theme.colors.text},
  green: {bg: theme.colors.accent, fg: theme.colors.ink},
  glass: {bg: rgba(theme.colors.bgDeep, 0.72), fg: theme.colors.text, border: rgba(theme.colors.text, 0.28)},
};

/** Label box in the style of the reference video (solid box, bold text, yellow highlights via <Hl>). */
export const Chip: React.FC<{variant?: Variant; size?: number; children?: React.ReactNode; icon?: React.ReactNode}> = ({variant = 'blue', size = 60, children, icon}) => {
  const v = VARS[variant];
  return (
    <div
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: size * 0.3,
        background: v.bg,
        color: v.fg,
        border: v.border ? `3px solid ${v.border}` : undefined,
        padding: `${size * 0.2}px ${size * 0.42}px`,
        borderRadius: size * 0.16,
        fontFamily: theme.fonts.body,
        fontWeight: 800,
        fontSize: size,
        lineHeight: 1.06,
        textTransform: 'uppercase',
        whiteSpace: 'nowrap',
        boxShadow: `0 12px 30px ${rgba(theme.colors.ink, 0.38)}`,
      }}
    >
      {icon}
      <span>{children}</span>
    </div>
  );
};
export const Hl: React.FC<{children?: React.ReactNode}> = ({children}) => <span style={{color: theme.colors.hero}}>{children}</span>;

/** Hero display text (Comix Loud, uppercase only). Its glyphs are ~1.3x the font-size tall,
 *  so the box is sized to the visible glyph height (size * 1.32) to keep layouts predictable. */
export const Hero: React.FC<{size?: number; color?: string; children?: React.ReactNode; style?: React.CSSProperties}> = ({size = 160, color = theme.colors.hero, children, style}) => (
  <div style={{height: size * 1.32, display: 'flex', justifyContent: 'center'}}>
    <div
      style={{
        marginTop: size * 0.535,
        fontFamily: theme.fonts.display,
        fontSize: size,
        lineHeight: 1,
        color,
        textTransform: 'uppercase',
        textAlign: 'center',
        whiteSpace: 'nowrap',
        textShadow: `0 ${size * 0.04}px 0 ${rgba(theme.colors.ink, 0.6)}, 0 ${size * 0.1}px ${size * 0.2}px ${rgba(theme.colors.ink, 0.45)}`,
        ...style,
      }}
    >
      {children}
    </div>
  </div>
);

/** Number that counts up between two moments, with an ease-out. */
export const Count: React.FC<{from?: number; to: number; a: number; b: number; format?: (n: number) => string}> = ({from = 0, to, a, b, format}) => {
  const t = useT();
  const v = interpolate(t, [a, b], [from, to], {...clamp, easing: theme.ease.out});
  const n = Math.round(v);
  return <>{format ? format(n) : String(n)}</>;
};
export const withCommas = (n: number): string => n.toLocaleString('en-US');

/** Darkens the globe behind cards between two moments. */
export const Scrim: React.FC<{from: number; to: number; amount?: number}> = ({from, to, amount = 0.45}) => {
  const t = useT();
  const o = interpolate(t, [from - 0.15, from + 0.25, to - 0.25, to], [0, amount, amount, 0], clamp);
  return <div style={{position: 'absolute', inset: 0, background: rgba(theme.colors.bgDeep, o)}} />;
};

/** Glass card used for lists / icon rows. */
export const GlassCard: React.FC<{w?: number; h?: number; children?: React.ReactNode; style?: React.CSSProperties}> = ({w = 880, h = 210, children, style}) => (
  <div
    style={{
      width: w,
      height: h,
      borderRadius: 34,
      background: rgba(theme.colors.bgDeep, 0.68),
      border: `3px solid ${rgba(theme.colors.text, 0.26)}`,
      boxShadow: `0 20px 50px ${rgba(theme.colors.ink, 0.45)}`,
      display: 'flex',
      alignItems: 'center',
      gap: 36,
      padding: '0 44px',
      boxSizing: 'border-box',
      ...style,
    }}
  >
    {children}
  </div>
);
