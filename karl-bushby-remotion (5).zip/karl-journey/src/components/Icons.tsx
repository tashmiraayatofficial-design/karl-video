import React from 'react';
import {theme} from '../theme';

type IP = {size?: number; color?: string; dark?: string; style?: React.CSSProperties};
const base = (size: number, style?: React.CSSProperties): React.SVGProps<SVGSVGElement> => ({
  width: size,
  height: size,
  viewBox: '0 0 100 100',
  style: {display: 'block', overflow: 'visible', ...style},
});
const C = theme.colors;

export const Skull: React.FC<IP> = ({size = 100, color = C.danger, dark = C.ink, style}) => (
  <svg {...base(size, style)}>
    <path d="M14 90 L86 58" stroke={color} strokeWidth={11} strokeLinecap="round" />
    <path d="M86 90 L14 58" stroke={color} strokeWidth={11} strokeLinecap="round" />
    <path d="M50 4C28 4 16 19 16 37c0 11 5 19 13 23v13h42V60c8-4 13-12 13-23C84 19 72 4 50 4Z" fill={color} stroke={dark} strokeWidth={3} />
    <circle cx={36} cy={40} r={9.5} fill={dark} />
    <circle cx={64} cy={40} r={9.5} fill={dark} />
    <path d="M50 49l-6 11h12z" fill={dark} />
    <path d="M41 73v-9M50 73v-9M59 73v-9" stroke={dark} strokeWidth={3} />
  </svg>
);

export const Tree: React.FC<IP> = ({size = 100, color = C.accent, dark = C.ink, style}) => (
  <svg {...base(size, style)}>
    <rect x={44} y={72} width={12} height={20} rx={3} fill={dark} />
    <path d="M50 8 L78 40 H22 Z" fill={color} />
    <path d="M50 28 L84 62 H16 Z" fill={color} stroke={dark} strokeWidth={2} />
    <path d="M50 46 L90 80 H10 Z" fill={color} stroke={dark} strokeWidth={2} />
  </svg>
);

export const Swamp: React.FC<IP> = ({size = 100, color = C.swim, dark = C.accent, style}) => (
  <svg {...base(size, style)}>
    <path d="M10 70 Q22 60 34 70 T58 70 T82 70 T96 66" fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" />
    <path d="M12 86 Q24 76 36 86 T60 86 T84 86" fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" opacity={0.7} />
    {[28, 46, 64].map((x, i) => (
      <g key={x}>
        <path d={`M${x} 66 V${28 + i * 6}`} stroke={dark} strokeWidth={5} strokeLinecap="round" />
        <ellipse cx={x} cy={22 + i * 6} rx={5} ry={11} fill={dark} />
      </g>
    ))}
  </svg>
);

export const River: React.FC<IP> = ({size = 100, color = C.swim, dark = C.accent, style}) => (
  <svg {...base(size, style)}>
    <rect x={4} y={6} width={92} height={88} rx={14} fill={dark} opacity={0.35} />
    <path d="M64 4 C20 22 90 40 36 58 C10 66 60 78 40 98" fill="none" stroke={color} strokeWidth={13} strokeLinecap="round" />
  </svg>
);

export const Snow: React.FC<IP> = ({size = 100, color = C.ice, style}) => (
  <svg {...base(size, style)}>
    <g stroke={color} strokeWidth={6} strokeLinecap="round" fill="none">
      {[0, 60, 120].map((a) => (
        <g key={a} transform={`rotate(${a} 50 50)`}>
          <path d="M50 8 V92" />
          <path d="M50 22 L40 12 M50 22 L60 12 M50 78 L40 88 M50 78 L60 88" />
        </g>
      ))}
    </g>
  </svg>
);

export const NoCar: React.FC<IP> = ({size = 100, color = C.text, dark = C.danger, style}) => (
  <svg {...base(size, style)}>
    <path d="M14 62 V50 Q14 44 20 42 L30 30 H68 L80 42 Q86 44 86 50 V62 Z" fill={color} />
    <circle cx={32} cy={66} r={9} fill={color} stroke={C.ink} strokeWidth={3} />
    <circle cx={68} cy={66} r={9} fill={color} stroke={C.ink} strokeWidth={3} />
    <circle cx={50} cy={50} r={44} fill="none" stroke={dark} strokeWidth={8} />
    <path d="M19 81 L81 19" stroke={dark} strokeWidth={8} strokeLinecap="round" />
  </svg>
);

export const NoHome: React.FC<IP> = ({size = 100, color = C.text, dark = C.danger, style}) => (
  <svg {...base(size, style)}>
    <path d="M50 20 L82 48 H72 V78 H28 V48 H18 Z" fill={color} />
    <rect x={44} y={56} width={12} height={22} fill={C.ink} />
    <circle cx={50} cy={50} r={44} fill="none" stroke={dark} strokeWidth={8} />
    <path d="M19 81 L81 19" stroke={dark} strokeWidth={8} strokeLinecap="round" />
  </svg>
);

export const Walker: React.FC<IP> = ({size = 100, color = C.hero, style}) => (
  <svg {...base(size, style)}>
    <circle cx={54} cy={16} r={10} fill={color} />
    <path d="M52 30 L44 58 L28 82 M44 58 L62 68 L66 92 M52 30 L66 48 L82 44 M52 30 L38 46 L26 44" fill="none" stroke={color} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Check: React.FC<IP> = ({size = 100, color = C.accent, style}) => (
  <svg {...base(size, style)}>
    <path d="M14 54 L40 80 L88 24" fill="none" stroke={color} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const House: React.FC<IP> = ({size = 100, color = C.ink, style}) => (
  <svg {...base(size, style)}>
    <path d="M50 14 L90 50 H78 V86 H22 V50 H10 Z" fill={color} />
    <rect x={42} y={58} width={16} height={28} fill={C.hero} />
  </svg>
);

export const Doc: React.FC<IP> = ({size = 100, color = C.text, dark = C.blue, style}) => (
  <svg {...base(size, style)}>
    <path d="M22 6 H62 L80 24 V94 H22 Z" fill={color} />
    <path d="M62 6 V24 H80" fill="none" stroke={dark} strokeWidth={4} />
    <path d="M32 40 H70 M32 52 H70 M32 64 H54" stroke={dark} strokeWidth={5} strokeLinecap="round" />
    <circle cx={64} cy={76} r={11} fill="none" stroke={C.danger} strokeWidth={5} />
  </svg>
);

export const Coin: React.FC<IP> = ({size = 100, color = C.hero, dark = C.ink, style}) => (
  <svg {...base(size, style)}>
    <circle cx={50} cy={50} r={42} fill={color} stroke={dark} strokeWidth={4} />
    <circle cx={50} cy={50} r={30} fill="none" stroke={dark} strokeWidth={4} />
    <path d="M50 28 V72 M40 38 H56 Q62 38 62 45 Q62 50 56 50 H44 Q38 50 38 57 Q38 63 44 63 H60" fill="none" stroke={dark} strokeWidth={5} strokeLinecap="round" />
  </svg>
);

export const Clock: React.FC<IP> = ({size = 100, color = C.text, dark = C.blue, style}) => (
  <svg {...base(size, style)}>
    <circle cx={50} cy={50} r={42} fill={color} />
    <circle cx={50} cy={50} r={42} fill="none" stroke={dark} strokeWidth={6} />
    <path d="M50 24 V50 L68 62" fill="none" stroke={dark} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Gate: React.FC<IP> = ({size = 100, color = C.text, dark = C.danger, style}) => (
  <svg {...base(size, style)}>
    <rect x={10} y={20} width={8} height={70} rx={2} fill={color} />
    <rect x={82} y={20} width={8} height={70} rx={2} fill={color} />
    <rect x={8} y={38} width={84} height={12} rx={3} fill={dark} />
    <path d="M24 38 L36 50 M44 38 L56 50 M64 38 L76 50" stroke={color} strokeWidth={5} />
  </svg>
);

export const Passport: React.FC<IP> = ({size = 100, color = C.blue, dark = C.hero, style}) => (
  <svg {...base(size, style)}>
    <rect x={20} y={6} width={60} height={88} rx={8} fill={color} stroke={C.text} strokeWidth={3} />
    <circle cx={50} cy={42} r={16} fill="none" stroke={dark} strokeWidth={4} />
    <path d="M34 42 H66 M50 26 V58 M40 31 Q50 42 40 53 M60 31 Q50 42 60 53" fill="none" stroke={dark} strokeWidth={3} />
    <rect x={32} y={70} width={36} height={6} rx={3} fill={dark} />
  </svg>
);

export const Alert: React.FC<IP> = ({size = 100, color = C.hero, dark = C.ink, style}) => (
  <svg {...base(size, style)}>
    <path d="M50 8 L94 88 H6 Z" fill={color} stroke={dark} strokeWidth={4} strokeLinejoin="round" />
    <path d="M50 36 V62" stroke={dark} strokeWidth={9} strokeLinecap="round" />
    <circle cx={50} cy={76} r={5.5} fill={dark} />
  </svg>
);

export const Cart: React.FC<IP> = ({size = 100, color = C.hero, dark = C.ink, style}) => (
  <svg {...base(size, style)}>
    <path d="M24 30 H72 L66 64 H30 Z" fill={color} stroke={dark} strokeWidth={4} strokeLinejoin="round" />
    <path d="M24 30 L10 18 H2" fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" />
    <circle cx={36} cy={78} r={11} fill={color} stroke={dark} strokeWidth={4} />
    <circle cx={64} cy={78} r={11} fill={color} stroke={dark} strokeWidth={4} />
    <path d="M38 40 H62 M40 52 H60" stroke={dark} strokeWidth={4} strokeLinecap="round" />
  </svg>
);
