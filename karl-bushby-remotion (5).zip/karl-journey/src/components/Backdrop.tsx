import React from 'react';
import {random, staticFile, useCurrentFrame} from 'remotion';
import {rgba, theme} from '../theme';
import {H, W} from '../timing';

const STARS = Array.from({length: 120}, (_, i) => ({
  x: random(`sx${i}`) * W,
  y: random(`sy${i}`) * H,
  r: 0.7 + random(`sr${i}`) * 1.9,
  ph: random(`sp${i}`) * 6.28,
}));

/** Layer 1: deep-space gradient + twinkling stars (a teal haze at the top, like the reference). */
export const Space: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', inset: 0, background: `radial-gradient(ellipse at 50% 45%, ${theme.colors.bg} 0%, ${theme.colors.bgDeep} 75%)`}}>
      <div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg, ${rgba(theme.colors.accent, 0.2)} 0%, transparent 38%)`}} />
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        {STARS.map((s, i) => (
          <circle key={i} cx={s.x} cy={s.y} r={s.r} fill={theme.colors.text} opacity={0.3 + 0.45 * Math.abs(Math.sin(f / 45 + s.ph))} />
        ))}
      </svg>
    </div>
  );
};

/** Top layer: colour grade, vignette and film grain. */
export const Grade: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <>
      <div style={{position: 'absolute', inset: 0, background: `linear-gradient(160deg, ${rgba(theme.colors.hero, 0.05)}, ${rgba(theme.colors.blue, 0.07)})`, mixBlendMode: 'soft-light'}} />
      <div style={{position: 'absolute', inset: 0, background: `radial-gradient(ellipse at 50% 50%, transparent 55%, ${rgba(theme.colors.ink, 0.55)} 100%)`}} />
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `url(${staticFile('grain.png')})`,
          backgroundPosition: `${(f * 37) % 256}px ${(f * 91) % 256}px`,
          mixBlendMode: 'overlay',
          opacity: 0.13,
        }}
      />
    </>
  );
};
