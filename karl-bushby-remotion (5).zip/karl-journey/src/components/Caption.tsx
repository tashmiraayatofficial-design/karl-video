import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {CUES} from '../cues';
import {rgba, theme} from '../theme';
import {FPS} from '../timing';

/** Small caption in the style of the reference video: one SRT cue at a time (audio tags removed). */
export const Caption: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const cue = CUES.find((c) => c.text && t >= c.start && t < c.end);
  if (!cue) return null;
  const o = interpolate(t, [cue.start, cue.start + 0.1, cue.end - 0.08, cue.end], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 60, right: 60, top: theme.layout.captionY, textAlign: 'center', opacity: o}}>
      <span
        style={{
          fontFamily: theme.fonts.body,
          fontWeight: 700,
          fontSize: 54,
          color: theme.colors.text,
          textShadow: `0 3px 10px ${rgba(theme.colors.ink, 0.85)}, 0 0 4px ${rgba(theme.colors.ink, 0.8)}`,
        }}
      >
        {cue.text}
      </span>
    </div>
  );
};
