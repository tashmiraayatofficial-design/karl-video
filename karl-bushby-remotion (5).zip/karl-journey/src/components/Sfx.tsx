import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {sec} from '../timing';

type Ev = {t: number; file: 'whoosh.mp3' | 'pop.wav' | 'bell.wav' | 'alarm.wav'; vol: number; dur: number};
const W_ = (t: number): Ev => ({t, file: 'whoosh.mp3', vol: 0.3, dur: 0.8});
const P_ = (t: number, vol = 0.28): Ev => ({t, file: 'pop.wav', vol, dur: 0.3});

/** Sparse SFX (user-provided files). Each starts ~2 frames before the visual lands. */
const EVENTS: Ev[] = [
  W_(0.0), P_(1.24), W_(4.3), P_(5.82),
  P_(7.76), P_(9.64), P_(12.26), P_(13.34), W_(15.3),
  W_(18.6), P_(19.7), P_(22.4), {t: 24.04, file: 'bell.wav', vol: 0.26, dur: 0.7},
  W_(25.6), {t: 30.3, file: 'alarm.wav', vol: 0.2, dur: 1.4}, P_(30.58),
  W_(36.4), P_(37.22), P_(38.32), P_(39.12), P_(40.4),
  P_(41.3, 0.34), W_(44.6), W_(51.3), P_(53.0), P_(55.1), P_(58.1), P_(59.9),
  W_(64.1), P_(68.02), P_(68.92), P_(70.02), P_(71.38, 0.34),
  W_(72.4), P_(75.16), P_(78.18), W_(83.1), P_(83.5), P_(87.08), W_(90.9), W_(95.5), P_(99.32),
  W_(102.1), P_(104.04), {t: 110.3, file: 'bell.wav', vol: 0.32, dur: 1.3},
  W_(111.3), P_(112.4), W_(114.8), P_(117.72), W_(122.1), P_(123.28), P_(124.36), P_(125.1), P_(125.88),
];

export const Sfx: React.FC = () => (
  <>
    {EVENTS.map((e, i) => {
      const dur = sec(e.dur);
      return (
        <Sequence key={i} from={Math.max(0, sec(e.t) - 2)} durationInFrames={dur}>
          <Audio
            src={staticFile(`sfx/${e.file}`)}
            volume={(f) => e.vol * Math.min(1, Math.max(0, (dur - f) / 6))}
          />
        </Sequence>
      );
    })}
  </>
);
