export const FPS = 30;
export const W = 1080;
export const H = 1920;
/** Voiceover length 126.668 s; the SRT ends at 126.48 s. */
export const TOTAL_SEC = 126.668;
export const TOTAL_FRAMES = Math.ceil(TOTAL_SEC * FPS);
export const sec = (s: number): number => Math.round(s * FPS);

/** Scene boundaries (seconds). Every boundary is a cue boundary of the SRT. */
export const SC = {
  hook: [0, 4.36],
  who: [4.36, 7.78],
  depart: [7.78, 18.68],
  rules: [18.68, 25.66],
  southAmerica: [25.66, 30.1],
  darien: [30.1, 36.46],
  hazards: [36.46, 41.4],
  prison: [41.4, 44.68],
  north: [44.68, 51.4],
  bering: [51.4, 58.18],
  ice: [58.18, 64.2],
  asia: [64.2, 72.46],
  usa: [72.46, 83.22],
  caspian: [83.22, 90.94],
  europe: [90.94, 95.54],
  channel: [95.54, 102.18],
  arrival: [102.18, 111.32],
  total: [111.32, 114.9],
  ring: [114.9, 122.16],
  recap: [122.16, TOTAL_SEC],
} as const;
