import {Easing} from 'remotion';

/** Orthographic globe camera. lat/lon in degrees (lon may be "unwrapped"), R = globe radius in px. */
export type Cam = {lat: number; lon: number; R: number; cx: number; cy: number};
type KF = Cam & {t: number};

const K = (t: number, lat: number, lon: number, R: number, cx = 540, cy = 960): KF => ({t, lat, lon, R, cx, cy});
const G = 980; // cy for full-globe shots (a bit below centre, like the reference)

// Camera path. Longitudes are chosen so every move takes the short way round.
const KFS: KF[] = [
  K(0, 10, -30, 260, 540, G),
  K(1.4, 12, -48, 450, 540, G),
  K(4.36, 6, -60, 470, 540, G),
  K(7.78, -5, -64, 470, 540, G),
  // Punta Arenas
  K(9.6, -49, -71.5, 2600, 540, 1010),
  K(15.0, -50, -71.5, 2800, 540, 1010),
  // both ends of the journey
  K(17.4, 0, -35, 520, 540, G),
  K(24.8, -5, -62, 520, 540, G),
  // South America -> Colombia
  K(26.4, -40, -72, 1400),
  K(27.6, -22, -72, 1500),
  K(28.8, -3, -76, 1600),
  K(29.9, 7, -76.5, 1900),
  // Darien Gap
  K(30.7, 8.2, -77.3, 5200),
  K(36.46, 8.5, -78.0, 5200),
  K(41.0, 8.8, -79.0, 5000),
  K(41.6, 9.0, -79.5, 3800),
  K(44.1, 9.0, -79.6, 3700),
  // Panama -> Alaska
  K(44.68, 9.5, -81, 2600),
  K(45.9, 17, -92, 1700),
  K(47.0, 31, -100, 1400),
  K(48.4, 47, -113, 1300),
  K(50.0, 62, -142, 1500),
  K(51.4, 64.5, -155, 1900),
  // Bering Strait
  K(52.8, 65.6, -168.5, 4000),
  K(58.18, 65.9, -169.6, 4300),
  K(63.5, 66.0, -170.0, 4800),
  // Russia -> Mongolia -> China
  K(64.4, 66, -172, 4600),
  K(65.8, 62, -200, 1500),
  K(67.0, 53, -232, 1300),
  K(68.6, 45, -250, 1500),
  K(72.2, 40, -252, 1700),
  // USA (LA -> Washington)
  K(73.5, 37, -176, 800),
  K(75.6, 37.5, -99, 1400),
  K(82.8, 37.8, -98, 1450),
  // Caspian Sea
  K(84.6, 42, -30, 800),
  K(86.0, 43.5, 70, 1500),
  K(87.2, 42.3, 50.6, 3300),
  K(90.5, 41.6, 50.5, 3500),
  // Turkey -> Europe
  K(91.8, 40.3, 36, 2200),
  K(92.8, 41.0, 29.5, 2800),
  K(94.2, 45.5, 17, 1900),
  K(95.5, 49.5, 4, 2200),
  // English Channel
  K(96.5, 50.7, 1.3, 7000),
  K(102.0, 51.0, 1.0, 7000),
  // Hull
  K(104.0, 52.6, -0.5, 3800),
  K(108.9, 53.4, -0.5, 4200),
  K(110.6, 53.7, -0.35, 6500),
  K(111.32, 53.7, -0.35, 6600),
  // zoom out: the whole route
  K(112.6, 45, -5, 1200),
  K(114.9, 40, -60, 470, 540, G),
  K(122.0, 36, -130, 470, 540, G),
  K(126.7, 34, -170, 470, 540, G),
];

const ease = Easing.bezier(0.65, 0, 0.35, 1);

export function cameraAt(t: number): Cam {
  let c: Cam;
  if (t <= KFS[0].t) c = KFS[0];
  else if (t >= KFS[KFS.length - 1].t) c = KFS[KFS.length - 1];
  else {
    let i = 0;
    while (KFS[i + 1].t <= t) i++;
    const a = KFS[i];
    const b = KFS[i + 1];
    const e = ease((t - a.t) / (b.t - a.t));
    c = {
      lat: a.lat + (b.lat - a.lat) * e,
      lon: a.lon + (b.lon - a.lon) * e,
      R: Math.exp(Math.log(a.R) + (Math.log(b.R) - Math.log(a.R)) * e),
      cx: a.cx + (b.cx - a.cx) * e,
      cy: a.cy + (b.cy - a.cy) * e,
    };
  }
  // gentle "breathing" drift so held shots never freeze
  const drift = (6 / c.R) * (180 / Math.PI);
  return {
    ...c,
    lon: c.lon + drift * Math.sin(t * 0.7),
    lat: c.lat + drift * 0.6 * Math.cos(t * 0.5),
    R: c.R * (1 + 0.008 * Math.sin(t * 0.9)),
  };
}

const D2R = Math.PI / 180;

/** Forward projection of lat/lon to canvas pixels; z > 0 means the point faces the viewer. */
export function project(lat: number, lon: number, cam: Cam): {x: number; y: number; z: number} {
  const p = lat * D2R;
  const l = (lon - cam.lon) * D2R;
  const p0 = cam.lat * D2R;
  const x = Math.cos(p) * Math.sin(l);
  const y = Math.cos(p0) * Math.sin(p) - Math.sin(p0) * Math.cos(p) * Math.cos(l);
  const z = Math.sin(p0) * Math.sin(p) + Math.cos(p0) * Math.cos(p) * Math.cos(l);
  return {x: cam.cx + cam.R * x, y: cam.cy - cam.R * y, z};
}
