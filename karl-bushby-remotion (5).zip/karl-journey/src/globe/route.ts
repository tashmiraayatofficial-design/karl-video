/**
 * Route data. Coordinates are [lat, lon] with lon "unwrapped" (monotonic westward across the
 * date line). The path is ILLUSTRATIVE: it joins the places named in the script and is not a GPS track.
 */
export type LegKind = 'walk' | 'ice' | 'swim' | 'detour' | 'goal';
export type Pt = [number, number];
export type Leg = {id: string; kind: LegKind; t0: number; t1: number; pts: Pt[]; until?: number};

export const LEGS: Leg[] = [
  {id: 'goal', kind: 'goal', t0: 16.9, t1: 18.2, until: 25.2, pts: [
    [-53.16, -70.91], [-20, -45], [10, -30], [40, -12], [53.74, -0.34]]},
  {id: 'southAmerica', kind: 'walk', t0: 25.66, t1: 29.85, pts: [
    [-53.16, -70.91], [-47, -72.6], [-41, -72.9], [-35, -72.1], [-29, -71.1], [-23, -70.3], [-18.5, -70.3],
    [-12, -77], [-5, -80.5], [-1, -80.4], [1.6, -78.8], [3.8, -76.6], [6.2, -75.6], [8.1, -76.73]]},
  {id: 'darien', kind: 'walk', t0: 30.7, t1: 36.1, pts: [
    [8.1, -76.73], [8.4, -77.1], [8.3, -77.45], [8.15, -77.69]]},
  {id: 'toPanama', kind: 'walk', t0: 37.2, t1: 41.2, pts: [
    [8.15, -77.69], [8.5, -78.3], [8.98, -79.52]]},
  {id: 'north', kind: 'walk', t0: 44.85, t1: 50.4, pts: [
    [8.98, -79.52], [9.9, -84.1], [12.1, -86.3], [14.6, -90.5], [17.0, -96.7], [19.4, -99.1], [25.7, -100.3],
    [29.4, -100.5], [33, -102], [39.7, -105], [46.8, -112], [51, -114], [55, -118], [60.7, -135],
    [63.5, -145], [64.8, -147.7], [64.5, -157], [64.5, -165.4], [65.6, -168.1]]},
  {id: 'bering', kind: 'ice', t0: 55.3, t1: 58.0, pts: [
    [65.6, -168.1], [65.76, -169.0], [66.07, -169.7]]},
  {id: 'asia', kind: 'walk', t0: 64.9, t1: 68.1, pts: [
    [66.07, -169.7], [66.2, -174], [64.7, -182.5], [59.6, -209.2], [62, -230.3], [52.3, -255.7],
    [47.9, -253.1], [43.6, -248]]},
  {id: 'toCaspian', kind: 'walk', t0: 85.6, t1: 87.0, pts: [
    [43.6, -248], [43.8, -272.4], [43.2, -283.1], [44.5, -294], [43.65, -308.85]]},
  {id: 'caspian', kind: 'swim', t0: 87.3, t1: 90.3, pts: [
    [43.65, -308.85], [42.2, -309.6], [40.45, -310.1]]},
  {id: 'europe', kind: 'walk', t0: 91.0, t1: 95.2, pts: [
    [40.45, -310.1], [41.7, -315.2], [39.9, -327.1], [41.0, -331], [42.7, -336.7], [44.8, -339.5],
    [48.2, -343.6], [48.1, -348.4], [48.9, -357.65], [50.87, -358.42]]},
  {id: 'channel', kind: 'swim', t0: 98.4, t1: 101.6, pts: [
    [50.87, -358.42], [51.13, -358.69]]},
  {id: 'england', kind: 'walk', t0: 102.9, t1: 109.4, pts: [
    [51.13, -358.69], [51.5, -360], [52.57, -360.24], [53.1, -359.8], [53.74, -360.34]]},
  {id: 'usa', kind: 'detour', t0: 80.0, t1: 82.4, pts: [
    [34.05, -118.24], [36.2, -115.1], [39.74, -104.99], [39.1, -94.58], [38.63, -90.2], [39.1, -84.5],
    [40.44, -80.0], [38.9, -77.04]]},
];

export type Dense = {lat: number; lon: number; cum: number}[];
const STEP = 0.25; // degrees between drawn vertices

/** Interpolates each leg to small steps; swim legs get a little wave. */
export function densify(leg: Leg): {pts: Dense; total: number} {
  const out: Dense = [];
  let cum = 0;
  for (let i = 0; i < leg.pts.length - 1; i++) {
    const [a1, o1] = leg.pts[i];
    const [a2, o2] = leg.pts[i + 1];
    const len = Math.hypot(a2 - a1, (o2 - o1) * Math.cos((a1 * Math.PI) / 180));
    const n = Math.max(2, Math.ceil(len / (leg.kind === 'swim' ? 0.02 : STEP)));
    for (let k = i === 0 ? 0 : 1; k <= n; k++) {
      const u = k / n;
      let lat = a1 + (a2 - a1) * u;
      let lon = o1 + (o2 - o1) * u;
      if (leg.kind === 'swim') {
        const w = Math.sin(u * len * 90) * 0.03;
        lat += w * 0.8;
        lon += w;
      }
      if (out.length) {
        const p = out[out.length - 1];
        cum += Math.hypot(lat - p.lat, (lon - p.lon) * Math.cos((lat * Math.PI) / 180));
      }
      out.push({lat, lon, cum});
    }
  }
  return {pts: out, total: cum || 1};
}

export const DENSE = LEGS.map((l) => ({leg: l, ...densify(l)}));

/** Highlighted danger zone (Darien Gap) - coarse polygon. */
export const DARIEN_POLY: Pt[] = [
  [9.05, -77.9], [8.95, -77.3], [8.6, -77.0], [8.0, -76.65], [7.6, -76.9], [7.7, -77.6], [8.2, -78.0], [8.6, -78.3],
];

export type MarkerKind = 'label' | 'start' | 'home' | 'ring';
export type Marker = {id: string; lat: number; lon: number; at: number; until: number; kind: MarkerKind; text?: string; dx?: number; dy?: number};

export const MARKERS: Marker[] = [
  {id: 'pa', lat: -53.16, lon: -70.91, at: 9.66, until: 18.6, kind: 'start', text: 'PUNTA ARENAS, CHILE'},
  {id: 'hull0', lat: 53.74, lon: -0.34, at: 16.62, until: 18.6, kind: 'home', text: 'HULL, ENGLAND'},
  {id: 'colombia', lat: 6.9, lon: -75.6, at: 33.86, until: 36.4, kind: 'label', text: 'COLOMBIA'},
  {id: 'panama', lat: 8.75, lon: -79.2, at: 34.56, until: 36.4, kind: 'label', text: 'PANAMA'},
  {id: 'panamaCity', lat: 8.98, lon: -79.52, at: 40.42, until: 41.4, kind: 'label', text: 'PANAMA', dy: 70},
  {id: 'alaska0', lat: 64.2, lon: -150, at: 49.76, until: 51.3, kind: 'label', text: 'ALASKA'},
  {id: 'alaska', lat: 65.0, lon: -163.5, at: 56.14, until: 64, kind: 'label', text: 'ALASKA', dy: -70},
  {id: 'russia', lat: 66.6, lon: -177, at: 57.02, until: 64, kind: 'label', text: 'RUSSIA', dy: -70},
  {id: 'strait', lat: 65.85, lon: -168.9, at: 56.14, until: 64, kind: 'ring'},
  {id: 'rus1', lat: 60, lon: -212, at: 65.6, until: 69, kind: 'label', text: 'RUSSIA'},
  {id: 'mon', lat: 47.2, lon: -253.4, at: 66.3, until: 69, kind: 'label', text: 'MONGOLIA'},
  {id: 'chn', lat: 40.5, lon: -250, at: 67.2, until: 72.4, kind: 'label', text: 'CHINA'},
  {id: 'la', lat: 34.05, lon: -118.24, at: 80.22, until: 83, kind: 'label', text: 'LOS ANGELES', dy: 52},
  {id: 'dc', lat: 38.9, lon: -77.04, at: 81.4, until: 83, kind: 'label', text: 'WASHINGTON, D.C.', dy: -52},
  {id: 'casp', lat: 41.6, lon: -306.4, at: 88.52, until: 91, kind: 'label', text: 'CASPIAN SEA'},
  {id: 'aze', lat: 40.0, lon: -313.2, at: 89.6, until: 91, kind: 'label', text: 'AZERBAIJAN'},
  {id: 'tur', lat: 38.2, lon: -326.5, at: 91.6, until: 95.5, kind: 'label', text: 'TURKEY'},
  {id: 'bos', lat: 41.0, lon: -331, at: 92.6, until: 95.5, kind: 'label', text: 'BOSPHORUS', dy: -50},
  {id: 'eur', lat: 46.2, lon: -343, at: 94.1, until: 95.5, kind: 'label', text: 'EUROPE'},
  {id: 'fra', lat: 50.55, lon: -359.2, at: 100.18, until: 102.2, kind: 'label', text: 'FRANCE', dy: 40},
  {id: 'eng', lat: 51.45, lon: -360.7, at: 101.06, until: 102.2, kind: 'label', text: 'ENGLAND', dy: -40},
  {id: 'chRing', lat: 51.0, lon: -358.55, at: 98.4, until: 102.2, kind: 'ring'},
  {id: 'hull', lat: 53.74, lon: -0.34, at: 108.94, until: 111.2, kind: 'home', text: 'HOME IN HULL'},
];

/** Sea-ice strength in the Bering Strait region (0..1), used by the globe shader. */
export function iceAt(t: number): number {
  const up = Math.min(1, Math.max(0, (t - 54.8) / 1.8));
  const down = Math.min(1, Math.max(0, (t - 66) / 4));
  return up * (1 - down);
}
export const ICE_CENTER: Pt = [65.8, -168.5];
export const ICE_RADIUS = 0.2;
