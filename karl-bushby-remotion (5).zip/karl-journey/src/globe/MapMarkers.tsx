import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {House} from '../components/Icons';
import {rgba, theme} from '../theme';
import {sec} from '../timing';
import {cameraAt, project} from './camera';
import {MARKERS, Marker} from './route';

const Pill: React.FC<{text: string}> = ({text}) => (
  <div
    style={{
      background: rgba(theme.colors.bgDeep, 0.78),
      border: `3px solid ${rgba(theme.colors.text, 0.3)}`,
      color: theme.colors.text,
      fontFamily: theme.fonts.body,
      fontWeight: 800,
      fontSize: 38,
      padding: '6px 22px',
      borderRadius: 999,
      whiteSpace: 'nowrap',
      boxShadow: `0 8px 22px ${rgba(theme.colors.ink, 0.45)}`,
    }}
  >
    {text}
  </div>
);

const Item: React.FC<{m: Marker; x: number; y: number; f: number}> = ({m, x, y, f}) => {
  const {fps} = useVideoConfig();
  const fin = sec(m.at) - 4;
  const fout = sec(m.until);
  const p = spring({frame: f - fin, fps, config: theme.spring.pop});
  const ex = f > fout ? Math.min(1, (f - fout) / 7) : 0;
  const o = Math.min(1, p * 1.6) * (1 - ex);
  const ph = (f % 50) / 50;
  const pos: React.CSSProperties = {position: 'absolute', left: x, top: y, opacity: o, transform: `translate(-50%,-50%) scale(${0.7 + 0.3 * p})`};

  if (m.kind === 'ring') {
    return (
      <div style={{position: 'absolute', left: x, top: y, opacity: o}}>
        {[0, 0.5].map((k) => {
          const q = (ph + k) % 1;
          return <div key={k} style={{position: 'absolute', left: -60 * q - 14, top: -60 * q - 14, width: 120 * q + 28, height: 120 * q + 28, borderRadius: '50%', border: `4px solid ${rgba(theme.colors.text, 0.9 * (1 - q))}`}} />;
        })}
        <div style={{position: 'absolute', left: -8, top: -8, width: 16, height: 16, borderRadius: '50%', background: theme.colors.text}} />
      </div>
    );
  }
  if (m.kind === 'home') {
    return (
      <div style={pos}>
        <div style={{position: 'relative', width: 92, height: 92}}>
          <div style={{position: 'absolute', inset: -26 * ph, borderRadius: '50%', border: `4px solid ${rgba(theme.colors.hero, 0.8 * (1 - ph))}`}} />
          <div style={{position: 'absolute', inset: 0, borderRadius: '50%', background: theme.colors.hero, border: `4px solid ${theme.colors.text}`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 10px 26px ${rgba(theme.colors.ink, 0.5)}`}}>
            <House size={54} />
          </div>
          {m.text && (
            <div style={{position: 'absolute', left: '50%', top: m.dy ?? 118, transform: 'translate(-50%,-50%)'}}>
              <Pill text={m.text} />
            </div>
          )}
        </div>
      </div>
    );
  }
  if (m.kind === 'start') {
    return (
      <div style={pos}>
        <div style={{position: 'relative', width: 40, height: 40}}>
          <div style={{position: 'absolute', inset: -22 * ph, borderRadius: '50%', border: `4px solid ${rgba(theme.colors.accent, 0.85 * (1 - ph))}`}} />
          <div style={{position: 'absolute', inset: 0, borderRadius: '50%', background: theme.colors.accent, border: `5px solid ${theme.colors.text}`}} />
          {m.text && (
            <div style={{position: 'absolute', left: '50%', top: m.dy ?? -62, transform: 'translate(-50%,-50%)'}}>
              <Pill text={m.text} />
            </div>
          )}
        </div>
      </div>
    );
  }
  return (
    <div style={pos}>
      <div style={{position: 'relative', width: 20, height: 20}}>
        <div style={{position: 'absolute', inset: 0, borderRadius: '50%', background: theme.colors.text, border: `4px solid ${theme.colors.blue}`}} />
        <div style={{position: 'absolute', left: '50%', top: m.dy ?? -46, transform: 'translate(-50%,-50%)'}}>
          <Pill text={m.text ?? ''} />
        </div>
      </div>
    </div>
  );
};

/** Pins, labels and rings that are glued to lat/lon on the globe (positions follow the camera). */
export const MapMarkers: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cam = cameraAt(f / fps);
  return (
    <>
      {MARKERS.map((m) => {
        if (f < sec(m.at) - 4 || f > sec(m.until) + 8) return null;
        const q = project(m.lat, m.lon, cam);
        if (q.z < 0.1) return null;
        return <Item key={m.id} m={m} x={q.x} y={q.y} f={f} />;
      })}
    </>
  );
};
