import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Skull} from '../components/Icons';
import {rgba, theme} from '../theme';
import {H, W, sec} from '../timing';
import {Cam, cameraAt, project} from './camera';
import {DARIEN_POLY, DENSE, Dense, LegKind} from './route';

const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

/** Visible SVG path runs of a dense leg up to cumulative length `upto`; also returns the tip. */
function runs(pts: Dense, upto: number, cam: Cam): {paths: string[]; tip: {lat: number; lon: number}} {
  const paths: string[] = [];
  let cur = '';
  let n = 0;
  let prev: Dense[number] | null = null;
  let tip = {lat: pts[0].lat, lon: pts[0].lon};
  const add = (lat: number, lon: number) => {
    const q = project(lat, lon, cam);
    if (q.z > 0.03) {
      cur += `${n === 0 ? 'M' : 'L'}${q.x.toFixed(1)} ${q.y.toFixed(1)} `;
      n++;
    } else {
      if (n > 1) paths.push(cur);
      cur = '';
      n = 0;
    }
  };
  for (const p of pts) {
    if (p.cum > upto) {
      if (prev && p.cum > prev.cum) {
        const k = (upto - prev.cum) / (p.cum - prev.cum);
        const lat = prev.lat + (p.lat - prev.lat) * k;
        const lon = prev.lon + (p.lon - prev.lon) * k;
        add(lat, lon);
        tip = {lat, lon};
      }
      break;
    }
    add(p.lat, p.lon);
    tip = {lat: p.lat, lon: p.lon};
    prev = p;
  }
  if (n > 1) paths.push(cur);
  return {paths, tip};
}

const STYLE: Record<LegKind, {color: string}> = {
  walk: {color: theme.colors.hero},
  detour: {color: theme.colors.hero},
  ice: {color: theme.colors.ice},
  goal: {color: theme.colors.text},
  swim: {color: theme.colors.swim},
};

/** Route lines drawn on the globe, the red "current position" dot and the Darien danger zone. */
export const RouteOverlay: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / fps;
  const cam = cameraAt(t);
  const w = interpolate(cam.R, [470, 1500, 5000], [5, 8, 12], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  const headRef: {v: {lat: number; lon: number} | null; t0: number} = {v: null, t0: -1};
  const lines: React.ReactNode[] = [];
  DENSE.forEach(({leg, pts, total}) => {
    if (t < leg.t0 || (leg.until !== undefined && t > leg.until)) return;
    const p = theme.ease.inOut(clamp01((t - leg.t0) / (leg.t1 - leg.t0)));
    const {paths, tip} = runs(pts, total * p, cam);
    if (leg.t0 > headRef.t0 && !leg.until) {
      headRef.t0 = leg.t0;
      headRef.v = tip;
    }
    const st = STYLE[leg.kind];
    const dash = leg.kind === 'goal' ? `${w * 1.8} ${w * 1.8}` : leg.kind === 'swim' ? `1 ${w * 2.2}` : leg.kind === 'ice' ? `${w * 2.2} ${w * 1.4}` : leg.kind === 'detour' ? `${w * 2.4} ${w * 1.6}` : undefined;
    const off = leg.kind === 'swim' ? -f * 0.6 : 0;
    paths.forEach((d, i) => {
      lines.push(
        <g key={`${leg.id}${i}`} fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d={d} stroke={rgba(st.color, 0.28)} strokeWidth={w * 2.8} />
          <path d={d} stroke={rgba(theme.colors.ink, 0.5)} strokeWidth={w + 5} strokeDasharray={dash} strokeDashoffset={off} />
          <path d={d} stroke={st.color} strokeWidth={w} strokeDasharray={dash} strokeDashoffset={off} />
        </g>,
      );
    });
  });

  // red current-position dot with pulse
  let headEl: React.ReactNode = null;
  if (headRef.v) {
    const q = project(headRef.v.lat, headRef.v.lon, cam);
    if (q.z > 0.05) {
      const ph = (f % 45) / 45;
      headEl = (
        <g>
          <circle cx={q.x} cy={q.y} r={18 + 26 * ph} fill="none" stroke={rgba(theme.colors.danger, 0.7 * (1 - ph))} strokeWidth={4} />
          <circle cx={q.x} cy={q.y} r={24} fill={rgba(theme.colors.danger, 0.3)} />
          <circle cx={q.x} cy={q.y} r={15} fill={theme.colors.danger} stroke={theme.colors.text} strokeWidth={3} />
          <circle cx={q.x} cy={q.y} r={5} fill={theme.colors.text} />
        </g>
      );
    }
  }

  // Darien Gap danger zone (green highlight + skull), like the reference
  let zone: React.ReactNode = null;
  const zIn = sec(30.6) - 4;
  const zOut = sec(41.4);
  if (f >= zIn && f <= zOut + 8) {
    const pr = spring({frame: f - zIn, fps, config: theme.spring.soft});
    const ex = f > zOut ? clamp01((f - zOut) / 7) : 0;
    const proj = DARIEN_POLY.map(([la, lo]) => project(la, lo, cam));
    const d = proj.map((q, i) => `${i ? 'L' : 'M'}${q.x.toFixed(1)} ${q.y.toFixed(1)}`).join(' ') + 'Z';
    const cx = proj.reduce((s, q) => s + q.x, 0) / proj.length;
    const cy = proj.reduce((s, q) => s + q.y, 0) / proj.length;
    const pulse = 0.5 + 0.5 * Math.sin(f / 8);
    const sp = spring({frame: f - sec(31.0), fps, config: theme.spring.pop});
    zone = (
      <g opacity={pr * (1 - ex)}>
        <path d={d} fill={rgba(theme.colors.accent, 0.34 + 0.1 * pulse)} stroke={theme.colors.accent} strokeWidth={5} strokeLinejoin="round" />
        <path d={d} fill="none" stroke={rgba(theme.colors.accent, 0.35)} strokeWidth={16} strokeLinejoin="round" />
        <g transform={`translate(${cx - 55} ${cy - 62}) scale(${Math.max(0, sp)})`} style={{transformOrigin: '55px 62px'}}>
          <Skull size={110} />
        </g>
      </g>
    );
  }

  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
      {zone}
      {lines}
      {headEl}
    </svg>
  );
};
