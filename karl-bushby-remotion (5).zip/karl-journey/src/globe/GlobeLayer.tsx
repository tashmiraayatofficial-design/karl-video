import React, {useLayoutEffect, useRef, useState} from 'react';
import {cancelRender, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {cameraAt} from './camera';
import {ICE_CENTER, ICE_RADIUS, iceAt} from './route';

const VERT = `#version 300 es
in vec2 p;
void main(){ gl_Position = vec4(p, 0.0, 1.0); }`;

const FRAG = `#version 300 es
precision highp float;
uniform vec2 uRes; uniform vec2 uCenter; uniform float uR;
uniform float uLat0; uniform float uLon0;
uniform sampler2D uTex;
uniform float uIce; uniform vec2 uIceC; uniform float uIceRad;
out vec4 outColor;
const float PI = 3.14159265359;

float hash(vec2 p){ vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
vec2 hash2(vec2 p){ vec3 q = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973)); q += dot(q, q.yzx + 33.33); return fract((q.xx + q.yz) * q.zy); }
// Worley noise: x = F1, y = F2, z = id of nearest cell
vec3 worley(vec2 x){
  vec2 n = floor(x); vec2 f = fract(x);
  float f1 = 8.0; float f2 = 8.0; float id = 0.0;
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 g = vec2(float(i), float(j));
    vec2 o = hash2(n + g);
    vec2 r = g + o - f;
    float d = dot(r, r);
    if (d < f1) { f2 = f1; f1 = d; id = hash(n + g); }
    else if (d < f2) { f2 = d; }
  }
  return vec3(sqrt(f1), sqrt(f2), id);
}

void main(){
  vec2 px = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);
  vec2 d = (px - uCenter) / uR; d.y = -d.y;
  float r2 = dot(d, d);
  float r = sqrt(r2);
  float z = sqrt(max(0.0, 1.0 - r2));
  float sl = sin(uLat0); float cl = cos(uLat0);
  float lat = asin(clamp(z * sl + d.y * cl, -1.0, 1.0));
  float lon = uLon0 + atan(d.x, z * cl - d.y * sl);
  float u = lon / (2.0 * PI) + 0.5;
  float v = 0.5 - lat / PI;
  // seam-safe derivatives for mip selection
  float u1 = fract(u); float u2 = fract(u + 0.5) - 0.5;
  vec2 dx1 = vec2(dFdx(u1), dFdx(v)); vec2 dx2 = vec2(dFdx(u2), dFdx(v));
  vec2 dy1 = vec2(dFdy(u1), dFdy(v)); vec2 dy2 = vec2(dFdy(u2), dFdy(v));
  vec2 gx = abs(dx1.x) < abs(dx2.x) ? dx1 : dx2;
  vec2 gy = abs(dy1.x) < abs(dy2.x) ? dy1 : dy2;
  vec3 col = textureGrad(uTex, vec2(u1, v), gx, gy).rgb;
  float water = smoothstep(0.02, 0.10, col.b - max(col.r, col.g * 0.75));

  // drifting sea ice around the Bering Strait
  float cosd = sin(lat) * sin(uIceC.x) + cos(lat) * cos(uIceC.x) * cos(lon - uIceC.y);
  float dang = acos(clamp(cosd, -1.0, 1.0));
  float reg = (1.0 - smoothstep(uIceRad * 0.45, uIceRad, dang)) * uIce;
  vec2 wp = vec2((lon - uIceC.y) * cos(lat), lat - uIceC.x) * 62.0;
  vec3 w1 = worley(wp);
  float edge = w1.y - w1.x;
  float cell = step(w1.z, reg * 0.88);
  float crack = smoothstep(0.03, 0.09, edge);
  vec3 iceCol = mix(vec3(0.70, 0.85, 0.95), vec3(0.96, 0.98, 1.0), w1.z) * (0.92 + 0.08 * crack);
  float iceA = cell * crack * water * step(0.02, reg);
  col = mix(col, iceCol, iceA * 0.93);
  col = mix(col, col * vec3(0.55, 0.70, 0.90), (1.0 - crack) * cell * water * reg * 0.6);

  // lighting
  vec3 n = vec3(d.x, d.y, z);
  vec3 L = normalize(vec3(-0.45, 0.5, 0.75));
  float lam = clamp(dot(n, L), 0.0, 1.0);
  float shade = mix(0.62, 1.08, pow(lam, 0.8));
  float limb = pow(z, 0.28);
  vec3 lit = col * shade * mix(0.55, 1.0, limb);
  vec3 Rv = reflect(-L, n);
  lit += vec3(0.9, 0.95, 1.0) * pow(max(Rv.z, 0.0), 40.0) * water * 0.14 * (1.0 - iceA);
  float rim = pow(1.0 - z, 2.6);
  lit = mix(lit, vec3(0.42, 0.68, 1.0), rim * 0.6);

  // atmosphere glow + anti-aliased edge
  float aa = 1.5 / uR;
  float inside = 1.0 - smoothstep(1.0 - aa, 1.0 + aa, r);
  float e = max(r - 1.0, 0.0);
  float glow = exp(-e * 16.0) * 0.85;
  float a = max(inside, glow * (1.0 - inside));
  vec3 rgb = mix(vec3(0.35, 0.62, 1.0), lit, inside);
  outColor = vec4(rgb * a, a);
}`;

type GLState = {gl: WebGL2RenderingContext; u: Record<string, WebGLUniformLocation | null>};

let imgPromise: Promise<HTMLImageElement> | null = null;
const loadImage = (): Promise<HTMLImageElement> => {
  if (!imgPromise) {
    imgPromise = new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('earth_day.jpg failed to load'));
      im.src = staticFile('earth_day.jpg');
    });
  }
  return imgPromise;
};

const compile = (gl: WebGL2RenderingContext, type: number, src: string) => {
  const s = gl.createShader(type)!;
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) ?? 'shader error');
  return s;
};

const init = (canvas: HTMLCanvasElement, img: HTMLImageElement): GLState => {
  const gl = canvas.getContext('webgl2', {preserveDrawingBuffer: true, premultipliedAlpha: true, alpha: true, antialias: false});
  if (!gl) throw new Error('WebGL2 not available');
  const prog = gl.createProgram()!;
  gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT));
  gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog) ?? 'link error');
  gl.useProgram(prog);
  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, 'p');
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const tex = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
  gl.generateMipmap(gl.TEXTURE_2D);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  const aniso = gl.getExtension('EXT_texture_filter_anisotropic');
  if (aniso) gl.texParameterf(gl.TEXTURE_2D, aniso.TEXTURE_MAX_ANISOTROPY_EXT, 8);
  const names = ['uRes', 'uCenter', 'uR', 'uLat0', 'uLon0', 'uTex', 'uIce', 'uIceC', 'uIceRad'];
  const u: GLState['u'] = {};
  names.forEach((n) => (u[n] = gl.getUniformLocation(prog, n)));
  gl.uniform1i(u.uTex, 0);
  return {gl, u};
};

/** The Earth: NASA Blue Marble mapped on a sphere in a WebGL shader (orthographic, with atmosphere). */
export const GlobeLayer: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const ref = useRef<HTMLCanvasElement>(null);
  const st = useRef<GLState | null>(null);
  const [handle] = useState(() => delayRender('Earth texture'));
  const [ready, setReady] = useState(false);
  const released = useRef(false);
  const release = () => {
    if (!released.current) {
      released.current = true;
      continueRender(handle);
    }
  };

  useLayoutEffect(() => {
    let alive = true;
    loadImage()
      .then((img) => {
        if (!alive || !ref.current) return;
        st.current = init(ref.current, img);
        setReady(true);
      })
      .catch((e) => {
        console.error(e);
        cancelRender(e);
      });
    return () => {
      alive = false;
    };
  }, []);

  useLayoutEffect(() => {
    if (!ready || !st.current) return;
    const {gl, u} = st.current;
    const t = frame / fps;
    const cam = cameraAt(t);
    gl.viewport(0, 0, width, height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform2f(u.uRes, width, height);
    gl.uniform2f(u.uCenter, cam.cx, cam.cy);
    gl.uniform1f(u.uR, cam.R);
    gl.uniform1f(u.uLat0, (cam.lat * Math.PI) / 180);
    gl.uniform1f(u.uLon0, (cam.lon * Math.PI) / 180);
    gl.uniform1f(u.uIce, iceAt(t));
    gl.uniform2f(u.uIceC, (ICE_CENTER[0] * Math.PI) / 180, (ICE_CENTER[1] * Math.PI) / 180);
    gl.uniform1f(u.uIceRad, ICE_RADIUS);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    release();
  }, [ready, frame, fps, width, height]);

  return <canvas ref={ref} width={width} height={height} style={{position: 'absolute', left: 0, top: 0, width, height}} />;
};
