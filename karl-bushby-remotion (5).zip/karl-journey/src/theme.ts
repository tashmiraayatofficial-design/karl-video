import {Easing} from 'remotion';

/** Single source of truth for colors, fonts, easing and springs. No raw hex anywhere else. */
export const theme = {
  colors: {
    // "Natural Earth Day": navy space base, yellow route hero, green accent
    bg: '#0E2A47',
    bgDeep: '#061423',
    ink: '#06121F',
    hero: '#FFD60A',
    accent: '#3DDC84',
    text: '#FFFFFF',
    blue: '#1A56DB',
    danger: '#E63946',
    ice: '#BFE6FF',
    swim: '#4FD1FF',
    muted: '#A9C3DD',
  },
  fonts: {
    // Comix Loud is ALL-CAPS only (no lowercase glyphs): always pass uppercase text.
    display: "'Comix Loud', Impact, 'Arial Black', sans-serif",
    body: "Inter, 'SF Pro Display', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Liberation Sans', sans-serif",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    in: Easing.bezier(0.5, 0, 0.8, 0.3),
    inOut: Easing.bezier(0.65, 0, 0.35, 1),
  },
  spring: {
    pop: {damping: 12, stiffness: 150, mass: 0.7},
    soft: {damping: 22, stiffness: 100, mass: 0.9},
    snap: {damping: 15, stiffness: 240, mass: 0.6},
  },
  layout: {safeTop: 240, safeBottom: 1680, captionY: 1500},
};

export const rgba = (hex: string, a: number): string => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
