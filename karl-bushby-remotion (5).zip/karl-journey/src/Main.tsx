import React from 'react';
import {AbsoluteFill, Audio, getRemotionEnvironment, staticFile} from 'remotion';
import {Grade, Space} from './components/Backdrop';
import {Caption} from './components/Caption';
import {Sfx} from './components/Sfx';
import {GlobeLayer} from './globe/GlobeLayer';
import {MapMarkers} from './globe/MapMarkers';
import {RouteOverlay} from './globe/RouteOverlay';
import {useFonts} from './hooks';
import {SceneDarien, SceneDepart, SceneHook, SceneRules, SceneSouthAmerica, SceneWho} from './scenes/SceneGroupA';
import {SceneAsia, SceneBering, SceneHazards, SceneIce, SceneNorth, ScenePrison} from './scenes/SceneGroupB';
import {SceneArrival, SceneCaspian, SceneChannel, SceneEurope, SceneRecap, SceneRing, SceneTotal, SceneUsa} from './scenes/SceneGroupC';
import {theme} from './theme';

export type MainProps = {
  /** Play public/voiceover.mp3. Default: on in Studio/preview, OFF while rendering. Override with --props='{"voiceover":true}' */
  voiceover?: boolean;
  /** Small caption (one SRT cue at a time). */
  captions?: boolean;
};

/** Layer order: space -> Earth -> route -> map pins -> scene graphics -> captions -> grade/grain/vignette. */
export const Main: React.FC<MainProps> = ({voiceover, captions = false}) => {
  useFonts();
  const playVoiceover = voiceover ?? !getRemotionEnvironment().isRendering;
  return (
    <AbsoluteFill style={{backgroundColor: theme.colors.bgDeep}}>
      <Space />
      <GlobeLayer />
      <RouteOverlay />
      <MapMarkers />
      <SceneHook />
      <SceneWho />
      <SceneDepart />
      <SceneRules />
      <SceneSouthAmerica />
      <SceneDarien />
      <SceneHazards />
      <ScenePrison />
      <SceneNorth />
      <SceneBering />
      <SceneIce />
      <SceneAsia />
      <SceneUsa />
      <SceneCaspian />
      <SceneEurope />
      <SceneChannel />
      <SceneArrival />
      <SceneTotal />
      <SceneRing />
      <SceneRecap />
      {captions && <Caption />}
      <Grade />
      <Sfx />
      {playVoiceover && <Audio src={staticFile('voiceover.mp3')} />}
    </AbsoluteFill>
  );
};
