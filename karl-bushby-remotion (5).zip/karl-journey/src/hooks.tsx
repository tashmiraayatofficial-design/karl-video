import React, {useContext, useEffect, useState} from 'react';
import {continueRender, delayRender, staticFile, useCurrentFrame} from 'remotion';
import {FPS} from './timing';

/** Scenes live inside <Sequence>, so useCurrentFrame() is scene-relative. This gives absolute time. */
export const SceneCtx = React.createContext({start: 0});
export const useAbs = (): number => useCurrentFrame() + useContext(SceneCtx).start;
export const useT = (): number => useAbs() / FPS;

/** Loads Comix Loud (works offline, from public/fonts). */
export const useFonts = (): void => {
  const [handle] = useState(() => delayRender('Comix Loud font'));
  useEffect(() => {
    const ff = new FontFace('Comix Loud', `url(${staticFile('fonts/ComixLoud.ttf')})`);
    ff.load()
      .then((f) => {
        (document.fonts as unknown as {add: (f: FontFace) => void}).add(f);
        continueRender(handle);
      })
      .catch(() => continueRender(handle));
  }, [handle]);
};
