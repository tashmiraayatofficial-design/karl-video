// Generated from public/subtitles.srt (audio tags like [sigh] removed)
export type Cue = {i:number; start:number; end:number; text:string};
export const CUES: Cue[] = [
 {
  "i": 1,
  "start": 0.1,
  "end": 1.26,
  "text": "Imagine spending"
 },
 {
  "i": 2,
  "start": 1.26,
  "end": 2.52,
  "text": "28 years trying to"
 },
 {
  "i": 3,
  "start": 2.52,
  "end": 4.36,
  "text": "walk home. His name"
 },
 {
  "i": 4,
  "start": 4.36,
  "end": 5.84,
  "text": "was Karl Bushby, a"
 },
 {
  "i": 5,
  "start": 5.84,
  "end": 6.56,
  "text": "former British"
 },
 {
  "i": 6,
  "start": 6.56,
  "end": 7.78,
  "text": "paratrooper. On"
 },
 {
  "i": 7,
  "start": 7.78,
  "end": 9.66,
  "text": "November 1st, 1998,"
 },
 {
  "i": 8,
  "start": 9.66,
  "end": 10.68,
  "text": "he left Punta"
 },
 {
  "i": 9,
  "start": 10.68,
  "end": 11.62,
  "text": "Arenas, Chile,"
 },
 {
  "i": 10,
  "start": 11.62,
  "end": 12.28,
  "text": "with a small"
 },
 {
  "i": 11,
  "start": 12.28,
  "end": 13.36,
  "text": "expedition cart and"
 },
 {
  "i": 12,
  "start": 13.36,
  "end": 14.24,
  "text": "just a few hundred"
 },
 {
  "i": 13,
  "start": 14.24,
  "end": 15.32,
  "text": "dollars. His"
 },
 {
  "i": 14,
  "start": 15.32,
  "end": 16.62,
  "text": "destination? His"
 },
 {
  "i": 15,
  "start": 16.62,
  "end": 17.44,
  "text": "mother's home in"
 },
 {
  "i": 16,
  "start": 17.44,
  "end": 18.18,
  "text": "Hull, England."
 },
 {
  "i": 17,
  "start": 18.68,
  "end": 19.72,
  "text": "He made two rules:"
 },
 {
  "i": 18,
  "start": 19.72,
  "end": 21.14,
  "text": "no transportation"
 },
 {
  "i": 19,
  "start": 21.14,
  "end": 21.64,
  "text": "to advance"
 },
 {
  "i": 20,
  "start": 21.64,
  "end": 22.42,
  "text": "his journey"
 },
 {
  "i": 21,
  "start": 22.42,
  "end": 23.3,
  "text": "and no returning"
 },
 {
  "i": 22,
  "start": 23.3,
  "end": 24.06,
  "text": "home until he"
 },
 {
  "i": 23,
  "start": 24.06,
  "end": 25.02,
  "text": "arrived on foot."
 },
 {
  "i": 24,
  "start": 25.66,
  "end": 26.72,
  "text": "First, he crossed"
 },
 {
  "i": 25,
  "start": 26.72,
  "end": 27.52,
  "text": "South America"
 },
 {
  "i": 26,
  "start": 27.52,
  "end": 27.96,
  "text": "and reached"
 },
 {
  "i": 27,
  "start": 27.96,
  "end": 30.1,
  "text": "Colombia. In 2001,"
 },
 {
  "i": 28,
  "start": 30.1,
  "end": 30.6,
  "text": "he entered the"
 },
 {
  "i": 29,
  "start": 30.6,
  "end": 31.88,
  "text": "notorious Darien"
 },
 {
  "i": 30,
  "start": 31.88,
  "end": 33.18,
  "text": "Gap, a dangerous"
 },
 {
  "i": 31,
  "start": 33.18,
  "end": 33.86,
  "text": "jungle between"
 },
 {
  "i": 32,
  "start": 33.86,
  "end": 34.56,
  "text": "Colombia and"
 },
 {
  "i": 33,
  "start": 34.56,
  "end": 36.46,
  "text": "Panama."
 },
 {
  "i": 34,
  "start": 36.46,
  "end": 37.24,
  "text": "After battling"
 },
 {
  "i": 35,
  "start": 37.24,
  "end": 38.34,
  "text": "dense forests,"
 },
 {
  "i": 36,
  "start": 38.34,
  "end": 39.14,
  "text": "swamps, and"
 },
 {
  "i": 37,
  "start": 39.14,
  "end": 40.42,
  "text": "dangerous rivers, he"
 },
 {
  "i": 38,
  "start": 40.42,
  "end": 41.38,
  "text": "reached Panama,"
 },
 {
  "i": 39,
  "start": 41.4,
  "end": 41.76,
  "text": "where he was"
 },
 {
  "i": 40,
  "start": 41.76,
  "end": 43.18,
  "text": "imprisoned for 18"
 },
 {
  "i": 41,
  "start": 43.18,
  "end": 44.68,
  "text": "days. He continued"
 },
 {
  "i": 42,
  "start": 44.68,
  "end": 45.24,
  "text": "through Central"
 },
 {
  "i": 43,
  "start": 45.24,
  "end": 46.82,
  "text": "America, Mexico,"
 },
 {
  "i": 44,
  "start": 46.82,
  "end": 47.9,
  "text": "the United States,"
 },
 {
  "i": 45,
  "start": 47.9,
  "end": 48.82,
  "text": "and Canada,"
 },
 {
  "i": 46,
  "start": 48.82,
  "end": 49.76,
  "text": "eventually reaching"
 },
 {
  "i": 47,
  "start": 49.76,
  "end": 51.4,
  "text": "Alaska. In March"
 },
 {
  "i": 48,
  "start": 51.4,
  "end": 53.04,
  "text": "2006, alongside"
 },
 {
  "i": 49,
  "start": 53.04,
  "end": 53.78,
  "text": "fellow adventurer"
 },
 {
  "i": 50,
  "start": 53.78,
  "end": 55.14,
  "text": "Dimitri Kiefer, he"
 },
 {
  "i": 51,
  "start": 55.14,
  "end": 56.14,
  "text": "crossed the frozen"
 },
 {
  "i": 52,
  "start": 56.14,
  "end": 57.02,
  "text": "Bering Strait"
 },
 {
  "i": 53,
  "start": 57.02,
  "end": 58.18,
  "text": "into Russia."
 },
 {
  "i": 54,
  "start": 58.18,
  "end": 58.86,
  "text": "The dangerous"
 },
 {
  "i": 55,
  "start": 58.86,
  "end": 60.32,
  "text": "crossing took 14"
 },
 {
  "i": 56,
  "start": 60.32,
  "end": 61.16,
  "text": "days through"
 },
 {
  "i": 57,
  "start": 61.16,
  "end": 62.14,
  "text": "shifting sea ice"
 },
 {
  "i": 58,
  "start": 62.14,
  "end": 62.88,
  "text": "and freezing"
 },
 {
  "i": 59,
  "start": 62.88,
  "end": 64.2,
  "text": "ocean water. His"
 },
 {
  "i": 60,
  "start": 64.2,
  "end": 64.819,
  "text": "journey then"
 },
 {
  "i": 61,
  "start": 64.819,
  "end": 65.6,
  "text": "continued through"
 },
 {
  "i": 62,
  "start": 65.6,
  "end": 66.94,
  "text": "Russia, Mongolia,"
 },
 {
  "i": 63,
  "start": 66.94,
  "end": 68.04,
  "text": "and China, where"
 },
 {
  "i": 64,
  "start": 68.04,
  "end": 68.94,
  "text": "visa restrictions,"
 },
 {
  "i": 65,
  "start": 68.94,
  "end": 70.04,
  "text": "border problems,"
 },
 {
  "i": 66,
  "start": 70.04,
  "end": 70.72,
  "text": "and financial"
 },
 {
  "i": 67,
  "start": 70.72,
  "end": 71.4,
  "text": "difficulties"
 },
 {
  "i": 68,
  "start": 71.4,
  "end": 72.46,
  "text": "repeatedly stopped"
 },
 {
  "i": 69,
  "start": 72.46,
  "end": 73.28,
  "text": "him. In an"
 },
 {
  "i": 70,
  "start": 73.28,
  "end": 74.54,
  "text": "extraordinary attempt"
 },
 {
  "i": 71,
  "start": 74.54,
  "end": 75.18,
  "text": "to overcome"
 },
 {
  "i": 72,
  "start": 75.18,
  "end": 75.82,
  "text": "Russian visa"
 },
 {
  "i": 73,
  "start": 75.82,
  "end": 77.18,
  "text": "restrictions, he even"
 },
 {
  "i": 74,
  "start": 77.18,
  "end": 78.2,
  "text": "walked approximately"
 },
 {
  "i": 75,
  "start": 78.2,
  "end": 80.22,
  "text": "5,600 kilometers"
 },
 {
  "i": 76,
  "start": 80.22,
  "end": 81.4,
  "text": "from Los Angeles to"
 },
 {
  "i": 77,
  "start": 81.4,
  "end": 81.9,
  "text": "Washington,"
 },
 {
  "i": 78,
  "start": 81.9,
  "end": 82.48,
  "text": "D.C."
 },
 {
  "i": 79,
  "start": 83.22,
  "end": 85.14,
  "text": "Then, in 2024, when"
 },
 {
  "i": 80,
  "start": 85.14,
  "end": 85.64,
  "text": "land routes"
 },
 {
  "i": 81,
  "start": 85.64,
  "end": 86.18,
  "text": "into Europe"
 },
 {
  "i": 82,
  "start": 86.18,
  "end": 87.1,
  "text": "became impossible,"
 },
 {
  "i": 83,
  "start": 87.1,
  "end": 88.52,
  "text": "he swam across the"
 },
 {
  "i": 84,
  "start": 88.52,
  "end": 89.6,
  "text": "Caspian Sea to"
 },
 {
  "i": 85,
  "start": 89.6,
  "end": 90.94,
  "text": "Azerbaijan. He"
 },
 {
  "i": 86,
  "start": 90.94,
  "end": 91.6,
  "text": "continued through"
 },
 {
  "i": 87,
  "start": 91.6,
  "end": 92.6,
  "text": "Turkey, crossed"
 },
 {
  "i": 88,
  "start": 92.6,
  "end": 93.24,
  "text": "the Bosphorus,"
 },
 {
  "i": 89,
  "start": 93.24,
  "end": 94.1,
  "text": "and traveled"
 },
 {
  "i": 90,
  "start": 94.1,
  "end": 95.54,
  "text": "across Europe. On"
 },
 {
  "i": 91,
  "start": 95.54,
  "end": 97.48,
  "text": "October 5th, 2026,"
 },
 {
  "i": 92,
  "start": 97.48,
  "end": 98.52,
  "text": "he finally"
 },
 {
  "i": 93,
  "start": 98.52,
  "end": 99.34,
  "text": "swam across the"
 },
 {
  "i": 94,
  "start": 99.34,
  "end": 100.18,
  "text": "English Channel"
 },
 {
  "i": 95,
  "start": 100.18,
  "end": 101.06,
  "text": "from France to"
 },
 {
  "i": 96,
  "start": 101.06,
  "end": 102.18,
  "text": "England. And on"
 },
 {
  "i": 97,
  "start": 102.18,
  "end": 104.06,
  "text": "November 2nd, 2026,"
 },
 {
  "i": 98,
  "start": 104.06,
  "end": 105.88,
  "text": "exactly 28 years"
 },
 {
  "i": 99,
  "start": 105.88,
  "end": 107.0,
  "text": "and 1 day after"
 },
 {
  "i": 100,
  "start": 107.0,
  "end": 108.02,
  "text": "leaving Chile,"
 },
 {
  "i": 101,
  "start": 108.02,
  "end": 108.94,
  "text": "Karl Bushby"
 },
 {
  "i": 102,
  "start": 108.94,
  "end": 109.84,
  "text": "finally arrived at"
 },
 {
  "i": 103,
  "start": 109.84,
  "end": 110.38,
  "text": "his mother's"
 },
 {
  "i": 104,
  "start": 110.38,
  "end": 111.32,
  "text": "home in Hull,"
 },
 {
  "i": 105,
  "start": 111.32,
  "end": 112.24,
  "text": "completing a journey"
 },
 {
  "i": 106,
  "start": 112.24,
  "end": 113.16,
  "text": "of approximately"
 },
 {
  "i": 107,
  "start": 113.16,
  "end": 114.9,
  "text": "50,000 kilometers."
 },
 {
  "i": 108,
  "start": 114.9,
  "end": 116.24,
  "text": "The most astonishing"
 },
 {
  "i": 109,
  "start": 116.24,
  "end": 117.74,
  "text": "fact? He spent only"
 },
 {
  "i": 110,
  "start": 117.74,
  "end": 119.16,
  "text": "about 15 of those"
 },
 {
  "i": 111,
  "start": 119.16,
  "end": 120.52,
  "text": "28 years actually"
 },
 {
  "i": 112,
  "start": 120.52,
  "end": 122.16,
  "text": "walking.  The"
 },
 {
  "i": 113,
  "start": 122.16,
  "end": 123.3,
  "text": "rest was a battle"
 },
 {
  "i": 114,
  "start": 123.3,
  "end": 124.38,
  "text": "against borders,"
 },
 {
  "i": 115,
  "start": 124.38,
  "end": 125.9,
  "text": "bureaucracy, money,"
 },
 {
  "i": 116,
  "start": 125.9,
  "end": 126.48,
  "text": "and time."
 }
];
