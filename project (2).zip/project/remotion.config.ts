import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setOverwriteOutput(true);
// Engine A (tilted tile map) needs no WebGL. swangle is passed on the command line too (harmless).
Config.setChromiumOpenGlRenderer('swangle');
// NOTE: no Config.setCrf here. The bitrate comes from render-settings.env (workflow).
