import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
const frames = process.argv.slice(2).map(Number);
const entry = new URL('../src/index.ts', import.meta.url).pathname;
const serveUrl = await bundle({entryPoint: entry, publicDir: new URL('../public', import.meta.url).pathname});
const opts = {browserExecutable: '/tmp/chromium', chromiumOptions: {gl: 'swangle', disableWebSecurity: true, enableMultiProcessOnLinux: false}, logLevel: 'warn', timeoutInMilliseconds: 120000};
const props = {noTiles: true};
const comp = await selectComposition({serveUrl, id: 'Main', inputProps: props, ...opts});
for (const f of frames) {
  await renderStill({composition: comp, serveUrl, frame: f, output: `/tmp/still_${f}.jpg`, inputProps: props, imageFormat: 'jpeg', ...opts});
  console.log('done', f);
}
