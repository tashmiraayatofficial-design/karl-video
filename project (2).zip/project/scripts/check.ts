import {BOTTOMS, CAM_KEYS, CUES, DURATION_S, HEROES, HLS, ROW_ICONS, MAP_ICONS, ROUTES, PULSES, FPS} from '../src/config';
import {camAt} from '../src/math';
const out: string[] = [];
// 1 camera key order
for (let i = 1; i < CAM_KEYS.length; i++) if (CAM_KEYS[i].t <= CAM_KEYS[i - 1].t) out.push(`CAM order problem at key ${i}: ${CAM_KEYS[i - 1].t.toFixed(2)} -> ${CAM_KEYS[i].t.toFixed(2)}`);
// 2 motion: every 3 s window needs zoom change >=3% or bearing >=2deg or pan
let worst = 1e9;
for (let t = 0; t + 3 <= DURATION_S; t += 0.25) {
  let mz = 0, mb = 0, mp = 0;
  const a = camAt(CAM_KEYS, t);
  for (let u = t; u <= t + 3; u += 0.1) {
    const b = camAt(CAM_KEYS, u);
    mz = Math.max(mz, Math.abs(Math.pow(2, b.zoom - a.zoom) - 1));
    mb = Math.max(mb, Math.abs(b.bearing - a.bearing));
    mp = Math.max(mp, Math.hypot(b.lon - a.lon, b.lat - a.lat) * Math.pow(2, a.zoom) * 0.7);
  }
  const ok = mz >= 0.03 || mb >= 2 || mp >= 40;
  if (!ok) out.push(`MOTION weak in window ${t.toFixed(2)}-${(t + 3).toFixed(2)} z=${(mz * 100).toFixed(1)}% b=${mb.toFixed(1)} pan=${mp.toFixed(0)}px`);
  worst = Math.min(worst, Math.max(mz / 0.03, mb / 2, mp / 40));
}
out.push(`motion margin (1.0 = just enough): ${worst.toFixed(2)}`);
// 3 zones: heroes / bottoms must not overlap in time
const ovl = (name: string, items: {s: number; e: number}[]) => {
  const s = [...items].sort((a, b) => a.s - b.s);
  for (let i = 1; i < s.length; i++) if (s[i].s < s[i - 1].e - 0.001) out.push(`${name} overlap ${s[i - 1].s.toFixed(2)}-${s[i - 1].e.toFixed(2)} vs ${s[i].s.toFixed(2)}`);
};
ovl('HERO', HEROES);
ovl('BOTTOM', BOTTOMS);
// 4 stands <=2 at once
const stands = HLS.filter((h) => h.flag);
let maxSt = 0;
for (let t = 0; t < DURATION_S; t += 0.05) maxSt = Math.max(maxSt, stands.filter((h) => t >= h.flag!.s && t <= h.flag!.e).length);
out.push(`max flag stands at once: ${maxSt}`);
// 5 icon groups at once
let maxIc = 0;
for (let t = 0; t < DURATION_S; t += 0.05) {
  const row = ROW_ICONS.some((r) => t >= r.s && t <= r.e) ? 1 : 0;
  const mp = MAP_ICONS.some((r) => t >= r.s && t <= r.e) ? 1 : 0;
  const rt = ROUTES.some((r) => t >= r.s && t <= r.e && r.head === 'ship') ? 1 : 0;
  const pn = PULSES.some((r) => t >= r.s && t <= r.e) ? 1 : 0;
  maxIc = Math.max(maxIc, row + mp + rt + pn);
}
out.push(`max icon groups at once: ${maxIc}`);
// 6 info coverage per cue
const info = [...HEROES, ...BOTTOMS, ...HLS.filter((h) => h.label).map((h) => ({s: h.label!.s, e: h.label!.e})), ...ROW_ICONS.filter((r) => r.caption)];
for (const c of CUES) {
  const hit = info.some((i) => i.s < c.e && i.e > c.s + 0.05);
  if (!hit) out.push(`NO INFO for cue ${c.i} ${c.s.toFixed(2)}-${c.e.toFixed(2)} "${c.text}"`);
}
// 7 highlight list summary
out.push(`highlights: ${HLS.length}, heroes: ${HEROES.length}, bottoms: ${BOTTOMS.length}, duration ${DURATION_S.toFixed(2)} s = ${Math.round(DURATION_S * FPS)} frames`);
console.log(out.join('\n'));
