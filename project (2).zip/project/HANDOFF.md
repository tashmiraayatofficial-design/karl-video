# HANDOFF - England Video (UK: one country or four?)

Subject: "What exactly is the United Kingdom?" Script from SRT (98 cues). Language: English on screen.
Duration: SRT 111.8 s + end card 2.5 s = 114.3 s = 3429 frames @ 30 fps, 1080x1920, composition `Main`, entry src/index.ts.
Engine: A (tilted satellite tile map, Esri World Imagery). Reason: one country's inner borders and close views. Blue Marble files NOT used (globe goes soft when zoomed in).
Opening: wide shot over the USA ("2026 World Cup comes to America"), long fly over the Atlantic to the UK, England + Scotland click-highlight.
Style: Reference Look. Colors: UK green #3DFF7A, England teal, Scotland amber, Wales royal blue, N. Ireland violet, Ireland lime, USA sky, Panama pink, route yellow, numbers gold. Fonts: Comix Loud (hero text only, uppercase only), Inter 400/600/800 (everything else, incl. GBP sign).
Element picks: sea route (dashed, ship), arrow route, 2 bar charts (158/115, 55/45), timeline bar 1282-1536, counters, hand-drawn icons, light-sweep transitions, particles, end card.
Flag stands (flag-icons, public/flags): us, gb, gb-eng, gb-sct, gb-wls, ie, pa. Northern Ireland: no flag (neutral). Max 2 stands at once. Four-country reveals: stands on England + Scotland only (Wales in the last reveal).
End card: SUBSCRIBE (YouTube) + FOLLOW (Facebook), hand-drawn, no logos. Channel names NOT given yet (src/config.ts CHANNEL = {youtube:'', facebook:''}).
Bitrate: render-settings.env VIDEO_BITRATE=16M (estimate ~230 MB, +-15%). No CRF.
Render time estimate: Engine A not measured; guess 20-60 min (ranges are wide).
Timing: all from src/srt.json (even split of each cue across its words = approximate). Visuals lead words by 0.2 s. Voiceover is 111.96 s; its last ~5 s may run up to ~0.5 s later than the SRT. SRT wins. INCLUDE_VOICEOVER=false.

## Verified (chat sandbox)
- npx tsc --noEmit: passes.
- scripts/check.ts: camera keys in order; every 3 s window has enough camera motion (margin 1.06); no overlap in hero/bottom slots; max 2 flag stands; max 2 icon groups; every cue has an info element.
- 17 preview stills (vector fallback, noTiles) checked by eye for layout.
## NOT verified
- Satellite tiles (sandbox cannot reach Esri), real file size, real render time, the motion in the real video (only the camera path was checked by numbers), labels colliding while the map moves, GitHub run, bitrate flag.

## GitHub test 1 (frames 0-89): OK. Real Esri satellite tiles loaded, 15.9 Mbps, 6.0 MB for 3 s (full estimate ~230 MB), audio present. Fixed: dark margin at plane edge (tiles cut at plane border); plane enlarged.

## Status
Gate A approved. Steps 3-6 done. Waiting for Gate B (user approves key stills). Next: final ZIP -> GitHub upload -> 3 s test (frames 0-89 and last 90: 3339-3428) -> Gate C -> full render.
## Credits
Imagery (c) Esri; Borders: Natural Earth; Flags: flag-icons (MIT); Fonts: Inter (OFL), Comix Loud (user supplied); SFX: user supplied.
