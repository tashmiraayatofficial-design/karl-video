import React from 'react';
import {C, IconKind} from './config';

const N = C.navy;
const CREAM = '#F4EFE2';

const Body: React.FC<{kind: IconKind; red?: boolean}> = ({kind, red}) => {
  const sw = 3.5;
  switch (kind) {
    case 'castle':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round" fill={CREAM}>
          <rect x={22} y={44} width={56} height={46} />
          <rect x={8} y={28} width={22} height={62} />
          <rect x={70} y={28} width={22} height={62} />
          <path d="M8 28v-8h5v4h4v-4h5v4h4v-4h4v8z" />
          <path d="M70 28v-8h5v4h4v-4h5v4h4v-4h4v8z" />
          <path d="M22 44v-6h6v4h6v-4h6v4h6v-4h6v4h6v-4h6v6z" />
          <path d="M42 90v-18a8 8 0 0 1 16 0v18z" fill={N} />
        </g>
      );
    case 'ship':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round">
          <path d="M14 66h72l-10 18H26z" fill="#B5683A" />
          <path d="M50 14v52" fill="none" />
          <path d="M52 18l30 38H52z" fill={CREAM} />
          <path d="M48 24L24 56h24z" fill="#E6DDC6" />
          <path d="M50 14l12 4-12 4z" fill={C.red} />
        </g>
      );
    case 'warning':
      return (
        <g stroke={C.redDark} strokeWidth={4} strokeLinejoin="round">
          <path d="M50 10L92 84H8z" fill={C.red} />
          <rect x={46} y={36} width={8} height={26} rx={3} fill="#fff" stroke="none" />
          <circle cx={50} cy={72} r={5} fill="#fff" stroke="none" />
        </g>
      );
    case 'scales':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round" strokeLinecap="round" fill={CREAM}>
          <path d="M50 14v66" fill="none" />
          <path d="M30 86h40" fill="none" />
          <path d="M18 26h64" fill="none" />
          <path d="M18 26L8 56h20z" />
          <path d="M82 26L72 56h20z" />
          <path d="M6 56a12 8 0 0 0 24 0z" fill={C.gold} />
          <path d="M70 56a12 8 0 0 0 24 0z" fill={C.gold} />
          <circle cx={50} cy={14} r={5} fill={C.gold} />
        </g>
      );
    case 'gavel':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round" strokeLinecap="round">
          <g transform="rotate(-35 50 40)">
            <rect x={26} y={20} width={48} height={24} rx={5} fill="#B5683A" />
            <rect x={22} y={18} width={8} height={28} rx={3} fill={C.gold} />
            <rect x={70} y={18} width={8} height={28} rx={3} fill={C.gold} />
            <rect x={46} y={44} width={8} height={44} rx={3} fill="#D9A15F" />
          </g>
          <rect x={20} y={82} width={60} height={10} rx={4} fill={CREAM} />
        </g>
      );
    case 'church':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round" fill={CREAM}>
          <rect x={26} y={48} width={48} height={42} />
          <path d="M26 48L50 28l24 20z" fill="#B5683A" />
          <rect x={44} y={6} width={12} height={26} />
          <path d="M50 -2v14M43 5h14" strokeLinecap="round" fill="none" />
          <path d="M42 90V70a8 8 0 0 1 16 0v20z" fill={N} />
        </g>
      );
    case 'parliament':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round" fill={CREAM}>
          <rect x={10} y={62} width={80} height={26} />
          <path d="M16 62V52h68v10z" />
          <path d="M34 52a16 16 0 0 1 32 0z" fill={C.gold} />
          <path d="M50 36V22" fill="none" strokeLinecap="round" />
          <path d="M50 22l10 4-10 4z" fill={C.blue} />
          <path d="M24 66v18M38 66v18M52 66v18M66 66v18M78 66v18" fill="none" />
        </g>
      );
    case 'ballot':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round" strokeLinecap="round">
          <rect x={14} y={46} width={72} height={42} rx={4} fill={C.blue} />
          <rect x={34} y={44} width={32} height={6} rx={2} fill={N} />
          <path d="M30 40V16h40v24z" fill={CREAM} />
          <path d="M38 28l6 6 12-12" fill="none" stroke={C.green} strokeWidth={5} />
        </g>
      );
    case 'coins':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round">
          <ellipse cx={36} cy={72} rx={24} ry={9} fill={C.gold} />
          <path d="M12 72v-10a24 9 0 0 0 48 0v10" fill="#E5B52B" />
          <ellipse cx={36} cy={62} rx={24} ry={9} fill={C.gold} />
          <path d="M40 54v-10a24 9 0 0 0 48 0v10" fill="#E5B52B" />
          <ellipse cx={64} cy={44} rx={24} ry={9} fill={C.gold} />
          <ellipse cx={64} cy={44} rx={13} ry={4} fill="none" />
        </g>
      );
    case 'pin':
      return (
        <g stroke={N} strokeWidth={sw} strokeLinejoin="round">
          <path d="M50 92C30 64 20 52 20 36a30 30 0 0 1 60 0c0 16-10 28-30 56z" fill={red ? C.red : C.gold} />
          <circle cx={50} cy={36} r={11} fill="#fff" />
        </g>
      );
    default:
      return null;
  }
};

export const Icon: React.FC<{kind: IconKind; size: number; red?: boolean; slash?: boolean}> = ({kind, size, red, slash}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible', filter: 'drop-shadow(0 5px 6px rgba(0,0,0,0.5))'}}>
    <Body kind={kind} red={red} />
    {slash ? (
      <g stroke={C.red} strokeWidth={9} strokeLinecap="round">
        <circle cx={50} cy={50} r={44} fill="none" />
        <path d="M18 82L82 18" />
      </g>
    ) : null}
  </svg>
);

// ---- end-card extras
export const HandIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible', filter: 'drop-shadow(0 4px 5px rgba(0,0,0,0.5))'}}>
    <g stroke={N} strokeWidth={3.5} strokeLinejoin="round" strokeLinecap="round" fill="#fff">
      <path d="M38 10a7 7 0 0 1 14 0v34h4a7 7 0 0 1 12 0 7 7 0 0 1 11 3 7 7 0 0 1 9 7v20c0 16-10 26-26 26H46c-10 0-16-6-22-16L14 66a6 6 0 0 1 10-6l8 8V10" />
    </g>
  </svg>
);
export const BellIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible', filter: 'drop-shadow(0 4px 5px rgba(0,0,0,0.5))'}}>
    <g stroke={N} strokeWidth={3.5} strokeLinejoin="round" strokeLinecap="round" fill={C.gold}>
      <path d="M50 10c-16 0-26 12-26 28 0 20-8 24-12 30h76c-4-6-12-10-12-30 0-16-10-28-26-28z" />
      <path d="M40 76a10 10 0 0 0 20 0z" fill="#E5B52B" />
    </g>
  </svg>
);

// ---- flag stand: hand-drawn pole + base, real flag (flag-icons) cut in strips so it waves
export const FLAG_STRIPS = 10;
