import {useEffect, useState} from 'react';
import {cancelRender, continueRender, delayRender, staticFile} from 'remotion';

const FACES: [string, string, string][] = [
  ['Inter', 'fonts/Inter-400.woff2', '400'],
  ['Inter', 'fonts/Inter-600.woff2', '600'],
  ['Inter', 'fonts/Inter-800.woff2', '800'],
  ['Comix', 'fonts/ComixLoud.ttf', '400'],
];

export const useFonts = (): boolean => {
  const [handle] = useState(() => delayRender('fonts'));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    Promise.all(
      FACES.map(async ([family, file, weight]) => {
        const ff = new FontFace(family, `url(${staticFile(file)})`, {weight});
        const loaded = await ff.load();
        (document.fonts as unknown as {add: (f: FontFace) => void}).add(loaded);
      }),
    )
      .then(() => {
        setReady(true);
        continueRender(handle);
      })
      .catch((e) => cancelRender(e)); // a missing font must FAIL the render loudly
  }, [handle]);
  return ready;
};

let ctx: CanvasRenderingContext2D | null = null;
export const measure = (text: string, family: 'Inter' | 'Comix', weight: number, size: number, spacing = 0): number => {
  if (!ctx) ctx = document.createElement('canvas').getContext('2d');
  if (!ctx) return text.length * size * 0.7;
  ctx.font = `${weight} ${size}px ${family}`;
  return ctx.measureText(text).width + spacing * text.length;
};
