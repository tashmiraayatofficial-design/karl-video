import React from 'react';
import {Img, spring, staticFile} from 'remotion';
import {BOTTOMS, Bottom, C, CHANNEL, END_S, FPS, HEROES, Hero, ROW_ICONS, RowIcon} from './config';
import {measure} from './fonts';
import {HandIcon, BellIcon, Icon} from './Icons';
import {clamp, eio3, eoExpo, fmtInt, prog} from './math';

const sp = (t: number, s: number, damping = 13, stiffness = 140) =>
  spring({frame: Math.max(0, (t - s) * FPS), fps: FPS, config: {damping, stiffness}});
const seg = new Intl.Segmenter('en', {granularity: 'grapheme'});
const graphemes = (s: string) => [...seg.segment(s)].map((x) => x.segment);

// ===================== hero text (top zone y 150-520, auto-fit to 880 px) =====================
const HERO_MAX = 118;
const heroSize = (h: Hero) => {
  let size = HERO_MAX;
  for (const l of h.lines) {
    const w = measure(l.t, 'Comix', 400, HERO_MAX, 3);
    if (w > 880) size = Math.min(size, (HERO_MAX * 880) / w);
  }
  return Math.floor(size);
};

export const HeroLayer: React.FC<{t: number}> = ({t}) => {
  const h = HEROES.find((x) => t >= x.s && t <= x.e);
  if (!h) return null;
  const size = heroSize(h);
  const out = prog(t, h.e - 0.28, h.e);
  return (
    <div style={{position: 'absolute', left: 100, top: 185, width: 880, opacity: 1 - out, transform: `translateY(${-out * 30}px)`, textAlign: 'center'}}>
      {h.lines.map((l, li) => {
        const chars = graphemes(l.t);
        const color = l.c === 'g' ? C.gold : C.white;
        return (
          <div key={li} style={{height: size * 1.4, whiteSpace: 'pre', fontFamily: 'Comix', fontSize: size, letterSpacing: 3, lineHeight: 1.4, color, WebkitTextStroke: `${Math.max(5, size * 0.065)}px ${C.navy}`, paintOrder: 'stroke fill', textShadow: l.c === 'g' ? '0 0 30px rgba(255,212,59,0.45)' : '0 0 24px rgba(0,0,0,0.55)'}}>
            {chars.map((ch, i) => {
              const p = clamp(sp(t, l.s + i * 0.035, 14, 170), 0, 1.1);
              const q = clamp(p, 0, 1);
              return (
                <span key={i} style={{display: 'inline-block', opacity: q, transform: `translateY(${(1 - q) * 34}px) scale(${0.8 + 0.2 * p})`, filter: q < 1 ? `blur(${(1 - q) * 6}px)` : undefined}}>
                  {ch === ' ' ? '\u00A0' : ch}
                </span>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

// ===================== bottom zone info (y 1350-1670) =====================
const panel: React.CSSProperties = {
  position: 'absolute', left: 120, width: 840, top: 1370, minHeight: 280, borderRadius: 34,
  background: 'rgba(7,18,31,0.78)', border: '3px solid rgba(255,255,255,0.18)', boxSizing: 'border-box',
  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '18px 30px',
};
const fit = (text: string, weight: number, base: number, maxW: number, ls = 1) => {
  const w = measure(text, 'Inter', weight, base, ls);
  return Math.floor(w > maxW ? (base * maxW) / w : base);
};

const fmtCounter = (b: Extract<Bottom, {k: 'counter'}>, v: number) =>
  b.fmt === 'money' ? '£' + fmtInt(v) : b.fmt === 'pct' ? Math.round(v) + '%' : b.fmt === 'x' ? Math.round(v) + '×' : fmtInt(v);

const BottomItem: React.FC<{b: Bottom; t: number}> = ({b, t}) => {
  const inn = sp(t, b.s, 14, 150);
  const out = prog(t, b.e - 0.25, b.e);
  const wrap: React.CSSProperties = {opacity: clamp(inn * 2, 0, 1) * (1 - out), transform: `translateY(${(1 - clamp(inn, 0, 1)) * 50 + out * 30}px)`};
  const txt: React.CSSProperties = {fontFamily: 'Inter', fontWeight: 800, textAlign: 'center', whiteSpace: 'nowrap'};
  if (b.k === 'pill') {
    const fs = fit(b.main, 800, 62, 770);
    return (
      <div style={{...wrap, position: 'absolute', left: 0, top: 0, width: 1080, height: 1920}}>
        <div style={{...panel, minHeight: b.sub ? 210 : 140, top: b.sub ? 1440 : 1480}}>
          <div style={{...txt, fontSize: fs, color: C.white, letterSpacing: 1}}>{b.main}</div>
          {b.sub ? <div style={{...txt, fontSize: 36, color: C.gold, marginTop: 8, letterSpacing: 1}}>{b.sub}</div> : null}
        </div>
      </div>
    );
  }
  if (b.k === 'counter') {
    const v = b.to * eoExpo(prog(t, b.s + 0.15, b.s + 0.15 + b.dur));
    const num = fmtCounter(b, v);
    const fs = fit(fmtCounter(b, b.to), 800, 150, 740, 0);
    const postFs = b.post ? fit(b.post, 800, 40, 770) : 40;
    return (
      <div style={{...wrap, position: 'absolute', left: 0, top: 0, width: 1080, height: 1920}}>
        <div style={panel}>
          {b.pre ? <div style={{...txt, fontSize: 44, color: C.white, opacity: 0.92, letterSpacing: 3}}>{b.pre}</div> : null}
          <div style={{...txt, fontSize: fs, color: C.gold, lineHeight: 1.05, textShadow: '0 0 30px rgba(255,212,59,0.55)', fontVariantNumeric: 'tabular-nums'}}>{num}</div>
          {b.post ? <div style={{...txt, fontSize: postFs, color: C.white, letterSpacing: 1}}>{b.post}</div> : null}
        </div>
      </div>
    );
  }
  if (b.k === 'bars') {
    const mx = Math.max(...b.rows.map((r) => r.v));
    return (
      <div style={{...wrap, position: 'absolute', left: 0, top: 0, width: 1080, height: 1920}}>
        <div style={{...panel, alignItems: 'stretch', padding: '14px 34px'}}>
          <div style={{...txt, fontSize: 32, color: C.gold, marginBottom: 6, letterSpacing: 3}}>{b.title}</div>
          {b.rows.map((r, i) => {
            const g = eoExpo(prog(t, b.s + 0.25 + i * 0.2, b.s + 1.35 + i * 0.2));
            return (
              <div key={i} style={{display: 'flex', alignItems: 'center', height: 90}}>
                <div style={{...txt, width: 210, textAlign: 'left', fontSize: 40, color: C.white}}>{r.label}</div>
                <div style={{position: 'relative', width: 430, height: 58, borderRadius: 29, background: 'rgba(255,255,255,0.12)'}}>
                  <div style={{position: 'absolute', left: 0, top: 0, height: 58, width: (r.v / mx) * 430 * g, borderRadius: 29, background: r.c, boxShadow: `0 0 18px ${r.c}`}} />
                </div>
                <div style={{...txt, width: 130, textAlign: 'right', fontSize: 58, color: C.gold}}>{Math.round(r.v * g)}</div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
  if (b.k === 'chips') {
    return (
      <div style={{...wrap, transform: undefined, position: 'absolute', left: 0, top: 1470, width: 1080, display: 'flex', justifyContent: 'center', gap: 16, opacity: 1 - out}}>
        {b.items.map((c, i) => {
          const p = clamp(sp(t, c.s, 11, 170), 0, 1.15);
          return (
            <div key={i} style={{...txt, fontSize: 46, color: c.c === C.gold ? C.navy : C.white, background: c.c === C.gold ? C.gold : 'rgba(7,18,31,0.85)', border: `4px solid ${C.gold}`, borderRadius: 40, padding: '14px 28px', transform: `scale(${p})`, opacity: clamp(p * 2, 0, 1)}}>
              {c.t}
            </div>
          );
        })}
      </div>
    );
  }
  if (b.k === 'flagcard') {
    const rot = Math.sin(t * 2.2) * 1.6;
    return (
      <div style={{...wrap, position: 'absolute', left: 0, top: 0, width: 1080, height: 1920}}>
        <div style={{position: 'absolute', left: 540 - 200, top: 1380, width: 400, height: 300, borderRadius: 14, border: '8px solid #fff', boxShadow: '0 14px 30px rgba(0,0,0,0.6)', overflow: 'hidden', transform: `rotate(${rot}deg)`, boxSizing: 'border-box'}}>
          <Img src={staticFile(`flags/${b.iso}.svg`)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
        </div>
      </div>
    );
  }
  // timeline
  const pr = eio3(prog(t, b.ta, b.tb));
  const year = Math.round(b.a + (b.b - b.a) * pr);
  const x0 = 170;
  const x1 = 910;
  const cx = x0 + (x1 - x0) * pr;
  return (
    <div style={{...wrap, position: 'absolute', left: 0, top: 0, width: 1080, height: 1920}}>
      <div style={{...panel, minHeight: 230, top: 1410}} />
      <div style={{position: 'absolute', left: x0, top: 1585, width: x1 - x0, height: 10, borderRadius: 5, background: 'rgba(255,255,255,0.25)'}} />
      <div style={{position: 'absolute', left: x0, top: 1585, width: (x1 - x0) * pr, height: 10, borderRadius: 5, background: C.gold, boxShadow: `0 0 14px ${C.gold}`}} />
      {[x0, x1].map((x, i) => (
        <div key={i} style={{position: 'absolute', left: x - 12, top: 1578, width: 24, height: 24, borderRadius: 12, background: C.white, border: `4px solid ${C.navy}`, boxSizing: 'border-box'}} />
      ))}
      <div style={{position: 'absolute', left: cx - 18, top: 1572, width: 36, height: 36, borderRadius: 18, background: C.gold, border: `4px solid ${C.navy}`, boxSizing: 'border-box'}} />
      <div style={{position: 'absolute', left: cx - 100, top: 1450, width: 200, textAlign: 'center', fontFamily: 'Inter', fontWeight: 800, fontSize: 80, color: C.gold, textShadow: '0 0 24px rgba(255,212,59,0.5)'}}>{year}</div>
      <div style={{position: 'absolute', left: x0 - 70, top: 1620, width: 140, textAlign: 'center', fontFamily: 'Inter', fontWeight: 800, fontSize: 34, color: C.white}}>{b.a}</div>
      <div style={{position: 'absolute', left: x1 - 70, top: 1620, width: 140, textAlign: 'center', fontFamily: 'Inter', fontWeight: 800, fontSize: 34, color: C.white}}>{b.b}</div>
    </div>
  );
};

export const BottomLayer: React.FC<{t: number}> = ({t}) => (
  <>
    {BOTTOMS.filter((b) => t >= b.s - 0.02 && t <= b.e).map((b, i) => (
      <BottomItem key={i} b={b} t={t} />
    ))}
  </>
);

// ===================== abstract icon row (y ~1235, inside the middle zone) =====================
interface Placed extends RowIcon {x: number}
const placed: Placed[] = (() => {
  const sorted = [...ROW_ICONS].sort((a, b) => a.s - b.s);
  const groups: RowIcon[][] = [];
  for (const it of sorted) {
    const g = groups[groups.length - 1];
    if (g && it.s < Math.max(...g.map((x) => x.e))) g.push(it);
    else groups.push([it]);
  }
  const out: Placed[] = [];
  for (const g of groups) g.forEach((it, i) => out.push({...it, x: 540 + (i - (g.length - 1) / 2) * 250}));
  return out;
})();

export const RowIcons: React.FC<{t: number}> = ({t}) => (
  <>
    {placed.filter((p) => t >= p.s - 0.02 && t <= p.e).map((p, i) => {
      const k = clamp(sp(t, p.s, 11, 150), 0, 1.15);
      const out = prog(t, p.e - 0.2, p.e);
      return (
        <div key={i} style={{position: 'absolute', left: p.x - 90, top: 1130, width: 180, textAlign: 'center', opacity: clamp(k * 2, 0, 1) * (1 - out), transform: `scale(${(0.6 + 0.4 * k) * (1 - 0.3 * out)})`, transformOrigin: '50% 80%'}}>
          <div style={{display: 'flex', justifyContent: 'center', transform: `translateY(${Math.sin(t * 3 + i) * 4}px)`}}>
            <Icon kind={p.kind} size={150} slash={p.slash} />
          </div>
          {p.caption ? <div style={{fontFamily: 'Inter', fontWeight: 800, fontSize: 34, color: C.white, letterSpacing: 1.5, textShadow: '0 2px 8px rgba(0,0,0,0.9), 0 0 3px #000', whiteSpace: 'nowrap', marginTop: 4}}>{p.caption}</div> : null}
        </div>
      );
    })}
  </>
);

// ===================== end card: SUBSCRIBE (YouTube) + FOLLOW (Facebook), hand-drawn, no logos =====================
export const EndCard: React.FC<{t: number}> = ({t}) => {
  if (t < END_S) return null;
  const tap1 = END_S + 0.95;
  const tap2 = END_S + 1.7;
  const btn = (label: string, name: string, cy: number, t0: number, tap: number) => {
    const k = clamp(sp(t, t0, 12, 150), 0, 1.12);
    const tapped = t > tap;
    const press = tapped && t < tap + 0.18 ? 0.93 : 1;
    const h = name ? 132 : 112;
    return (
      <div style={{position: 'absolute', left: 260, top: cy - h / 2, width: 560, height: h, borderRadius: h / 2, background: tapped ? C.gold : C.blue, border: `5px solid ${C.white}`, boxSizing: 'border-box', boxShadow: '0 10px 26px rgba(0,0,0,0.55)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', transform: `scale(${k * press})`, opacity: clamp(k * 2, 0, 1)}}>
        <div style={{fontFamily: 'Inter', fontWeight: 800, fontSize: 52, letterSpacing: 3, color: tapped ? C.navy : C.white}}>{label}</div>
        {name ? <div style={{fontFamily: 'Inter', fontWeight: 600, fontSize: 28, color: tapped ? C.navy : C.white, marginTop: -2}}>{name}</div> : null}
      </div>
    );
  };
  const y1 = 1470;
  const y2 = 1610;
  const handT = t < tap1 + 0.3 ? prog(t, END_S + 0.55, tap1) : prog(t, tap1 + 0.35, tap2);
  const fromY = t < tap1 + 0.3 ? 1760 : y1;
  const toY = t < tap1 + 0.3 ? y1 : y2;
  const hx = 660 + (1 - eio3(handT)) * 140;
  const hy = fromY + (toY - fromY) * eio3(handT) + 40;
  const bellT = t - (tap1 + 0.1);
  const wig = bellT > 0 ? Math.sin(bellT * 22) * 22 * Math.exp(-bellT * 2.2) : 0;
  const bellK = clamp(sp(t, END_S + 0.15, 12, 150), 0, 1.1);
  return (
    <>
      {btn('SUBSCRIBE', CHANNEL.youtube, y1, END_S + 0.05, tap1)}
      {btn('FOLLOW', CHANNEL.facebook, y2, END_S + 0.45, tap2)}
      <div style={{position: 'absolute', left: 840, top: y1 - 45, width: 90, height: 90, transform: `scale(${bellK}) rotate(${wig}deg)`, transformOrigin: '50% 10%'}}>
        <BellIcon size={90} />
      </div>
      <div style={{position: 'absolute', left: hx, top: hy, opacity: clamp(handT * 3, 0, 1), transform: `scale(${t > tap1 && t < tap1 + 0.15 || t > tap2 && t < tap2 + 0.15 ? 0.88 : 1})`}}>
        <HandIcon size={110} />
      </div>
    </>
  );
};
