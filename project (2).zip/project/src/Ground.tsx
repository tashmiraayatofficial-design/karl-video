import React from 'react';
import {C, HLS, Hl, PULSES, REG, ROUTES} from './config';
import {PH, PW, Projector, clamp, eio3, prog} from './math';

// ---------- shared helpers
export const vis = (t: number, s: number, e: number, outDur = 0.3) => (t < s ? 0 : t > e ? 0 : 1 - prog(t, e - outDur, e));

const ringD = (proj: Projector, ring: number[][], reverse = false) => {
  const pts = reverse ? [...ring].reverse() : ring;
  let d = '';
  for (let i = 0; i < pts.length; i++) {
    const q = proj.plane(pts[i][0], pts[i][1]);
    d += (i ? 'L' : 'M') + q.x.toFixed(1) + ' ' + q.y.toFixed(1);
  }
  return d;
};

interface RegionPaths {rings: string[]; rev: string[]; all: string}
const regionPaths = (proj: Projector, id: string, cache: Map<string, RegionPaths>): RegionPaths => {
  const hit = cache.get(id);
  if (hit) return hit;
  const rings = REG[id].rings.map((r) => ringD(proj, r));
  const rev = REG[id].rings.map((r) => ringD(proj, r, true));
  const out = {rings, rev, all: rings.map((r) => r + 'Z').join('')};
  cache.set(id, out);
  return out;
};

const chaikin = (pts: {x: number; y: number}[], n: number) => {
  let p = pts;
  for (let k = 0; k < n; k++) {
    const q = [p[0]];
    for (let i = 0; i < p.length - 1; i++) {
      q.push({x: 0.75 * p[i].x + 0.25 * p[i + 1].x, y: 0.75 * p[i].y + 0.25 * p[i + 1].y});
      q.push({x: 0.25 * p[i].x + 0.75 * p[i + 1].x, y: 0.25 * p[i].y + 0.75 * p[i + 1].y});
    }
    q.push(p[p.length - 1]);
    p = q;
  }
  return p;
};

export interface RouteState {
  d: string; alpha: number; dashed: boolean; color: string; head: 'ship' | 'arrow' | undefined;
  hx: number; hy: number; ang: number; p: number;
}
export const routeStates = (proj: Projector, t: number): RouteState[] => {
  const out: RouteState[] = [];
  for (const r of ROUTES) {
    if (t < r.s || t > r.e) continue;
    const alpha = 1 - prog(t, r.e - 0.3, r.e);
    const p = eio3(prog(t, r.s, r.s + r.d));
    const base = chaikin(r.pts.map((q) => proj.plane(q[0], q[1])), 3);
    const lens: number[] = [0];
    for (let i = 1; i < base.length; i++) lens.push(lens[i - 1] + Math.hypot(base[i].x - base[i - 1].x, base[i].y - base[i - 1].y));
    const total = lens[lens.length - 1];
    const target = total * p;
    let d = `M${base[0].x.toFixed(1)} ${base[0].y.toFixed(1)}`;
    let hx = base[0].x;
    let hy = base[0].y;
    let ang = 0;
    for (let i = 1; i < base.length; i++) {
      if (lens[i] <= target) {
        d += `L${base[i].x.toFixed(1)} ${base[i].y.toFixed(1)}`;
        hx = base[i].x;
        hy = base[i].y;
        ang = Math.atan2(base[i].y - base[i - 1].y, base[i].x - base[i - 1].x);
      } else {
        const f = (target - lens[i - 1]) / Math.max(1e-6, lens[i] - lens[i - 1]);
        hx = base[i - 1].x + (base[i].x - base[i - 1].x) * f;
        hy = base[i - 1].y + (base[i].y - base[i - 1].y) * f;
        ang = Math.atan2(base[i].y - base[i - 1].y, base[i].x - base[i - 1].x);
        d += `L${hx.toFixed(1)} ${hy.toFixed(1)}`;
        break;
      }
    }
    out.push({d, alpha, dashed: !!r.dashed, color: r.color, head: r.head, hx, hy, ang, p});
  }
  return out;
};

// ---------- ground layer (lies flat in the tilted plane)
export const GroundLayer: React.FC<{proj: Projector; t: number}> = ({proj, t}) => {
  const cache = new Map<string, RegionPaths>();
  const act = HLS.filter((h) => t >= h.s - 0.01 && t <= h.e);

  // dim everything except active L1 regions
  const l1 = act.filter((h) => h.mode === 'L1');
  let dimAlpha = 0;
  const holes = new Set<string>();
  for (const h of l1) {
    const a = clamp(prog(t, h.s, h.s + 0.6), 0, 1) * (1 - prog(t, h.e - 0.3, h.e));
    dimAlpha = Math.max(dimAlpha, a * 0.4);
    h.regions.forEach((r) => holes.add(r));
  }
  const BIG = 60000;
  const dimD = `M${-BIG} ${-BIG}H${BIG}V${BIG}H${-BIG}Z` + [...holes].map((r) => regionPaths(proj, r, cache).all).join('');

  const hlLayers = act.map((h: Hl) => {
    const exit = 1 - prog(t, h.e - 0.3, h.e);
    return (
      <g key={h.id} opacity={exit}>
        {h.regions.map((reg, i) => {
          const rp = regionPaths(proj, reg, cache);
          let po: number;
          let fillA: number;
          if (h.mode === 'L1') {
            po = eio3(prog(t, h.s, h.s + 0.9));
            fillA = 0.3 * prog(t, h.s + 0.6, h.s + 1.1);
          } else if (h.mode === 'L2') {
            po = eio3(prog(t, h.s, h.s + 0.35));
            fillA = 0.34 * prog(t, h.s + 0.1, h.s + 0.25);
          } else {
            const d0 = h.s + i * 0.1;
            po = eio3(prog(t, d0, d0 + 0.6));
            fillA = 0.3 * prog(t, d0 + 0.2, d0 + 0.7);
          }
          const flash = h.mode === 'L2' ? 0.55 * (1 - prog(t, h.s + 0.1, h.s + 0.35)) * (t > h.s + 0.1 ? 1 : 0) : 0;
          const glitch = h.mode === 'L2' && t < h.s + 0.22 ? 1 - prog(t, h.s, h.s + 0.22) : 0;
          return (
            <g key={reg}>
              <path d={rp.all} fill={h.color} fillOpacity={fillA} fillRule="evenodd" />
              {flash > 0 ? <path d={rp.all} fill="#fff" fillOpacity={flash} fillRule="evenodd" /> : null}
              {rp.rings.map((d, k) => (
                <g key={k} fill="none" strokeLinejoin="round" strokeLinecap="round">
                  {[false, true].map((rev) => (
                    <React.Fragment key={String(rev)}>
                      <path d={rev ? rp.rev[k] : d} pathLength={1000} stroke={h.color} strokeOpacity={0.35} strokeWidth={16} strokeDasharray={`${po * 500} 1000`} />
                      <path d={rev ? rp.rev[k] : d} pathLength={1000} stroke={h.color} strokeWidth={4.5} strokeDasharray={`${po * 500} 1000`} />
                    </React.Fragment>
                  ))}
                  {glitch > 0 ? (
                    <>
                      <path d={d} stroke="#ff2b4d" strokeWidth={4} strokeOpacity={glitch} transform="translate(6 0)" />
                      <path d={d} stroke="#22e4ff" strokeWidth={4} strokeOpacity={glitch} transform="translate(-6 0)" />
                    </>
                  ) : null}
                </g>
              ))}
            </g>
          );
        })}
      </g>
    );
  });

  const rs = routeStates(proj, t);
  const pulses = PULSES.filter((p) => t >= p.s && t <= p.e).map((p, i) => {
    const c = proj.plane(p.lon, p.lat);
    const a = vis(t, p.s, p.e, 0.3);
    const ph = ((t - p.s) % 1.2) / 1.2;
    return (
      <g key={i} opacity={a} fill="none" stroke={p.color}>
        {[0, 0.5].map((o) => {
          const q = (ph + o) % 1;
          return <circle key={o} cx={c.x} cy={c.y} r={30 + q * 150} strokeWidth={6} strokeOpacity={0.9 * (1 - q)} />;
        })}
      </g>
    );
  });

  return (
    <svg width={PW} height={PH} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
      {dimAlpha > 0 ? <path d={dimD} fill="#02070f" fillOpacity={dimAlpha} fillRule="evenodd" /> : null}
      {hlLayers}
      {rs.map((r, i) => (
        <g key={i} opacity={r.alpha} fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d={r.d} stroke={C.yellow} strokeOpacity={0.35} strokeWidth={26} />
          <path d={r.d} stroke={r.color} strokeWidth={11} strokeDasharray={r.dashed ? '30 22' : undefined} />
          {r.head === 'arrow' ? (
            <g transform={`translate(${r.hx} ${r.hy}) rotate(${(r.ang * 180) / Math.PI})`}>
              <path d="M-6 -26L38 0L-6 26Z" fill={r.color} stroke={C.navy} strokeWidth={3} />
            </g>
          ) : null}
        </g>
      ))}
      {pulses}
    </svg>
  );
};
