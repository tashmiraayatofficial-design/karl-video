import React from 'react';
import {Img, spring, staticFile} from 'remotion';
import {C, FPS, HLS, MAP_ICONS, PULSES, REG} from './config';
import {FLAG_STRIPS, Icon} from './Icons';
import {measure} from './fonts';
import {Projector, clamp, prog} from './math';
import {routeStates, vis} from './Ground';

const sp = (t: number, s: number) =>
  spring({frame: Math.max(0, (t - s) * FPS), fps: FPS, config: {damping: 12, stiffness: 130}});

const onScreen = (x: number, y: number) => x > -120 && x < 1200 && y > -120 && y < 2040;

// ---- flag stand: hand-drawn pole + base; the flag is the real flag-icons SVG cut into strips (waves)
const FlagStand: React.FC<{x: number; y: number; s: number; iso: string; t: number; t0: number; t1: number}> = ({x, y, s, iso, t, t0, t1}) => {
  const ms = clamp(s, 0.6, 1.3);
  const ph = 130 * ms; // pole height on screen: 78..169
  const fh = ph * 0.55;
  const fw = (fh * 4) / 3;
  const grow = sp(t, t0);
  const out = prog(t, t1 - 0.2, t1);
  const k = clamp(grow, 0, 1.05) * (1 - out);
  const sw = fw / FLAG_STRIPS;
  const strips = [];
  for (let i = 0; i < FLAG_STRIPS; i++) {
    const dy = Math.sin(t * 5.5 + i * 0.75) * 3.2 * (0.25 + i / FLAG_STRIPS);
    strips.push(
      <div key={i} style={{position: 'absolute', left: 4 + i * sw, top: dy, width: sw + 0.7, height: fh, overflow: 'hidden'}}>
        <Img src={staticFile(`flags/${iso}.svg`)} style={{position: 'absolute', left: -i * sw, top: 0, width: fw, height: fh}} />
      </div>,
    );
  }
  return (
    <div style={{position: 'absolute', left: x, top: y, width: 0, height: 0, opacity: clamp(k * 3, 0, 1)}}>
      <div style={{position: 'absolute', left: -fw / 2 - 4, top: -ph, width: fw + 8, height: ph, transformOrigin: `${fw / 2 + 4}px ${ph}px`, transform: `scale(${k})`}}>
        <div style={{position: 'absolute', left: fw / 2, top: 0, width: 7, height: ph, background: '#EDEDED', border: `2px solid ${C.navy}`, borderRadius: 4, boxSizing: 'border-box'}} />
        <div style={{position: 'absolute', left: fw / 2 - 2, top: -6, width: 11, height: 11, background: C.gold, border: `2px solid ${C.navy}`, borderRadius: 6, boxSizing: 'border-box'}} />
        <div style={{position: 'absolute', left: fw / 2 + 5, top: 6, width: fw + 8, height: fh + 8, border: 'none'}}>{strips}</div>
      </div>
      <div style={{position: 'absolute', left: -26 * ms, top: -8 * ms, width: 52 * ms, height: 16 * ms, borderRadius: '50%', background: 'rgba(0,0,0,0.55)', border: `3px solid ${C.navy}`, boxSizing: 'border-box', transform: `scale(${k})`}} />
    </div>
  );
};

// ---- place-name label with leader line, clamped into the middle zone and the safe box
const PlaceLabel: React.FC<{ax: number; ay: number; text: string; color: string; dx: number; dy: number; small?: boolean; t: number; t0: number; t1: number}> = ({ax, ay, text, color, dx, dy, small, t, t0, t1}) => {
  const fs = small ? 32 : 36;
  const w = measure(text, 'Inter', 800, fs, 1.5) + 50;
  const h = fs + 28;
  const cx = clamp(ax + dx, 100 + w / 2, 980 - w / 2);
  const cy = clamp(ay + dy, 560 + h / 2, 1330 - h / 2);
  const inn = sp(t, t0);
  const out = prog(t, t1 - 0.2, t1);
  const op = clamp(inn * 2, 0, 1) * (1 - out);
  return (
    <div style={{position: 'absolute', left: 0, top: 0, opacity: op}}>
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <line x1={ax} y1={ay} x2={cx} y2={cy} stroke={color} strokeWidth={4} strokeLinecap="round" />
        <circle cx={ax} cy={ay} r={7} fill={color} stroke={C.navy} strokeWidth={3} />
      </svg>
      <div style={{position: 'absolute', left: cx - w / 2, top: cy - h / 2 + (1 - inn) * 24, width: w, height: h, borderRadius: h / 2, background: 'rgba(7,18,31,0.88)', border: `4px solid ${color}`, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Inter', fontWeight: 800, fontSize: fs, letterSpacing: 1.5, color: C.white, whiteSpace: 'nowrap'}}>
        {text}
      </div>
    </div>
  );
};

export const Uprights: React.FC<{proj: Projector; t: number}> = ({proj, t}) => {
  const nodes: React.ReactNode[] = [];
  for (const h of HLS) {
    if (h.flag && t >= h.flag.s - 0.05 && t <= h.flag.e) {
      const [lon, lat] = REG[h.flag.region].label;
      const a = proj.screen(lon, lat);
      if (onScreen(a.x, a.y)) nodes.push(<FlagStand key={h.id + '-f'} x={a.x} y={a.y} s={a.s} iso={h.flag.iso} t={t} t0={h.flag.s} t1={h.flag.e} />);
    }
    if (h.label && t >= h.label.s - 0.05 && t <= h.label.e) {
      const [lon, lat] = REG[h.label.region].label;
      const a = proj.screen(lon, lat);
      if (onScreen(a.x, a.y)) nodes.push(<PlaceLabel key={h.id + '-l'} ax={a.x} ay={a.y} text={h.label.text} color={h.color} dx={h.label.dx} dy={h.label.dy} small={h.label.small} t={t} t0={h.label.s} t1={h.label.e} />);
    }
  }
  MAP_ICONS.forEach((m, i) => {
    if (t < m.s - 0.05 || t > m.e) return;
    const a = proj.screen(m.lon, m.lat);
    if (!onScreen(a.x, a.y)) return;
    const ms = clamp(a.s, 0.6, 1.3);
    const size = m.size * ms;
    const k = clamp(sp(t, m.s), 0, 1.15) * (1 - prog(t, m.e - 0.2, m.e));
    const bob = Math.sin(t * 3 + i) * 4;
    const ringP = ((t - m.s) % 1.2) / 1.2;
    nodes.push(
      <div key={'mi' + i} style={{position: 'absolute', left: a.x + (m.dx ?? 0) - size / 2, top: a.y + (m.dy ?? 0) - size + bob, width: size, height: size, transform: `scale(${0.6 + 0.4 * k})`, opacity: clamp(k * 2, 0, 1), transformOrigin: '50% 100%'}}>
        {m.red ? (
          <div style={{position: 'absolute', left: -size * 0.1, top: size * 0.62, width: size * 1.2, height: size * 0.42, borderRadius: '50%', border: `5px solid ${C.red}`, opacity: 1 - ringP, transform: `scale(${0.5 + ringP})`, boxSizing: 'border-box'}} />
        ) : null}
        <Icon kind={m.kind} size={size} red={m.red} />
      </div>,
    );
  });
  // ship at the head of the sea route
  routeStates(proj, t).forEach((r, i) => {
    if (r.head !== 'ship') return;
    const a = proj.fromPlane(r.hx, r.hy);
    const size = 120 * clamp(a.s, 0.6, 1.3);
    nodes.push(
      <div key={'ship' + i} style={{position: 'absolute', left: a.x - size / 2, top: a.y - size * 0.8 + Math.sin(t * 4) * 4, width: size, height: size, opacity: r.alpha}}>
        <Icon kind="ship" size={size} />
      </div>,
    );
  });
  // London pin + label
  PULSES.forEach((p, i) => {
    if (!p.pin || t < p.s || t > p.e) return;
    const a = proj.screen(p.lon, p.lat);
    const size = 110 * clamp(a.s, 0.6, 1.3);
    const k = clamp(sp(t, p.s), 0, 1.1) * (1 - prog(t, p.e - 0.2, p.e));
    nodes.push(
      <div key={'pin' + i} style={{position: 'absolute', left: a.x - size / 2, top: a.y - size + Math.sin(t * 4) * 3, width: size, height: size, opacity: clamp(k * 2, 0, 1), transform: `scale(${0.6 + 0.4 * k})`, transformOrigin: '50% 100%'}}>
        <Icon kind="pin" size={size} />
      </div>,
    );
    if (p.label)
      nodes.push(<PlaceLabel key={'pl' + i} ax={a.x} ay={a.y} text={p.label} color={p.color} dx={170} dy={30} small t={t} t0={p.s} t1={p.e} />);
  });
  return <>{nodes}</>;
};

export {vis};
