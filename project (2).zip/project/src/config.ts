import srt from './srt.json';
import regionsJson from '../public/data/regions.json';
import type {CamKey} from './math';

// ======================= basics =======================
export const W = 1080;
export const H = 1920;
export const FPS = 30;
export const INCLUDE_VOICEOVER = false; // render has quiet SFX only (set true only if asked)
export const SHOW_CAPTIONS = false; // NEVER print the narration (kept behind a flag, default OFF)
export const CHANNEL = {youtube: '', facebook: ''}; // names for the end card (empty = no name)
export const TILE_MAX_Z = 12;
// Esri World Imagery (closest to the reference look). Swap here for EOX / Mapbox if needed.
export const TILE_URL = (z: number, x: number, y: number) =>
  `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`;
export const CREDIT = 'Imagery © Esri · Borders: Natural Earth · Flags: flag-icons';

export const C = {
  navy: '#07121F', white: '#FFFFFF', yellow: '#FFE81A', green: '#3DFF7A', red: '#D3151C',
  redDark: '#6E0A0E', amber: '#FFB020', blue: '#2F6BFF', gold: '#FFD43B', teal: '#19E3B1',
  violet: '#9B6BFF', pink: '#FF5DA2', sky: '#33C4FF', lime: '#A6E22E',
};
export const RC: Record<string, string> = {
  usa: C.sky, england: C.teal, scotland: C.amber, wales: C.blue, nireland: C.violet,
  ireland: C.lime, panama: C.pink,
};

// ======================= SRT (the only timing source) =======================
interface SrtWord {w: string; s: number; e: number; cue: number}
interface SrtCue {i: number; s: number; e: number; text: string}
const words = srt.words as SrtWord[];
const cues = srt.cues as SrtCue[];
const norm = (s: string) => s.toLowerCase().replace(/[,.?!]/g, '');
export const wordTime = (w: string, nth = 1): number => {
  let n = 0;
  for (const x of words) {
    if (norm(x.w) === norm(w)) {
      n++;
      if (n === nth) return x.s;
    }
  }
  throw new Error(`word not found in SRT: ${w} #${nth}`);
};
export const cueStart = (i: number): number => {
  const c = cues.find((q) => q.i === i);
  if (!c) throw new Error('cue ' + i);
  return c.s;
};
const LEAD = 0.2; // visuals start 0.2 s before the spoken word
const A = (w: string, nth = 1, off = -LEAD) => wordTime(w, nth) + off;
const Q = (i: number, off = 0) => cueStart(i) + off;

export const CUES = cues;
export const VOICE_END = cues[cues.length - 1].e;
export const END_CARD_S = 2.5;
export const DURATION_S = VOICE_END + END_CARD_S;
export const DURATION = Math.round(DURATION_S * FPS);
export const END_S = VOICE_END; // end card starts when the voice ends

export const REG = regionsJson as unknown as Record<string, {rings: number[][][]; label: [number, number]}>;

// ======================= highlights =======================
export type Mode = 'L1' | 'L2' | 'L3';
export interface Hl {
  id: string; regions: string[]; color: string; mode: Mode; s: number; e: number;
  label?: {text: string; region: string; s: number; e: number; dx: number; dy: number; small?: boolean};
  flag?: {iso: string; region: string; s: number; e: number};
}
interface HOpt {
  label?: string; ls?: number; le?: number; lx?: number; ly?: number; lregion?: string;
  flag?: string; fs?: number; fe?: number; fregion?: string; small?: boolean;
}
const LBL: Record<string, [number, number]> = {
  england: [130, 80], scotland: [-190, 40], wales: [-200, 60], nireland: [-230, 20],
  ireland: [-200, 50], usa: [0, 80], panama: [0, 90],
};
const H1 = (id: string, regions: string[], color: string, mode: Mode, s: number, e: number, o: HOpt = {}): Hl => {
  const lr = o.lregion ?? regions[0];
  const hl: Hl = {id, regions, color, mode, s, e};
  if (o.label) {
    const d = LBL[lr] ?? [0, 80];
    hl.label = {text: o.label, region: lr, s: o.ls ?? s, e: o.le ?? e, dx: o.lx ?? d[0], dy: o.ly ?? d[1], small: o.small};
  }
  if (o.flag) hl.flag = {iso: o.flag, region: o.fregion ?? regions[0], s: o.fs ?? s + 0.6, e: o.fe ?? e};
  return hl;
};

const four = (id: string, t0: number, t1: number, stands: {eng: [number, number]; sct: [number, number]; wal?: [number, number]}): Hl[] => [
  H1(id + '-e', ['england'], C.teal, 'L2', t0, t1, {flag: 'gb-eng', fs: stands.eng[0], fe: stands.eng[1]}),
  H1(id + '-s', ['scotland'], C.amber, 'L2', t0 + 0.16, t1, {flag: 'gb-sct', fs: stands.sct[0], fe: stands.sct[1]}),
  H1(id + '-w', ['wales'], C.blue, 'L2', t0 + 0.32, t1, stands.wal ? {flag: 'gb-wls', fs: stands.wal[0], fe: stands.wal[1]} : {}),
  H1(id + '-n', ['nireland'], C.violet, 'L2', t0 + 0.48, t1),
];

const SO = A('So'); // end of the opening scene
const T_FOUR1 = A('four', 1, -0.3);
const T_FOUR2 = A('four', 2, -0.35);
const T_FOUR3 = Q(96, -0.4); // "In spirit, four nations"
const T_LEGAL = A('Legally');

export const HLS: Hl[] = [
  H1('usa', ['usa'], RC.usa, 'L1', A('America'), A('America') + 1.5, {label: 'AMERICA', flag: 'us'}),
  H1('eng-a', ['england'], RC.england, 'L2', A('England', 1), SO, {label: 'ENGLAND', flag: 'gb-eng', fs: A('England', 1) + 0.15}),
  H1('sct-a', ['scotland'], RC.scotland, 'L2', A('Scotland', 1), SO, {label: 'SCOTLAND', flag: 'gb-sct', fs: A('Scotland', 1) + 0.15}),
  H1('uk-a', ['england', 'scotland', 'wales', 'nireland'], C.green, 'L3', A('United'), A('four', 1, 0), {label: 'UNITED KINGDOM', lregion: 'england', lx: 150, ly: 110, flag: 'gb', fregion: 'england', fs: A('United') + 0.9, fe: T_FOUR1}),
  ...four('f1', T_FOUR1, A('Start') + 0.3, {eng: [T_FOUR1 + 0.3, A('Start') + 0.3], sct: [T_FOUR1 + 0.4, A('Start') + 0.3]}),
  H1('wal-1', ['wales'], RC.wales, 'L1', A('Wales', 1), A('England', 2, -0.1), {label: 'WALES', le: A('Edward') + 0.0, flag: 'gb-wls', fs: A('Wales', 1) + 0.2}),
  H1('eng-m', ['england'], RC.england, 'L1', A('England', 2), Q(28, 0.05), {flag: 'gb-eng', fs: A('England', 2) + 0.2}),
  H1('sct-m', ['scotland'], RC.scotland, 'L1', A('Scotland', 2), A('colony') + 0.3, {label: 'SCOTLAND', le: A('colony') - 0.3, flag: 'gb-sct', fs: A('Scotland', 2) + 0.5}),
  H1('pan', ['panama'], RC.panama, 'L1', A('Panama', 1, -0.3), A('capital') + 0.0, {label: 'PANAMA', le: A('about', 1, -0.3), flag: 'pa', fs: A('Panama', 1, 0.3)}),
  H1('eng-o', ['england'], RC.england, 'L1', A('England', 3), Q(41, -0.1), {label: 'ENGLAND', le: A('398,085', 1, 0.0), flag: 'gb-eng', fs: A('England', 3) + 0.4}),
  H1('sct-o', ['scotland'], RC.scotland, 'L1', Q(41, -0.2), Q(45, -0.1), {label: 'SCOTLAND', le: A('laws', 1, -0.5), flag: 'gb-sct', fs: Q(41, 0.4)}),
  H1('ire-1', ['ireland'], RC.ireland, 'L1', Q(45, -0.2), A('UK', 1, -0.3), {label: 'IRELAND', le: A('1800', 1, -0.2), flag: 'ie', fs: Q(45, 0.4)}),
  H1('uk-b', ['england', 'scotland', 'wales', 'nireland'], C.green, 'L3', A('UK', 1, -0.2), A('Today', 1, -0.3), {label: 'UNITED KINGDOM', lregion: 'england', lx: 150, ly: 110, le: A('1801', 1, 0.6), flag: 'gb', fregion: 'england', fs: A('UK', 1, 0.3), fe: A('1801', 1, 0.8)}),
  H1('ire-b', ['ireland'], C.green, 'L3', A('UK', 1, -0.2), A('most', 1, -0.2)),
  H1('ire-2', ['ireland'], RC.ireland, 'L1', A('most', 1, -0.2), A('Today', 1, -0.3), {label: 'IRELAND', le: A('Northern', 1, -0.3), flag: 'ie', fs: A('most', 1, 0.2), fe: A('Northern', 1, -0.2)}),
  H1('ni-1', ['nireland'], RC.nireland, 'L1', A('Northern', 1), A('Today', 1, -0.3), {label: 'NORTHERN IRELAND'}),
  H1('uk-c', ['england', 'scotland', 'wales', 'nireland'], C.green, 'L3', A('UK', 2), A('Scotland', 4), {flag: 'gb', fregion: 'england', fs: A('UK', 2) + 0.5, fe: A('three', 1, 0.8)}),
  H1('sct-p', ['scotland'], RC.scotland, 'L2', A('Scotland', 4), A('England', 4), {label: 'SCOTLAND', le: A('own', 2, -0.1), flag: 'gb-sct', fs: A('Scotland', 4) + 0.1, fe: A('Wales', 4, -0.1)}),
  H1('wal-p', ['wales'], RC.wales, 'L2', A('Wales', 4), A('England', 4), {label: 'WALES', le: A('own', 2, -0.1), flag: 'gb-wls', fs: A('Wales', 4) + 0.1, fe: A('Northern', 2, -0.1)}),
  H1('ni-p', ['nireland'], RC.nireland, 'L2', A('Northern', 2), A('England', 4), {label: 'NORTHERN IRELAND', le: A('own', 2, -0.1)}),
  H1('eng-p', ['england'], RC.england, 'L2', A('England', 4), Q(76, -0.05), {label: 'ENGLAND', le: A('shares', 1, -0.3), flag: 'gb-eng', fs: A('England', 4) + 0.15, fe: A('shares', 1, 0.8)}),
  H1('sct-q', ['scotland'], RC.scotland, 'L1', Q(76, -0.2), Q(85, -0.1), {label: 'SCOTLAND', le: A('2014', 1, 0.8), flag: 'gb-sct', fs: Q(76, 0.4), fe: A('2022', 1, -0.2)}),
  H1('wal-q', ['wales'], RC.wales, 'L1', A('Wales', 5), A('while', 1, -0.2), {label: 'WALES', le: A('May', 1, 1.8), flag: 'gb-wls', fs: A('Wales', 5, 0.3)}),
  H1('sct-r', ['scotland'], RC.scotland, 'L1', A('SNP', 1, -0.5), Q(93, -0.2), {label: 'SCOTLAND', le: A('top', 1, 0.0), flag: 'gb-sct', fs: A('SNP', 1, 0.1)}),
  ...four('f2', T_FOUR2, T_LEGAL, {eng: [T_FOUR2 + 0.3, T_LEGAL], sct: [T_FOUR2 + 0.4, T_LEGAL]}),
  H1('uk-d', ['england', 'scotland', 'wales', 'nireland'], C.green, 'L3', T_LEGAL, T_FOUR3, {flag: 'gb', fregion: 'england', fs: T_LEGAL + 0.4, fe: T_FOUR3}),
  ...four('f3', T_FOUR3, DURATION_S, {eng: [T_FOUR3 + 0.5, A('nations', 1, 1.2)], sct: [T_FOUR3 + 0.6, A('nations', 1, 1.2)], wal: [A('nations', 1, 1.2), A('union', 1, 0.0)]}),
];

// ======================= camera =======================
const K = (t: number, lon: number, lat: number, zoom: number, pitch: number, bearing: number, fly?: number): CamKey =>
  ({t, lon, lat, zoom, pitch, bearing, fly: fly !== undefined, dip: fly ?? 0});

export const CAM_KEYS: CamKey[] = [
  K(0, -96, 38.8, 4.05, 48, -10),
  K(A('America', 1, 0.0), -93, 39.5, 4.25, 47, -6),
  K(A('teams', 1, -0.5), -88, 42, 4.15, 46, -3),
  K(A('it,', 1, -0.5), -2.8, 54.3, 6.0, 46, 6, 3.0),
  K(SO, -3.0, 54.0, 6.3, 46, 2),
  K(A('four', 1, -0.5), -2.6, 54.4, 6.5, 47, -6),
  K(A('missing', 1, -0.3), -2.6, 53.6, 6.65, 46, -3),
  K(A('Wales', 1, -0.5), -3.8, 52.4, 7.8, 40, -8, 0.8),
  K(A('swallowed', 1, 0.5), -3.7, 52.5, 8.05, 38, -4),
  K(A('invaded', 1, 0.0), -3.9, 53.0, 8.6, 42, -6),
  K(A('built', 1, -0.5), -4.05, 53.05, 9.1, 44, -4),
  K(A('1536', 1, 0.0), -3.8, 52.7, 8.4, 43, 4),
  K(A('fully', 1, 0.0), -3.2, 52.6, 7.4, 44, -2),
  K(A('Scotland', 2, -0.5), -4.1, 56.4, 6.95, 42, -4, 0.6),
  K(A('colony', 1, -0.6), -4.0, 56.4, 7.1, 42, -8),
  K(A('Panama', 1, 0.2), -80.0, 8.7, 6.9, 40, -6, 3.4),
  K(A('quarter', 1, 0.0), -79.9, 8.9, 7.2, 38, 3),
  K(A('England', 3, -0.1), -1.6, 52.8, 7.0, 44, 3, 3.0),
  K(A('equivalent', 1, 0.0), -2.6, 54.2, 6.4, 44, -2),
  K(A('merged,', 2, 0.0), -3.5, 55.6, 6.6, 44, -4),
  K(A('church', 1, 0.3), -4.0, 56.4, 6.9, 42, 2),
  K(A('Ireland', 1, 0.5), -8.0, 53.3, 7.2, 42, -4, 0.3),
  K(A('1800', 1, 0.0), -7.9, 53.3, 7.2, 42, -6),
  K(A('158', 1, 0.0), -7.7, 53.4, 7.55, 41, 1),
  K(A('buying', 1, 0.0), -7.4, 53.6, 7.35, 42, -2),
  K(A('UK', 1, -0.5), -4.5, 54.5, 5.6, 46, 4, 0.9),
  K(A('most', 1, 0.0), -5.0, 54.0, 5.95, 46, -2),
  K(A('Northern', 1, 0.3), -6.7, 54.6, 8.0, 40, -4, 0.0),
  K(A('Today', 1, -0.6), -6.5, 54.7, 8.2, 40, 4),
  K(A('UK', 2, 0.0), -3.5, 54.4, 6.1, 46, -3, 0.0),
  K(A('Scotland', 4, 0.0), -3.8, 54.6, 6.25, 46, 0),
  K(A('assemblies', 1, 0.0), -4.3, 54.2, 6.55, 45, 5),
  K(A('England', 4, 0.0), -1.8, 52.8, 6.9, 44, -2),
  K(A('everyone', 1, -0.5), -3.0, 54.2, 6.2, 45, 3),
  K(Q(76, 0.2), -4.2, 56.6, 6.9, 42, -6, 0.0),
  K(A('Scots', 1, 1.5), -4.0, 56.3, 7.0, 43, 2),
  K(A('2022', 1, 0.3), -3.5, 55.5, 6.5, 44, -3),
  K(A("London's", 1, -0.5), -2.5, 54.3, 5.9, 46, 3),
  K(Q(85, 0.8), -3.8, 52.3, 7.9, 40, -6, 0.0),
  K(A('largest', 1, 0.5), -3.6, 52.4, 8.1, 40, 3),
  K(A('while', 1, 0.0), -4.3, 56.8, 6.9, 42, -4, 0.0),
  K(Q(93, 0.2), -3.0, 54.5, 5.6, 48, 2, 0.5),
  K(A('spirit,', 1, 0.0), -3.0, 54.4, 5.9, 47, -6),
  K(END_S, -3.0, 54.4, 5.5, 50, 8),
  K(DURATION_S, -3.0, 54.4, 5.0, 50, 14),
];

// ======================= hero text (top zone) =======================
export interface HeroLine {t: string; c: 'w' | 'g'; s: number}
export interface Hero {lines: HeroLine[]; s: number; e: number}
const hero = (s: number, e: number, ...lines: [string, 'w' | 'g', number?][]): Hero => ({
  s, e, lines: lines.map((l) => ({t: l[0], c: l[1], s: l[2] ?? s})),
});
export const HEROES: Hero[] = [
  hero(0.4, 3.6, ['2026 WORLD CUP', 'w'], ['COMES TO AMERICA', 'g', A('came')]),
  hero(3.9, SO, ['SAME COUNTRY', 'w'], ['TWO TEAMS', 'g', A('teams')]),
  hero(Q(8, -0.05), A('One', 1, -0.15), ['WHAT IS THE', 'w'], ['UNITED KINGDOM?', 'g', A('United')]),
  hero(A('One', 1, -0.15), A('Start', 1, -0.15), ['ONE COUNTRY', 'w'], ['OR FOUR?', 'g', A('or', 1, -0.2)]),
  hero(A('Start', 1, -0.1), A('Something', 1, -0.2), ['THE UK FLAG', 'g']),
  hero(A('Something', 1, -0.15), A('Wales', 1), ['SOMETHING', 'w'], ['IS MISSING', 'g', A('is', 2, -0.2)]),
  hero(A('Wales', 1), Q(21, -0.1), ['WALES', 'w'], ['NOT ON THE FLAG', 'g', A('isn\'t')]),
  hero(Q(21, -0.1), A('by', 1, -0.2), ['KING EDWARD I', 'w', A('King')], ['1282', 'g', A('1282', 1, -0.2)]),
  hero(A('by', 1, -0.2), A('Scotland', 2, -0.3), ['FULLY MERGED', 'w'], ['1536', 'g']),
  hero(A('Scotland', 2, -0.3), A('colony', 1, -0.2), ['SCOTLAND FOLLOWED', 'w'], ['1707', 'g', A('1707', 1, -0.2)]),
  hero(A('colony', 1, -0.2), A('England', 3, -0.3), ['COLONY IN PANAMA', 'w'], ['COLLAPSED', 'g', A('collapsed')]),
  hero(A('England', 3, -0.3), Q(41, -0.2), ['ENGLAND OFFERED', 'w']),
  hero(Q(41, -0.2), Q(45, -0.25), ['SCOTLAND MERGED', 'w'], ['KEPT ITS OWN', 'g', A('keeping')]),
  hero(Q(45, -0.2), A('1800', 1, -0.25), ['IRELAND', 'w'], ['WAS NEXT', 'g', A('was', 3, -0.2)]),
  hero(A('1800', 1, -0.2), A('UK', 1, -0.3), ['IRELAND, 1800', 'w'], ['VOTED ITSELF OUT', 'g', A('voted', 1)]),
  hero(A('UK', 1, -0.2), A('most', 1, -0.3), ['THE UK WAS BORN', 'w'], ['1801', 'g', A('1801', 1, -0.2)]),
  hero(A('most', 1, -0.2), A('where', 1, -0.3), ['MOST OF IRELAND', 'w'], ['BROKE AWAY', 'g', A('broke')]),
  hero(A('where', 1, -0.25), A('Today', 1, -0.3), ['WHERE PEOPLE', 'w'], ['CAN BE...', 'g', A('can')]),
  hero(A('Today', 1, -0.3), A('Scotland', 4, -0.25), ['THE UK RUNS ON', 'w'], ['3 LEGAL SYSTEMS', 'g', A('three')]),
  hero(A('Scotland', 4, -0.25), A('England', 4, -0.25), ['OWN PARLIAMENTS', 'w', A('have', 1)], ['OR ASSEMBLIES', 'g', A('assemblies')]),
  hero(A('England', 4, -0.25), Q(76, -0.25), ['ENGLAND:', 'w'], ['ONLY THE UK PARLIAMENT', 'g', A('only')]),
  hero(Q(76, -0.25), A('2022', 1, -0.25), ['SCOTLAND, 2014', 'w'], ['VOTED TO STAY', 'g', A('voted', 2)]),
  hero(A('2022', 1, -0.25), Q(85, -0.2), ['2022: SUPREME COURT', 'w'], ['NO NEW VOTE', 'g', A('hold')]),
  hero(Q(85, -0.15), A('Wales', 5, -0.3), ['MAY 2026', 'g']),
  hero(A('Wales', 5, -0.25), A('while', 1, -0.25), ['PLAID CYMRU', 'w', A('Plaid')], ['NATIONALIST PARTY', 'g', A('nationalist')]),
  hero(A('while', 1, -0.25), Q(93, -0.2), ['SNP STAYED', 'w', A('SNP')], ['ON TOP', 'g', A('on', 2)]),
  hero(Q(93, -0.15), A('Legally', 1, -0.25), ['ONE COUNTRY', 'w'], ['OR FOUR?', 'g', A('four', 2, -0.2)]),
  hero(A('Legally', 1, -0.2), Q(96, -0.45), ['LEGALLY:', 'w'], ['ONE STATE', 'g', A('state')]),
  hero(Q(96, -0.4), A('nations', 1, 0.6), ['IN SPIRIT:', 'w'], ['FOUR NATIONS', 'g', A('four', 3, -0.2)]),
  hero(A('nations', 1, 0.6), DURATION_S - 0.5, ['IN ONE', 'w', A('nations', 1, 0.2)], ['FRAGILE UNION', 'g', A('fragile')]),
];

// ======================= bottom zone info (one at a time) =======================
export type Bottom =
  | {k: 'pill'; main: string; sub?: string; s: number; e: number}
  | {k: 'counter'; pre?: string; to: number; fmt: 'int' | 'money' | 'pct' | 'x'; post?: string; s: number; e: number; dur: number}
  | {k: 'bars'; title: string; rows: {label: string; v: number; c: string}[]; s: number; e: number}
  | {k: 'chips'; items: {t: string; s: number; c: string}[]; s: number; e: number}
  | {k: 'flagcard'; iso: string; s: number; e: number}
  | {k: 'timeline'; a: number; b: number; ta: number; tb: number; s: number; e: number};

export const BOTTOMS: Bottom[] = [
  {k: 'flagcard', iso: 'gb', s: A('Start', 1, -0.2), e: A('Wales', 1, -0.15)},
  {k: 'pill', main: 'SWALLOWED', sub: 'LONG BEFORE THE FLAG', s: A('swallowed'), e: Q(21, -0.1)},
  {k: 'timeline', a: 1282, b: 1536, ta: A('1282'), tb: A('1536'), s: A('1282', 1, -0.3), e: A('Scotland', 2, -0.3)},
  {k: 'counter', pre: 'ABOUT', to: 2000, fmt: 'int', post: 'PEOPLE', s: A('about', 1), e: A('wiping', 1, 0.0), dur: 1.2},
  {k: 'counter', pre: 'ABOUT', to: 25, fmt: 'pct', post: "OF SCOTLAND'S LIQUID CAPITAL", s: A('wiping', 1, 0.0), e: A('England', 3, -0.3), dur: 1.0},
  {k: 'counter', to: 398085, fmt: 'money', post: 'OFFERED BY ENGLAND', s: A('398,085'), e: A('called', 1, -0.2), dur: 1.5},
  {k: 'pill', main: 'CALLED THE EQUIVALENT', s: A('called'), e: Q(45, -0.25)},
  {k: 'bars', title: 'THE VOTE', rows: [{label: 'FOR', v: 158, c: C.lime}, {label: 'AGAINST', v: 115, c: C.amber}], s: A('158'), e: A('six', 1, -0.3)},
  {k: 'counter', pre: 'OVER', to: 6, fmt: 'x', post: 'ITS LEGAL LIMIT', s: A('six', 1, -0.2), e: A('UK', 1, -0.3), dur: 1.0},
  {k: 'counter', pre: 'ABOUT', to: 120, fmt: 'int', post: 'YEARS', s: A('about', 2), e: A('most', 1, -0.3), dur: 1.2},
  {k: 'chips', items: [{t: 'BRITISH', s: A('British,'), c: C.white}, {t: 'IRISH', s: A('Irish,'), c: C.white}, {t: 'OR BOTH', s: A('both'), c: C.gold}], s: A('British,'), e: A('Today', 1, -0.3)},
  {k: 'pill', main: 'SHARED WITH EVERYONE', s: A('shares'), e: Q(76, -0.25)},
  {k: 'bars', title: 'SCOTLAND 2014', rows: [{label: 'STAY', v: 55, c: C.amber}, {label: 'LEAVE', v: 45, c: C.sky}], s: A('55'), e: A('2022', 1, -0.3)},
  {k: 'pill', main: "WITHOUT LONDON'S CONSENT", s: A('without'), e: Q(85, -0.2)},
  {k: 'pill', main: 'LARGEST', sub: 'FOR THE FIRST TIME', s: A('largest'), e: A('while', 1, -0.25)},
];

// ======================= icons =======================
export type IconKind = 'castle' | 'ship' | 'warning' | 'scales' | 'gavel' | 'church' | 'parliament' | 'ballot' | 'coins' | 'pin';
export interface RowIcon {kind: IconKind; caption?: string; s: number; e: number; slash?: boolean}
export interface MapIcon {kind: IconKind; lon: number; lat: number; s: number; e: number; size: number; dx?: number; dy?: number; red?: boolean}

export const ROW_ICONS: RowIcon[] = [
  {kind: 'scales', caption: 'LAWS', s: A('laws,'), e: Q(45, -0.2)},
  {kind: 'gavel', caption: 'COURTS', s: A('courts,'), e: Q(45, -0.2)},
  {kind: 'church', caption: 'CHURCH', s: A('church'), e: Q(45, -0.2)},
  {kind: 'parliament', caption: 'PARLIAMENT', s: A('parliament'), e: A('158', 1, -0.3)},
  {kind: 'coins', caption: 'BUYING VOTES', s: A('buying'), e: A('UK', 1, -0.3)},
  {kind: 'gavel', s: A('Supreme'), e: A('Then,', 1, -0.3)},
  {kind: 'ballot', slash: true, s: A('can\'t'), e: A('Then,', 1, -0.3)},
];
export const MAP_ICONS: MapIcon[] = [
  {kind: 'castle', lon: -3.83, lat: 53.28, s: A('built'), e: A('built') + 3.0, size: 140},
  {kind: 'castle', lon: -4.27, lat: 53.14, s: A('giant'), e: A('built') + 3.0, size: 140},
  {kind: 'castle', lon: -4.11, lat: 52.86, s: A('castles,'), e: A('built') + 3.0, size: 140},
  {kind: 'warning', lon: -79.9, lat: 8.9, s: A('collapsed'), e: A('collapsed') + 3.0, size: 150, dx: 110, dy: -170, red: true},
  {kind: 'parliament', lon: -4.3, lat: 56.9, s: A('parliaments'), e: A('but', 2, 0.0), size: 130, dx: 0, dy: -70},
  {kind: 'parliament', lon: -3.75, lat: 52.3, s: A('parliaments', 1, 0.2), e: A('but', 2, 0.0), size: 130, dx: 0, dy: -70},
  {kind: 'parliament', lon: -6.7, lat: 54.65, s: A('parliaments', 1, 0.4), e: A('but', 2, 0.0), size: 130, dx: 0, dy: -70},
];
export interface Pulse {lon: number; lat: number; s: number; e: number; color: string; label?: string; pin?: boolean}
export const PULSES: Pulse[] = [
  {lon: -0.1276, lat: 51.507, s: A('Parliament', 2, -0.2), e: A('everyone', 1, 0.5), color: C.gold, label: 'LONDON', pin: true},
  {lon: -0.1276, lat: 51.507, s: A("London's"), e: Q(85, -0.2), color: C.gold, label: 'LONDON', pin: true},
];

// ======================= routes =======================
export interface Route {pts: [number, number][]; s: number; d: number; e: number; color: string; dashed?: boolean; head?: 'ship' | 'arrow'}
export const ROUTES: Route[] = [
  {pts: [[-3.2, 55.95], [-12, 47], [-35, 34], [-62, 20], [-79.6, 9.1]], s: A('colony', 1, -0.5), d: 1.5, e: A('collapsed', 1, 0.8), color: C.yellow, dashed: true, head: 'ship'},
  {pts: [[-3.75, 52.3], [-2.6, 52.5], [-1.5, 52.7]], s: A('fully', 1, -0.2), d: 0.9, e: A('England', 2, 0.4), color: C.yellow, head: 'arrow'},
  {pts: [[-0.1276, 51.507], [-1.6, 53.5], [-3.19, 55.95]], s: A('shares', 1, -0.3), d: 0.9, e: Q(76, -0.2), color: C.yellow},
  {pts: [[-0.1276, 51.507], [-1.7, 51.5], [-3.18, 51.48]], s: A('shares', 1, -0.15), d: 0.9, e: Q(76, -0.2), color: C.yellow},
  {pts: [[-0.1276, 51.507], [-3, 53.5], [-5.93, 54.6]], s: A('shares', 1, 0.0), d: 0.9, e: Q(76, -0.2), color: C.yellow},
];

// ======================= scene sweeps and sound =======================
export const SWEEPS = [Q(8, -0.1), Q(12, -0.4), Q(21, -0.25), Q(28, -0.3), Q(45, -0.4), Q(55, -0.3), Q(64, 0.2), Q(76, -0.3), Q(85, -0.3), Q(93, -0.3)];
export interface Sfx {t: number; kind: 'pop' | 'whoosh' | 'alarm' | 'bell'; vol: number}
const popTimes: number[] = [];
const addPop = (t: number) => {
  if (!popTimes.some((x) => Math.abs(x - t) < 0.35)) popTimes.push(t);
};
HLS.filter((h) => !h.id.startsWith('f') || h.id.endsWith('-e')).forEach((h) => addPop(h.s));
BOTTOMS.forEach((b) => addPop(b.s));
export const SFX: Sfx[] = [
  ...popTimes.map((t): Sfx => ({t: t - 0.08, kind: 'pop', vol: 0.3})),
  ...SWEEPS.map((t): Sfx => ({t: t - 0.05, kind: 'whoosh', vol: 0.25})),
  {t: A('teams', 1, -0.5), kind: 'whoosh', vol: 0.3},
  {t: A('colony', 1, -0.6), kind: 'whoosh', vol: 0.3},
  {t: A('quarter', 1, 0.4), kind: 'whoosh', vol: 0.3},
  {t: A('collapsed', 1, -0.1), kind: 'alarm', vol: 0.2},
  {t: END_S + 1.15, kind: 'bell', vol: 0.3},
  {t: END_S + 0.1, kind: 'pop', vol: 0.3},
  {t: END_S + 0.55, kind: 'pop', vol: 0.3},
];
export const SFX_FILE: Record<Sfx['kind'], {file: string; maxS: number}> = {
  pop: {file: 'sfx/pop.wav', maxS: 0.5},
  whoosh: {file: 'sfx/whoosh.mp3', maxS: 0.8},
  alarm: {file: 'sfx/alarm.wav', maxS: 1.2},
  bell: {file: 'sfx/bell.wav', maxS: 1.4},
};
