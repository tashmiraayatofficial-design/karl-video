import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {CAM_KEYS, CREDIT, C, FPS, INCLUDE_VOICEOVER, SFX, SFX_FILE, SWEEPS} from './config';
import {useFonts} from './fonts';
import {GroundLayer} from './Ground';
import {TileLayer, VectorMap} from './TileLayer';
import {BottomLayer, EndCard, HeroLayer, RowIcons} from './TextLayers';
import {Uprights} from './Uprights';
import {AX, AY, PH, PW, ANCHOR_Y, camAt, clamp, makeProjector, planeTransform, prog} from './math';

const planeStyle = (cam: ReturnType<typeof camAt>): React.CSSProperties => ({
  position: 'absolute', left: 540 - AX, top: ANCHOR_Y - AY, width: PW, height: PH,
  transformOrigin: `${AX}px ${AY}px`, transform: planeTransform(cam),
});

const Particles: React.FC<{t: number}> = ({t}) => (
  <>
    {Array.from({length: 34}).map((_, i) => {
      const x = (i * 137.5) % 1080;
      const sp = 14 + (i % 5) * 7;
      const y = (((i * 71) % 1920) - t * sp + 4000) % 1920;
      const r = 2 + (i % 3);
      return <div key={i} style={{position: 'absolute', left: x + Math.sin(t * 0.8 + i) * 14, top: y, width: r * 2, height: r * 2, borderRadius: r, background: '#fff', opacity: 0.1 + (i % 4) * 0.03}} />;
    })}
  </>
);

const Sweeps: React.FC<{t: number}> = ({t}) => (
  <>
    {SWEEPS.map((s, i) => {
      const p = prog(t, s, s + 0.6);
      if (p <= 0 || p >= 1) return null;
      return (
        <div key={i} style={{position: 'absolute', top: -100, left: -700 + p * 2500, width: 460, height: 2120, transform: 'skewX(-18deg)', background: 'linear-gradient(90deg, rgba(255,255,255,0), rgba(255,255,255,0.3), rgba(255,255,255,0))'}} />
      );
    })}
  </>
);

export const Main: React.FC<{noTiles?: boolean}> = ({noTiles}) => {
  const ready = useFonts();
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const cam = camAt(CAM_KEYS, t);
  const proj = makeProjector(cam);
  return (
    <AbsoluteFill style={{background: C.navy, overflow: 'hidden'}}>
      <div style={{...planeStyle(cam), filter: 'brightness(0.88) contrast(1.1) saturate(1.05)'}}>
        {noTiles ? <VectorMap proj={proj} /> : <TileLayer proj={proj} />}
      </div>
      <div style={planeStyle(cam)}>
        <GroundLayer proj={proj} t={t} />
      </div>
      <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 760, background: 'linear-gradient(to bottom, #07121F 0%, #07121F 22%, rgba(7,18,31,0) 100%)'}} />
      {ready ? <Uprights proj={proj} t={t} /> : null}
      <Particles t={t} />
      {ready ? <RowIcons t={t} /> : null}
      {ready ? <HeroLayer t={t} /> : null}
      {ready ? <BottomLayer t={t} /> : null}
      {ready ? <EndCard t={t} /> : null}
      <Sweeps t={t} />
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)', pointerEvents: 'none'}} />
      <div style={{position: 'absolute', left: 0, width: 1080, top: 1850, textAlign: 'center', fontFamily: 'Inter', fontWeight: 400, fontSize: 18, color: '#fff', opacity: 0.7}}>{CREDIT}</div>
      {INCLUDE_VOICEOVER ? <Audio src={staticFile('voiceover.mp3')} /> : null}
      {SFX.map((s, i) => {
        const f = Math.max(0, Math.round(s.t * FPS));
        const d = SFX_FILE[s.kind];
        return (
          <Sequence key={i} from={f} durationInFrames={Math.ceil(d.maxS * FPS)}>
            <Audio src={staticFile(d.file)} volume={clamp(s.vol, 0, 1)} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
