import {CAM_KEYS, DURATION_S} from '../src/config';
import {camAt, globeCam, makeProjector} from '../src/math';
let minRaise = 99, maxRaise = 0, n = 0, over = 0;
const rows: string[] = [];
for (let t = 0; t <= DURATION_S; t += 0.5) {
  const c = camAt(CAM_KEYS, t);
  const g = globeCam(c);
  const want = c.zoom - 0.3 + Math.log2(1 / Math.cos((Math.min(70, Math.abs(c.lat)) * Math.PI) / 180));
  const raise = g.zoom - want;
  minRaise = Math.min(minRaise, raise); maxRaise = Math.max(maxRaise, raise); n++;
  if (raise > 0.001) over++;
  if (Math.round(t * 2) % 10 === 0) rows.push(`t=${t.toFixed(1)} lat=${c.lat.toFixed(1)} keyZoom=${c.zoom.toFixed(2)} wantGlobe=${want.toFixed(2)} used=${g.zoom.toFixed(2)} pitch=${g.pitch.toFixed(0)}`);
}
console.log(rows.join('\n'));
console.log(`samples=${n} forced-raise samples=${over} maxRaise=${maxRaise.toFixed(2)} zoomMax=${Math.max(...CAM_KEYS.map(k=>k.zoom))}`);
const p = makeProjector(camAt(CAM_KEYS, 20));
console.log('screen(London) at t=20', p.screen(-0.13, 51.5));
