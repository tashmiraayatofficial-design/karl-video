import {BOTTOMS, CAM_KEYS, DURATION_S, HEROES, HLS, REG, ROW_ICONS} from '../src/config';
import {camAt, clamp, makeProjector} from '../src/math';
const BOTTOM_TOP = (b: (typeof BOTTOMS)[number]) => (b.k === 'pill' ? (b.sub ? 1440 : 1480) : b.k === 'timeline' ? 1410 : b.k === 'chips' ? 1470 : b.k === 'flagcard' ? 1380 : 1370);
const issues = new Map<string, {n: number; first: number; msg: string}>();
const note = (k: string, t: number, msg: string) => {
  const v = issues.get(k);
  if (v) v.n++;
  else issues.set(k, {n: 1, first: t, msg});
};
for (let t = 0.2; t < DURATION_S; t += 0.1) {
  const proj = makeProjector(camAt(CAM_KEYS, t));
  const hero = HEROES.find((h) => t >= h.s + 0.4 && t <= h.e - 0.3);
  const bot = BOTTOMS.find((b) => t >= b.s + 0.4 && t <= b.e - 0.3);
  const row = ROW_ICONS.some((r) => t >= r.s + 0.4 && t <= r.e - 0.3);
  const act = HLS.filter((h) => t >= h.s + 0.6 && t <= h.e - 0.3);
  const rects: {n: string; x0: number; y0: number; x1: number; y1: number}[] = [];
  for (const h of act) {
    // main shape bbox
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (const reg of h.regions) for (const ring of REG[reg].rings) for (const p of ring) {
      const q = proj.screen(p[0], p[1]);
      x0 = Math.min(x0, q.x); y0 = Math.min(y0, q.y); x1 = Math.max(x1, q.x); y1 = Math.max(y1, q.y);
    }
    if (bot && h.mode === 'L1' && y1 > BOTTOM_TOP(bot) - 10) note('shape-under-card ' + h.id, t, `bottom=${y1.toFixed(0)} card top=${BOTTOM_TOP(bot)}`);
    if (hero && h.mode === 'L1' && y0 < 470 && h.regions.length === 1) note('shape-under-hero ' + h.id, t, `top=${y0.toFixed(0)} hero bottom~470`);
    if (h.flag && t >= h.flag.s + 0.5 && t <= h.flag.e - 0.3) {
      const [lon, lat] = REG[h.flag.region].label;
      const a = proj.screen(lon, lat);
      const ms = clamp(a.s, 0.6, 1.3);
      const ph = 130 * ms;
      const r = {n: 'flag ' + h.id, x0: a.x - 95 * ms, y0: a.y - ph - 10, x1: a.x + 95 * ms, y1: a.y + 10};
      rects.push(r);
      if (r.y0 < 500 || r.y1 > 1350) note('flag-outside-middle-zone ' + h.id, t, `y ${r.y0.toFixed(0)}..${r.y1.toFixed(0)}`);
      if (bot && r.y1 > BOTTOM_TOP(bot) - 10) note('flag-vs-card ' + h.id, t, `flag bottom ${r.y1.toFixed(0)} card ${BOTTOM_TOP(bot)}`);
      if (row && r.y1 > 1120 && r.y0 < 1330) note('flag-vs-iconrow ' + h.id, t, `flag ${r.y0.toFixed(0)}..${r.y1.toFixed(0)}`);
      if (hero && r.y0 < 470) note('flag-vs-hero ' + h.id, t, `flag top ${r.y0.toFixed(0)}`);
    }
    if (h.label && t >= h.label.s + 0.4 && t <= h.label.e - 0.3) {
      const [lon, lat] = REG[h.label.region].label;
      const a = proj.screen(lon, lat);
      const fs = h.label.small ? 26 : 30;
      const w = h.label.text.length * fs * 0.68 + 44;
      const hh = fs + 24;
      const cx = clamp(a.x + h.label.dx, 100 + w / 2, 980 - w / 2);
      const cy = clamp(a.y + h.label.dy, 560 + hh / 2, (row ? 1100 : 1330) - hh / 2);
      rects.push({n: 'label ' + h.id, x0: cx - w / 2, y0: cy - hh / 2, x1: cx + w / 2, y1: cy + hh / 2});
      if (bot && cy + hh / 2 > BOTTOM_TOP(bot) - 10) note('label-vs-card ' + h.id, t, `label bottom ${(cy + hh / 2).toFixed(0)}`);
    }
  }
  for (let i = 0; i < rects.length; i++) for (let j = i + 1; j < rects.length; j++) {
    const a = rects[i], b = rects[j];
    if (a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1) note(`overlap ${a.n} x ${b.n}`, t, 'rects intersect');
  }
}
for (const [k, v] of issues) console.log(`${k}: ${v.n} samples (first t=${v.first.toFixed(1)}) ${v.msg}`);
console.log('issue kinds:', issues.size);
