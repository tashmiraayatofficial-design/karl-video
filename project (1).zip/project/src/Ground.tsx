import React from 'react';
import {C, HLS, Hl, PULSES, REG, ROUTES} from './config';
import {Projector, SCREEN_H, SCREEN_W, angDist, clamp, eio3, greatCircle, prog} from './math';

// ---------- shared helpers
export const vis = (t: number, s: number, e: number, outDur = 0.3) => (t < s ? 0 : t > e ? 0 : 1 - prog(t, e - outDur, e));

// project a ring to screen space; hidden vertices (behind the horizon) are skipped
const ringD = (proj: Projector, ring: number[][], reverse = false) => {
  const pts = reverse ? [...ring].reverse() : ring;
  let d = '';
  let started = false;
  for (let i = 0; i < pts.length; i++) {
    const q = proj.screen(pts[i][0], pts[i][1]);
    if (!q.vis) continue;
    d += (started ? 'L' : 'M') + q.x.toFixed(1) + ' ' + q.y.toFixed(1);
    started = true;
  }
  return d;
};

interface RegionPaths {rings: string[]; rev: string[]; all: string}
const regionPaths = (proj: Projector, id: string, cache: Map<string, RegionPaths>): RegionPaths => {
  const hit = cache.get(id);
  if (hit) return hit;
  const rings = REG[id].rings.map((r) => ringD(proj, r));
  const rev = REG[id].rings.map((r) => ringD(proj, r, true));
  const out = {rings, rev, all: rings.map((r) => r + 'Z').join('')};
  cache.set(id, out);
  return out;
};

type LL = [number, number];
const chaikin = (pts: LL[], n: number): LL[] => {
  let p = pts;
  for (let k = 0; k < n; k++) {
    const q: LL[] = [p[0]];
    for (let i = 0; i < p.length - 1; i++) {
      q.push([0.75 * p[i][0] + 0.25 * p[i + 1][0], 0.75 * p[i][1] + 0.25 * p[i + 1][1]]);
      q.push([0.25 * p[i][0] + 0.75 * p[i + 1][0], 0.25 * p[i][1] + 0.75 * p[i + 1][1]]);
    }
    q.push(p[p.length - 1]);
    p = q;
  }
  return p;
};

// densified great-circle path of a route (lon/lat), cached because it does not depend on the camera
const pathCache = new Map<number, {pts: LL[]; lens: number[]}>();
const routePath = (idx: number) => {
  const hit = pathCache.get(idx);
  if (hit) return hit;
  const r = ROUTES[idx];
  const base = r.pts.length > 2 ? chaikin(r.pts, 3) : r.pts;
  const pts: LL[] = [];
  for (let i = 0; i < base.length - 1; i++) {
    const seg = greatCircle(base[i], base[i + 1], 0.35);
    for (let k = i === 0 ? 0 : 1; k < seg.length; k++) pts.push(seg[k]);
  }
  const lens: number[] = [0];
  for (let i = 1; i < pts.length; i++) lens.push(lens[i - 1] + angDist(pts[i - 1], pts[i]));
  const out = {pts, lens};
  pathCache.set(idx, out);
  return out;
};

export interface RouteState {
  d: string; alpha: number; dashed: boolean; color: string; head: 'ship' | 'arrow' | 'dot' | undefined;
  hx: number; hy: number; hs: number; ang: number; p: number; headVis: boolean;
}
export const routeStates = (proj: Projector, t: number): RouteState[] => {
  const out: RouteState[] = [];
  ROUTES.forEach((r, idx) => {
    if (t < r.s || t > r.e) return;
    const alpha = 1 - prog(t, r.e - 0.3, r.e);
    const p = eio3(prog(t, r.s, r.s + r.d));
    const {pts, lens} = routePath(idx);
    const target = lens[lens.length - 1] * p;
    let d = '';
    let pen = false;
    let hx = 0;
    let hy = 0;
    let hs = 1;
    let ang = 0;
    let px = 0;
    let py = 0;
    let headVis = false;
    for (let i = 0; i < pts.length; i++) {
      let lon = pts[i][0];
      let lat = pts[i][1];
      let last = false;
      if (lens[i] > target) {
        if (i === 0) break;
        const f = (target - lens[i - 1]) / Math.max(1e-9, lens[i] - lens[i - 1]);
        lon = pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * f;
        lat = pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * f;
        last = true;
      }
      const q = proj.screen(lon, lat);
      if (q.vis) {
        d += (pen ? 'L' : 'M') + q.x.toFixed(1) + ' ' + q.y.toFixed(1);
        if (pen) ang = Math.atan2(q.y - py, q.x - px);
        pen = true;
        hx = q.x; hy = q.y; hs = q.s; headVis = true;
        px = q.x; py = q.y;
      } else pen = false;
      if (last) break;
    }
    out.push({d, alpha, dashed: !!r.dashed, color: r.color, head: r.head, hx, hy, hs, ang, p, headVis});
  });
  return out;
};

// ---------- ground layer: everything that lies on the globe, drawn in screen space (follows the globe exactly)
export const GroundLayer: React.FC<{proj: Projector; t: number}> = ({proj, t}) => {
  const cache = new Map<string, RegionPaths>();
  const act = HLS.filter((h) => t >= h.s - 0.01 && t <= h.e);

  // dim everything except active L1 regions
  const l1 = act.filter((h) => h.mode === 'L1');
  let dimAlpha = 0;
  const holes = new Set<string>();
  for (const h of l1) {
    const a = clamp(prog(t, h.s, h.s + 0.6), 0, 1) * (1 - prog(t, h.e - 0.3, h.e));
    dimAlpha = Math.max(dimAlpha, a * 0.28);
    h.regions.forEach((r) => holes.add(r));
  }
  const dimD = `M-300 -300H${SCREEN_W + 300}V${SCREEN_H + 300}H-300Z` + [...holes].map((r) => regionPaths(proj, r, cache).all).join('');

  const hlLayers = act.map((h: Hl) => {
    const exit = 1 - prog(t, h.e - 0.3, h.e);
    return (
      <g key={h.id} opacity={exit}>
        {h.regions.map((reg, i) => {
          const rp = regionPaths(proj, reg, cache);
          let po: number;
          let fillA: number;
          if (h.mode === 'L1') {
            po = eio3(prog(t, h.s, h.s + 0.9));
            fillA = 0.3 * prog(t, h.s + 0.6, h.s + 1.1);
          } else if (h.mode === 'L2') {
            po = eio3(prog(t, h.s, h.s + 0.35));
            fillA = 0.34 * prog(t, h.s + 0.1, h.s + 0.25);
          } else {
            const d0 = h.s + i * 0.1;
            po = eio3(prog(t, d0, d0 + 0.6));
            fillA = 0.3 * prog(t, d0 + 0.2, d0 + 0.7);
          }
          const flash = h.mode === 'L2' ? 0.55 * (1 - prog(t, h.s + 0.1, h.s + 0.35)) * (t > h.s + 0.1 ? 1 : 0) : 0;
          const glitch = h.mode === 'L2' && t < h.s + 0.22 ? 1 - prog(t, h.s, h.s + 0.22) : 0;
          return (
            <g key={reg}>
              <path d={rp.all} fill={h.color} fillOpacity={fillA} fillRule="evenodd" />
              {flash > 0 ? <path d={rp.all} fill="#fff" fillOpacity={flash} fillRule="evenodd" /> : null}
              {rp.rings.map((d, k) => (
                <g key={k} fill="none" strokeLinejoin="round" strokeLinecap="round">
                  {[false, true].map((rev) => (
                    <React.Fragment key={String(rev)}>
                      <path d={rev ? rp.rev[k] : d} pathLength={1000} stroke={h.color} strokeOpacity={0.35} strokeWidth={14} strokeDasharray={`${po * 500} 1000`} />
                      <path d={rev ? rp.rev[k] : d} pathLength={1000} stroke={h.color} strokeWidth={4} strokeDasharray={`${po * 500} 1000`} />
                    </React.Fragment>
                  ))}
                  {glitch > 0 ? (
                    <>
                      <path d={d} stroke="#ff2b4d" strokeWidth={4} strokeOpacity={glitch} transform="translate(6 0)" />
                      <path d={d} stroke="#22e4ff" strokeWidth={4} strokeOpacity={glitch} transform="translate(-6 0)" />
                    </>
                  ) : null}
                </g>
              ))}
            </g>
          );
        })}
      </g>
    );
  });

  const rs = routeStates(proj, t);
  const pulses = PULSES.filter((p) => t >= p.s && t <= p.e).map((p, i) => {
    const c = proj.screen(p.lon, p.lat);
    if (!c.vis) return null;
    const a = vis(t, p.s, p.e, 0.3);
    const ph = ((t - p.s) % 1.2) / 1.2;
    return (
      <g key={i} opacity={a} fill="none" stroke={p.color}>
        {[0, 0.5].map((o) => {
          const q = (ph + o) % 1;
          return <circle key={o} cx={c.x} cy={c.y} r={(26 + q * 120) * clamp(c.s, 0.6, 1.3)} strokeWidth={6} strokeOpacity={0.9 * (1 - q)} />;
        })}
      </g>
    );
  });

  return (
    <svg width={SCREEN_W} height={SCREEN_H} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
      {dimAlpha > 0 ? <path d={dimD} fill="#02070f" fillOpacity={dimAlpha} fillRule="evenodd" /> : null}
      {hlLayers}
      {rs.map((r, i) => (
        <g key={i} opacity={r.alpha} fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d={r.d} stroke="#0a2a4a" strokeOpacity={0.55} strokeWidth={17} />
          <path d={r.d} stroke={C.yellow} strokeOpacity={0.35} strokeWidth={24} />
          <path d={r.d} stroke={r.color} strokeWidth={10} strokeDasharray={r.dashed ? '28 20' : undefined} />
          {r.head === 'arrow' && r.headVis ? (
            <g transform={`translate(${r.hx} ${r.hy}) rotate(${(r.ang * 180) / Math.PI})`}>
              <path d="M-6 -26L38 0L-6 26Z" fill={r.color} stroke={C.navy} strokeWidth={3} />
            </g>
          ) : null}
          {r.head === 'dot' && r.headVis ? (
            <g>
              <circle cx={r.hx} cy={r.hy} r={22} fill="#fff" stroke="#0a2a4a" strokeWidth={3} />
              <circle cx={r.hx} cy={r.hy} r={11} fill={C.red} />
            </g>
          ) : null}
        </g>
      ))}
      {pulses}
    </svg>
  );
};
