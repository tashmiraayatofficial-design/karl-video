import React from 'react';
import {Composition} from 'remotion';
import {DURATION, FPS, H, W} from './config';
import {Main} from './Main';

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={DURATION} fps={FPS} width={W} height={H} />
);
