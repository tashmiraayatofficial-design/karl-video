import React, {useEffect, useLayoutEffect, useRef, useState} from 'react';
import {cancelRender, continueRender, delayRender, staticFile} from 'remotion';
import type {GlobeUniforms} from './math';
import {SCREEN_H, SCREEN_W} from './math';

const VERT = `#version 300 es
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}`;

const FRAG = `#version 300 es
precision highp float;
uniform sampler2D uTex;
uniform vec3 uCp;
uniform vec3 uCr;
uniform vec3 uCu;
uniform vec3 uF;
uniform float uFocal;
uniform float uAY;
uniform float uTime;
out vec4 outColor;
const float PI = 3.14159265359;
void main() {
  float px = gl_FragCoord.x;
  float py = ${SCREEN_H}.0 - gl_FragCoord.y;
  vec3 d = normalize(uF * uFocal + uCr * (px - ${SCREEN_W / 2}.0) + uCu * (uAY - py));
  float b = dot(uCp, d);
  float c = dot(uCp, uCp) - 1.0;
  float disc = b * b - c;
  if (disc < 0.0) { outColor = vec4(0.03, 0.18, 0.42, 1.0); return; } // safety only: the camera keeps the sphere filling the screen
  float t = -b - sqrt(disc);
  vec3 n = normalize(uCp + d * t);
  float lat = asin(clamp(n.z, -1.0, 1.0));
  float lon = atan(n.y, n.x);
  float u = lon / (2.0 * PI) + 0.5;
  float v = 0.5 - lat / PI;
  float uB = fract(u + 0.5);
  vec2 dxA = dFdx(vec2(u, v));
  vec2 dyA = dFdy(vec2(u, v));
  vec2 dxB = dFdx(vec2(uB, v));
  vec2 dyB = dFdy(vec2(uB, v));
  bool useB = (abs(dxB.x) + abs(dyB.x)) < (abs(dxA.x) + abs(dyA.x));
  vec2 gx = useB ? dxB : dxA;
  vec2 gy = useB ? dyB : dyA;
  vec3 col = textureGrad(uTex, vec2(u, v), gx, gy).rgb;
  // soft daylight: lit from the camera side, never dark
  vec3 L = normalize(uCp + uCu * 0.55 - uCr * 0.25);
  float lam = clamp(dot(n, L), 0.0, 1.0);
  col *= 0.86 + 0.22 * lam;
  // thin blue atmosphere toward the limb
  float fres = pow(1.0 - clamp(dot(n, -d), 0.0, 1.0), 3.0);
  col = mix(col, vec3(0.42, 0.70, 1.0), fres * 0.38);
  col = pow(col, vec3(0.96));
  // tiny dither against banding in the smooth sea
  float dn = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
  col += (dn - 0.5) / 255.0;
  outColor = vec4(col, 1.0);
}`;

interface GLState {
  gl: WebGL2RenderingContext;
  prog: WebGLProgram;
  loc: Record<string, WebGLUniformLocation | null>;
}

const compile = (gl: WebGL2RenderingContext, type: number, src: string) => {
  const s = gl.createShader(type);
  if (!s) throw new Error('createShader failed');
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Shader error: ' + gl.getShaderInfoLog(s));
  return s;
};

export const GlobeLayer: React.FC<{u: GlobeUniforms; t: number}> = ({u, t}) => {
  const ref = useRef<HTMLCanvasElement>(null);
  const st = useRef<GLState | null>(null);
  const [handle] = useState(() => delayRender('earth texture'));
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    try {
      const gl = canvas.getContext('webgl2', {antialias: false, alpha: false, preserveDrawingBuffer: true});
      if (!gl) throw new Error('WebGL2 is not available (GL renderer problem). Use --gl=swangle.');
      const prog = gl.createProgram();
      if (!prog) throw new Error('createProgram failed');
      gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT));
      gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('Link error: ' + gl.getProgramInfoLog(prog));
      const loc: Record<string, WebGLUniformLocation | null> = {};
      for (const n of ['uTex', 'uCp', 'uCr', 'uCu', 'uF', 'uFocal', 'uAY', 'uTime']) loc[n] = gl.getUniformLocation(prog, n);
      const img = new Image();
      img.onload = () => {
        try {
          const maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE) as number;
          let source: TexImageSource = img;
          if (img.naturalWidth > maxTex) {
            // keep going with a smaller copy instead of failing (quality drops, but the video still renders)
            const c = document.createElement('canvas');
            c.width = maxTex;
            c.height = Math.round((maxTex * img.naturalHeight) / img.naturalWidth);
            const cx = c.getContext('2d');
            if (!cx) throw new Error('2D canvas missing');
            cx.drawImage(img, 0, 0, c.width, c.height);
            source = c;
          }
          const tex = gl.createTexture();
          gl.bindTexture(gl.TEXTURE_2D, tex);
          gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
          gl.generateMipmap(gl.TEXTURE_2D);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
          if (gl.getError() !== gl.NO_ERROR) throw new Error('Texture upload failed (WebGL error)');
          st.current = {gl, prog, loc};
          setReady(true);
          continueRender(handle);
        } catch (e) {
          cancelRender(e);
        }
      };
      img.onerror = () => cancelRender(new Error('Earth texture failed to load: earth/earth.jpg'));
      img.src = staticFile('earth/earth.jpg');
    } catch (e) {
      cancelRender(e);
    }
  }, [handle]);

  useLayoutEffect(() => {
    const s = st.current;
    if (!ready || !s) return;
    try {
      const {gl, prog, loc} = s;
      gl.viewport(0, 0, SCREEN_W, SCREEN_H);
      gl.useProgram(prog);
      gl.uniform1i(loc.uTex, 0);
      gl.uniform3f(loc.uCp, u.cp[0], u.cp[1], u.cp[2]);
      gl.uniform3f(loc.uCr, u.cr[0], u.cr[1], u.cr[2]);
      gl.uniform3f(loc.uCu, u.cu[0], u.cu[1], u.cu[2]);
      gl.uniform3f(loc.uF, u.f[0], u.f[1], u.f[2]);
      gl.uniform1f(loc.uFocal, u.focal);
      gl.uniform1f(loc.uAY, u.ay);
      gl.uniform1f(loc.uTime, t);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      if (gl.getError() !== gl.NO_ERROR) throw new Error('WebGL draw error');
    } catch (e) {
      cancelRender(e);
    }
  }, [ready, u, t]);

  return <canvas ref={ref} width={SCREEN_W} height={SCREEN_H} style={{position: 'absolute', left: 0, top: 0, width: SCREEN_W, height: SCREEN_H, background: '#0a3a78'}} />;
};
