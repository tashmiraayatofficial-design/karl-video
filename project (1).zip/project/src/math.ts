export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a), 0, 1);
export const eio3 = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const eioSine = (t: number) => -(Math.cos(Math.PI * t) - 1) / 2;
export const eoc = (t: number) => 1 - Math.pow(1 - t, 3);
export const eoExpo = (t: number) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));
export const eoBack = (t: number, s = 1.70158) => {
  const c3 = s + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + s * Math.pow(t - 1, 2);
};

// ---- Camera
export interface Cam {lon: number; lat: number; zoom: number; pitch: number; bearing: number}
export interface CamKey extends Cam {t: number; fly?: boolean; dip?: number}

export const camAt = (keys: CamKey[], t: number): Cam => {
  let base: Cam;
  if (t <= keys[0].t) base = keys[0];
  else if (t >= keys[keys.length - 1].t) base = keys[keys.length - 1];
  else {
    let i = 0;
    while (i < keys.length - 2 && t > keys[i + 1].t) i++;
    const a = keys[i];
    const b = keys[i + 1];
    const u = (t - a.t) / (b.t - a.t);
    const e = b.fly ? eio3(u) : 0.5 * u + 0.5 * eioSine(u);
    const dip = b.fly ? (b.dip ?? 0) * Math.sin(Math.PI * e) : 0;
    base = {
      lon: lerp(a.lon, b.lon, e),
      lat: lerp(a.lat, b.lat, e),
      zoom: lerp(a.zoom, b.zoom, e) - dip,
      pitch: lerp(a.pitch, b.pitch, e),
      bearing: lerp(a.bearing, b.bearing, e),
    };
  }
  // gentle continuous drift so the map is never still
  return {
    ...base,
    bearing: base.bearing + 1.4 * Math.sin((2 * Math.PI * t) / 8.5),
    zoom: base.zoom + 0.035 * Math.sin((2 * Math.PI * t) / 6.3),
  };
};

// ---- Globe camera (unit sphere, pinhole camera, no black anywhere)
export const SCREEN_W = 1080;
export const SCREEN_H = 1920;
export const ANCHOR_Y = 920; // screen y of the look-at point (keeps the focus in the middle zone)
export const FOCAL = 3600;
const D2R = Math.PI / 180;

type V3 = [number, number, number];
const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const mul = (a: V3, k: number): V3 => [a[0] * k, a[1] * k, a[2] * k];
const nrm = (a: V3): V3 => mul(a, 1 / Math.hypot(a[0], a[1], a[2]));

export const vec = (lon: number, lat: number): V3 => {
  const lo = lon * D2R;
  const la = lat * D2R;
  return [Math.cos(la) * Math.cos(lo), Math.cos(la) * Math.sin(lo), Math.sin(la)];
};

export interface Pt {x: number; y: number}
export interface SPt extends Pt {s: number; vis: boolean}

export interface GlobeUniforms {
  cp: V3; cr: V3; cu: V3; f: V3; focal: number; ay: number;
}

// build the camera vectors from lon/lat, zoom (px per radian = 256*2^zoom/2pi at the look point), pitch, bearing
const build = (cam: Cam): GlobeUniforms & {D: number} => {
  const S = 256 * Math.pow(2, cam.zoom);
  const D = (FOCAL * 2 * Math.PI) / S; // distance from the look point to the camera
  const p0 = vec(cam.lon, cam.lat);
  const lo = cam.lon * D2R;
  const la = cam.lat * D2R;
  const n0: V3 = [-Math.sin(la) * Math.cos(lo), -Math.sin(la) * Math.sin(lo), Math.cos(la)];
  const e0: V3 = [-Math.sin(lo), Math.cos(lo), 0];
  const b = cam.bearing * D2R;
  const up = add(mul(n0, Math.cos(b)), mul(e0, Math.sin(b)));
  const rt = sub(mul(e0, Math.cos(b)), mul(n0, Math.sin(b)));
  const tau = cam.pitch * D2R;
  const cp = add(p0, add(mul(p0, D * Math.cos(tau)), mul(up, -D * Math.sin(tau))));
  const f = nrm(sub(p0, cp));
  const cu = nrm(sub(up, mul(f, dot(up, f))));
  return {cp, cr: rt, cu, f, focal: FOCAL, ay: ANCHOR_Y, D};
};

// do all rays through the screen (plus a margin) hit the sphere?
const COVER_PTS: [number, number][] = (() => {
  const out: [number, number][] = [];
  const m = 140;
  for (const x of [-m, 270, 540, 810, SCREEN_W + m]) for (const y of [-m, 480, 960, 1440, SCREEN_H + m]) out.push([x, y]);
  return out;
})();
const covers = (u: GlobeUniforms): boolean => {
  for (const [px, py] of COVER_PTS) {
    const d = nrm(add(add(mul(u.f, u.focal), mul(u.cr, px - SCREEN_W / 2)), mul(u.cu, u.ay - py)));
    const b = dot(u.cp, d);
    const c = dot(u.cp, u.cp) - 1;
    if (b * b - c < 0.0004) return false; // missed, or grazing the horizon
    const t = -b - Math.sqrt(b * b - c);
    const h = add(u.cp, mul(d, t));
    // keep away from the extreme limb (the texture is squeezed there)
    if (dot(h, mul(d, -1)) < 0.12) return false;
  }
  return true;
};

export const ZOOM_MAX = 12.5;
// Convert a "map" camera (Web-Mercator style keys) to a globe camera that ALWAYS fills the screen.
export const globeCam = (c: Cam): Cam => {
  const lat = Math.min(70, Math.abs(c.lat));
  let zoom = c.zoom - 0.3 + Math.log2(1 / Math.cos(lat * D2R)); // same apparent size as the flat map at that latitude
  const pitch = Math.min(28, c.pitch * 0.55);
  let guard = 0;
  while (guard++ < 120 && !covers(build({...c, zoom, pitch}))) zoom += 0.05;
  return {lon: c.lon, lat: c.lat, zoom: Math.min(ZOOM_MAX, zoom), pitch, bearing: c.bearing};
};

export interface Projector {
  cam: Cam;
  u: GlobeUniforms;
  screen: (lon: number, lat: number) => SPt;
}

export const makeProjector = (mapCam: Cam): Projector => {
  const cam = globeCam(mapCam);
  const g = build(cam);
  const screen = (lon: number, lat: number): SPt => {
    const q = vec(lon, lat);
    const v = sub(q, g.cp);
    const z = dot(v, g.f);
    const x = dot(v, g.cr);
    const y = dot(v, g.cu);
    const zz = Math.max(0.02, z);
    const vis = z > 0.02 && dot(q, g.cp) > 1.0005;
    return {x: SCREEN_W / 2 + (g.focal * x) / zz, y: g.ay - (g.focal * y) / zz, s: g.D / zz, vis};
  };
  return {cam, u: g, screen};
};

// great-circle points between two lon/lat positions (inclusive), step in degrees
export const greatCircle = (a: [number, number], b: [number, number], stepDeg = 0.4): [number, number][] => {
  const va = vec(a[0], a[1]);
  const vb = vec(b[0], b[1]);
  const w = Math.acos(Math.min(1, Math.max(-1, dot(va, vb))));
  const n = Math.max(1, Math.ceil((w / D2R) / stepDeg));
  const out: [number, number][] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const k0 = w < 1e-9 ? 1 - t : Math.sin((1 - t) * w) / Math.sin(w);
    const k1 = w < 1e-9 ? t : Math.sin(t * w) / Math.sin(w);
    const p = add(mul(va, k0), mul(vb, k1));
    out.push([Math.atan2(p[1], p[0]) / D2R, Math.asin(Math.max(-1, Math.min(1, p[2]))) / D2R]);
  }
  return out;
};
export const angDist = (a: [number, number], b: [number, number]) =>
  Math.acos(Math.min(1, Math.max(-1, dot(vec(a[0], a[1]), vec(b[0], b[1]))))) ;

export const fmtInt = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
