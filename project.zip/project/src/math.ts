export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a), 0, 1);
export const eio3 = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const eioSine = (t: number) => -(Math.cos(Math.PI * t) - 1) / 2;
export const eoc = (t: number) => 1 - Math.pow(1 - t, 3);
export const eoExpo = (t: number) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));
export const eoBack = (t: number, s = 1.70158) => {
  const c3 = s + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + s * Math.pow(t - 1, 2);
};

// ---- Web Mercator, normalised 0..1 over the whole world
export const mx = (lon: number) => (lon + 180) / 360;
export const my = (lat: number) => {
  const r = (clamp(lat, -85, 85) * Math.PI) / 180;
  return (1 - Math.log(Math.tan(Math.PI / 4 + r / 2)) / Math.PI) / 2;
};

// ---- Camera
export interface Cam {lon: number; lat: number; zoom: number; pitch: number; bearing: number}
export interface CamKey extends Cam {t: number; fly?: boolean; dip?: number}

export const camAt = (keys: CamKey[], t: number): Cam => {
  let base: Cam;
  if (t <= keys[0].t) base = keys[0];
  else if (t >= keys[keys.length - 1].t) base = keys[keys.length - 1];
  else {
    let i = 0;
    while (i < keys.length - 2 && t > keys[i + 1].t) i++;
    const a = keys[i];
    const b = keys[i + 1];
    const u = (t - a.t) / (b.t - a.t);
    const e = b.fly ? eio3(u) : 0.5 * u + 0.5 * eioSine(u);
    const dip = b.fly ? (b.dip ?? 0) * Math.sin(Math.PI * e) : 0;
    base = {
      lon: lerp(a.lon, b.lon, e),
      lat: lerp(a.lat, b.lat, e),
      zoom: lerp(a.zoom, b.zoom, e) - dip,
      pitch: lerp(a.pitch, b.pitch, e),
      bearing: lerp(a.bearing, b.bearing, e),
    };
  }
  // gentle continuous drift so the map is never still
  return {
    ...base,
    bearing: base.bearing + 1.4 * Math.sin((2 * Math.PI * t) / 8.5),
    zoom: base.zoom + 0.035 * Math.sin((2 * Math.PI * t) / 6.3),
  };
};

// ---- Plane geometry (the tilted map plane)
export const PW = 3200;
export const PH_UP = 3000;
export const PH_DN = 1000;
export const PH = PH_UP + PH_DN;
export const AX = PW / 2;
export const AY = PH_UP;
export const ANCHOR_Y = 1050;
export const PERSP = 1800;
export const SCREEN_W = 1080;
export const SCREEN_H = 1920;

export interface Pt {x: number; y: number}
export interface SPt extends Pt {s: number}

export interface Projector {
  cam: Cam;
  S: number;
  plane: (lon: number, lat: number) => Pt;
  fromPlane: (px: number, py: number) => SPt;
  screen: (lon: number, lat: number) => SPt;
}

export const makeProjector = (cam: Cam): Projector => {
  const S = 256 * Math.pow(2, cam.zoom);
  const cx = mx(cam.lon);
  const cy = my(cam.lat);
  const pr = (cam.pitch * Math.PI) / 180;
  const br = (cam.bearing * Math.PI) / 180;
  const cb = Math.cos(br);
  const sb = Math.sin(br);
  const cp = Math.cos(pr);
  const sp = Math.sin(pr);
  const plane = (lon: number, lat: number): Pt => ({x: AX + (mx(lon) - cx) * S, y: AY + (my(lat) - cy) * S});
  const fromPlane = (px: number, py: number): SPt => {
    const x = px - AX;
    const y = py - AY;
    const x1 = x * cb - y * sb;
    const y1 = x * sb + y * cb;
    const z = y1 * sp;
    const s = PERSP / Math.max(250, PERSP - z);
    return {x: SCREEN_W / 2 + x1 * s, y: ANCHOR_Y + y1 * cp * s, s};
  };
  const screen = (lon: number, lat: number): SPt => {
    const p = plane(lon, lat);
    return fromPlane(p.x, p.y);
  };
  return {cam, S, plane, fromPlane, screen};
};

export const planeTransform = (cam: Cam) =>
  `perspective(${PERSP}px) rotateX(${cam.pitch}deg) rotateZ(${cam.bearing}deg)`;

export const fmtInt = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
