import React from 'react';
import {Img} from 'remotion';
import {AX, AY, PH, PW, Projector, SCREEN_H, SCREEN_W, mx, my} from './math';
import {TILE_MAX_Z, TILE_URL} from './config';
import world from '../public/data/world.json';
import {REG} from './config';

// Satellite tiles (Web Mercator) laid on the flat plane; the plane itself is tilted by CSS.
export const TileLayer: React.FC<{proj: Projector}> = ({proj}) => {
  const {cam, S} = proj;
  const tz = Math.max(1, Math.min(TILE_MAX_Z, Math.round(cam.zoom)));
  const n = Math.pow(2, tz);
  const ts = 256 * Math.pow(2, cam.zoom - tz);
  const cx = mx(cam.lon);
  const cy = my(cam.lat);
  const x0 = Math.floor(((0 - AX) / S + cx) * n) - 1;
  const x1 = Math.ceil(((PW - AX) / S + cx) * n) + 1;
  const y0 = Math.max(0, Math.floor(((0 - AY) / S + cy) * n) - 1);
  const y1 = Math.min(n - 1, Math.ceil(((PH - AY) / S + cy) * n) + 1);
  const tiles: React.ReactNode[] = [];
  for (let x = x0; x <= x1; x++) {
    for (let y = y0; y <= y1; y++) {
      const px = AX + (x / n - cx) * S;
      const py = AY + (y / n - cy) * S;
      if (px < 0 || py < 0 || px + ts > PW || py + ts > PH) continue;
      const c = [proj.fromPlane(px, py), proj.fromPlane(px + ts, py), proj.fromPlane(px, py + ts), proj.fromPlane(px + ts, py + ts)];
      const minX = Math.min(...c.map((q) => q.x));
      const maxX = Math.max(...c.map((q) => q.x));
      const minY = Math.min(...c.map((q) => q.y));
      const maxY = Math.max(...c.map((q) => q.y));
      if (maxX < -150 || minX > SCREEN_W + 150 || maxY < -150 || minY > SCREEN_H + 150) continue;
      const wx = ((x % n) + n) % n;
      tiles.push(
        <Img
          key={`${tz}/${x}/${y}`}
          src={TILE_URL(tz, wx, y)}
          style={{position: 'absolute', left: px, top: py, width: ts + 0.7, height: ts + 0.7}}
        />,
      );
    }
  }
  return <>{tiles}</>;
};

// Preview fallback (inputProps {"noTiles": true}): Natural Earth land drawn as vectors.
export const VectorMap: React.FC<{proj: Projector}> = ({proj}) => {
  const ring = (r: number[][]) => r.map((p, i) => {
    const q = proj.plane(p[0], p[1]);
    return `${i ? 'L' : 'M'}${q.x.toFixed(1)} ${q.y.toFixed(1)}`;
  }).join('') + 'Z';
  const detailed = Object.values(REG).flatMap((r) => r.rings);
  return (
    <svg width={PW} height={PH} style={{position: 'absolute', left: 0, top: 0}}>
      <rect width={PW} height={PH} fill="#0d2a52" />
      {(world as number[][][]).map((r, i) => (
        <path key={i} d={ring(r)} fill="#4d5b46" stroke="#7d8b6c" strokeWidth={1.5} />
      ))}
      {detailed.map((r, i) => (
        <path key={'d' + i} d={ring(r)} fill="#4d5b46" stroke="#7d8b6c" strokeWidth={1.5} />
      ))}
    </svg>
  );
};
