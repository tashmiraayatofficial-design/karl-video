# HANDOFF – Karl Bushby explainer (Remotion)

## 1. Subject / type / duration
Motion-graphics explainer: Karl Bushby's 28-year walk from Punta Arenas (Chile) to Hull (England).
SRT ends at 126.48 s; composition = 128.08 s (3,843 frames) incl. 1.6 s closing hold. Voiceover MP3 is 126.67 s.

## 2. User choices
- Style: 1 – Cinematic Route Map (Dark Tech, persistent map layer + foreground UI)
- Colours: 1 – Expedition Night: bg #0B1220, hero #F5A524, accent #3FA9F5, text #F4F1EA (all in src/theme.ts)
- Aspect ratio: 9:16 (1080x1920), 30 fps
- Fonts: Hello Botuna (hero, user-supplied, PERSONAL-USE licence) + Inter (body)

## 3. Scenes (all 15 written; preview stills checked)
S01 hook (kinetic) · S02 portrait card · S03 route overview · S04 two rules · S05 Colombia/Darien Gap ·
S06 terrain + 18 days · S07 timeline rail · S08 Bering Strait/14 days · S09 hub & spoke obstacles ·
S10 5,600 km dashboard · S11 land vs swim split + flow · S12 English Channel kinetic · S13 bento arrival ·
S14 15-of-28 waffle · S15 recap grid + bookend close.
Remaining: user review of scenes; MP4 render only when user says "Render it".

## 4. Assumptions / uncertainties
- Scene boundaries = SRT cue boundaries (src/timeline.ts). Word timing = cue split evenly (approximate).
- Route lines are illustrative waypoints (src/map/geo.ts), not exact GPS.
- Portrait (public/images/portrait.jpg) is low-resolution (735x415); it is upscaled and may look soft.
- SFX: only the 3 user files (whoosh/alarm/pop), trimmed copies in public/sfx, originals in public/sfx/original.
- [sigh] tags in the SRT are not shown on screen.

## 5. Commands
npm install
npx remotion studio
npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17
Chromium fallback: add --browser-executable=<path to chrome-headless-shell>; lower --concurrency if memory is short.
Voiceover preview flag: VOICEOVER_IN_RENDER in src/Main.tsx (default false; plays in Studio only).
Stills helper: node scripts/stills.mjs <seconds...>

## 5b. Review pass (static audit, no render possible in that session: no network, so npm install failed)
Fixed: S13 wt('arrived') and wt('November') matched earlier words (24 s / 7.8 s) instead of 108.9 s / 102.2 s;
camera keyframe at B[8]+2.0 was out of order (camera snapped near 66 s), now wt('Russia',64)-0.5;
all raw hex codes moved into theme.ts (mesh1, mesh2, black); added easing/clamp to ice-floe fade and S02 Ken Burns;
whoosh.wav de-clipped (peak 0.89).
Verified by script: every wt()/we() lookup resolves inside its scene window; camera/dim keys strictly increase; SEGS/PINS from<to.
NOT yet visually re-checked after these fixes: run `node scripts/stills.mjs 66 105 110` on a machine with network, or render.

## 5c. Visual check + fixes (session with network)
Checked stills at 66/105/110/112 s: camera and word timing OK. Fixed in S13: date/duration cards no longer wrap (font 35, nowrap), headline width fixed to 1080 so it centres, Hull route (segment J in src/map/geo.ts) now follows a curved waypoint path instead of straight lines. Known: during the word stagger the headline looks slightly off-centre because unrevealed words still reserve space; final state is centred.

## 6. Next step
Ask the user for scene changes, apply them, then render when they say "Render it".
