import data from './data/words.json';
import {FPS} from './theme';

// Word timings are the SRT cue duration split evenly across the words in each cue (approximate).
type W = {w: string; start: number; end: number};
const words = data.words as W[];
const norm = (s: string) => s.toLowerCase().replace(/[\u2019']/g, '').replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, '');

/** Start time (s) of the nth word matching `token`, searching from `after` seconds. */
export const wt = (token: string, after = 0, nth = 0): number => {
  const t = norm(token);
  const hits = words.filter((w) => w.start >= after - 0.001 && norm(w.w) === t);
  if (!hits[nth]) throw new Error(`timing: "${token}" not found after ${after}s`);
  return hits[nth].start;
};
/** End time (s) of the same word. */
export const we = (token: string, after = 0, nth = 0): number => {
  const t = norm(token);
  const hits = words.filter((w) => w.start >= after - 0.001 && norm(w.w) === t);
  if (!hits[nth]) throw new Error(`timing: "${token}" not found after ${after}s`);
  return hits[nth].end;
};
export const sec = (s: number) => Math.round(s * FPS);
export const SRT_END = (data.cues as {end: number}[]).at(-1)!.end;
