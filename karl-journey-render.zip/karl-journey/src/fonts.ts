import {continueRender, delayRender, staticFile} from 'remotion';

const faces: [string, string, string?][] = [
  ['Hello Botuna', 'fonts/HelloBotuna.ttf'],
  ['Inter', 'fonts/inter-latin-400-normal.woff2', '400'],
  ['Inter', 'fonts/inter-latin-600-normal.woff2', '600'],
  ['Inter', 'fonts/inter-latin-800-normal.woff2', '800'],
];
let started = false;
export const loadFonts = () => {
  if (started || typeof document === 'undefined') return;
  started = true;
  const h = delayRender('fonts');
  Promise.all(
    faces.map(([family, file, weight]) => {
      const f = new FontFace(family, `url(${staticFile(file)})`, weight ? {weight} : {});
      return f.load().then((l) => document.fonts.add(l));
    }),
  )
    .then(() => continueRender(h))
    .catch(() => continueRender(h)); // fall back to system fonts rather than failing the render
};
