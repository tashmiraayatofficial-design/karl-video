import {SRT_END} from './timing';
export const TAIL = 1.6; // seconds of calm hold after the last spoken word
// Scene boundaries (seconds) – every boundary is an SRT cue boundary.
export const B = [0, 4.36, 9.66, 18.18, 25.66, 36.46, 43.18, 51.4, 64.2, 73.28, 83.22, 95.54, 102.18, 114.9, 122.16, SRT_END + TAIL];
export const TOTAL_SEC = B[B.length - 1];
