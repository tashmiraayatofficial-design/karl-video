import {B} from './timeline';
import {wt} from './timing';

export type Sfx = {t: number; type: 'whoosh' | 'pop' | 'alarm'; vol: number};
// Limited set of 3 sounds (user-provided), reused for the same kind of event. Start 2-3 frames before the visual lands.
export const SFX_EVENTS: Sfx[] = [
  {t: 0.05, type: 'whoosh', vol: 0.3},                       // hook
  {t: 0.9, type: 'pop', vol: 0.3},                           // 28 lands
  {t: B[1] + 0.12, type: 'whoosh', vol: 0.22},               // portrait
  {t: wt('November') - 0.15, type: 'pop', vol: 0.28},        // date chip
  {t: B[2] + 0.05, type: 'whoosh', vol: 0.22},               // map zoom
  {t: wt('Punta') - 0.15, type: 'pop', vol: 0.28},
  {t: wt('expedition') - 0.15, type: 'pop', vol: 0.26},
  {t: wt('dollars.') - 0.9, type: 'pop', vol: 0.26},
  {t: wt('Hull', 9) - 0.2, type: 'pop', vol: 0.3},
  {t: B[3] + 0.05, type: 'whoosh', vol: 0.22},               // rules
  {t: wt('no') - 0.12, type: 'pop', vol: 0.28},
  {t: wt('and', 22) - 0.12, type: 'pop', vol: 0.28},
  {t: B[4] + 0.05, type: 'whoosh', vol: 0.22},
  {t: wt('Darien') - 0.15, type: 'alarm', vol: 0.18},        // danger
  {t: B[5] + 0.05, type: 'whoosh', vol: 0.2},
  {t: wt('forests,') - 0.12, type: 'pop', vol: 0.26},
  {t: wt('swamps,') - 0.12, type: 'pop', vol: 0.26},
  {t: wt('imprisoned') - 0.15, type: 'alarm', vol: 0.16},    // prison
  {t: B[6] + 0.05, type: 'whoosh', vol: 0.22},
  {t: B[7] + 0.05, type: 'whoosh', vol: 0.24},
  {t: wt('Dimitri') - 0.15, type: 'pop', vol: 0.26},
  {t: wt('14') - 0.15, type: 'pop', vol: 0.3},
  {t: B[8] + 0.05, type: 'whoosh', vol: 0.22},
  {t: wt('visa', 64) - 0.15, type: 'pop', vol: 0.26},
  {t: B[9] + 0.05, type: 'whoosh', vol: 0.22},
  {t: wt('5,600') - 0.15, type: 'pop', vol: 0.3},
  {t: B[10] + 0.05, type: 'whoosh', vol: 0.22},
  {t: B[11] + 0.05, type: 'whoosh', vol: 0.26},
  {t: wt('swam', 95) - 0.15, type: 'pop', vol: 0.28},
  {t: B[12] + 0.05, type: 'whoosh', vol: 0.24},
  {t: wt('50,000') - 0.2, type: 'pop', vol: 0.3},
  {t: B[13] + 0.05, type: 'whoosh', vol: 0.24},
  {t: wt('15') - 0.15, type: 'pop', vol: 0.28},
  {t: B[14] + 0.05, type: 'whoosh', vol: 0.22},
  {t: wt('time.') - 0.3, type: 'whoosh', vol: 0.2},
];
