import React, {createContext, useContext} from 'react';
import {interpolate, spring, useCurrentFrame} from 'remotion';
import {C, EASE, EXIT_FRAMES, FONT_BODY, FONT_DISPLAY, FPS, RADIUS, SHADOW, SPRING} from '../theme';
import {Icon, IconName} from './Icons';

// ---- scene context: absolute seconds -> local frames ---------------------------
export const SceneCtx = createContext({start: 0, end: 1, frames: 30});
export const useAt = () => {
  const {start} = useContext(SceneCtx);
  return (s: number, lead = 5) => Math.round((s - start) * FPS) - lead; // visuals land ~5 frames before the spoken word
};
export const useFrames = () => useContext(SceneCtx).frames;

/** Scene wrapper: foreground exits quickly (faster than entrances) in the last frames. */
export const Scene: React.FC<{children: React.ReactNode}> = ({children}) => {
  const frame = useCurrentFrame();
  const {frames} = useContext(SceneCtx);
  const ex = interpolate(frame, [frames - EXIT_FRAMES, frames - 1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.exit});
  return <div style={{position: 'absolute', inset: 0, opacity: 1 - ex, transform: `translateY(${-18 * ex}px)`}}>{children}</div>;
};

// ---- entrance (opacity + rise + scale together) -----------------------------------
export const Enter: React.FC<{at?: number; dy?: number; dx?: number; s0?: number; preset?: keyof typeof SPRING; exitAt?: number; float?: number; style?: React.CSSProperties; children: React.ReactNode}> = ({at = 0, dy = 44, dx = 0, s0 = 0.9, preset = 'pop', exitAt, float = 0, style, children}) => {
  const frame = useCurrentFrame();
  const p = spring({frame: frame - at, fps: FPS, config: SPRING[preset]});
  const ex = exitAt != null ? interpolate(frame, [exitAt, exitAt + EXIT_FRAMES], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.exit}) : 0;
  if (frame < at - 1) return null;
  const fl = float ? Math.sin(frame / 36 + at) * float * Math.min(1, p) : 0;
  return (
    <div style={{opacity: Math.min(1, p * 1.5) * (1 - ex), transform: `translate(${(1 - p) * dx}px, ${(1 - p) * dy - 26 * ex + fl}px) scale(${(s0 + (1 - s0) * p) * (1 - 0.05 * ex)})`, ...style}}>
      {children}
    </div>
  );
};

// ---- word-by-word stagger (default headline animation) --------------------------------
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
export const Words: React.FC<{text: string; at?: number; times?: number[]; per?: number; size?: number; color?: string; weight?: number; font?: string; align?: 'left' | 'center' | 'right'; hl?: string[]; hlColor?: string; lh?: number; exitAt?: number; style?: React.CSSProperties; dy?: number; maxWidth?: number}> = ({
  text, at = 0, times, per = 4, size = 96, color = C.text, weight = 800, font = FONT_DISPLAY, align = 'center', hl = [], hlColor = C.hero, lh = 1.06, exitAt, style, dy = 50, maxWidth,
}) => {
  const frame = useCurrentFrame();
  const words = text.split(' ');
  const ex = exitAt != null ? interpolate(frame, [exitAt, exitAt + EXIT_FRAMES], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.exit}) : 0;
  return (
    <div style={{fontFamily: font, fontSize: size, fontWeight: weight, color, textAlign: align, lineHeight: lh, maxWidth, opacity: 1 - ex, transform: `translateY(${-20 * ex}px)`, ...style}}>
      {words.map((w, i) => {
        const start = times ? times[i] : at + i * per;
        const p = spring({frame: frame - start, fps: FPS, config: SPRING.pop});
        const isHl = hl.map(norm).includes(norm(w));
        return (
          <span key={i} style={{display: 'inline-block', marginRight: i < words.length - 1 ? '0.26em' : 0, opacity: Math.min(1, p * 1.6), transform: `translateY(${(1 - p) * dy}px) scale(${0.86 + 0.14 * p})`, color: isHl ? hlColor : color}}>{w}</span>
        );
      })}
    </div>
  );
};

// ---- counter roll (only used for numbers that appear in the script) -------------------------
export const useCounter = (to: number, at: number, dur = 30) => {
  const frame = useCurrentFrame();
  const v = interpolate(frame, [at, at + dur], [0, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.out});
  return Math.round(v);
};
export const Counter: React.FC<{to: number; at: number; dur?: number; size?: number; color?: string; style?: React.CSSProperties; suffix?: string}> = ({to, at, dur = 30, size = 200, color = C.hero, style, suffix = ''}) => {
  const frame = useCurrentFrame();
  const v = useCounter(to, at, dur);
  const settle = interpolate(frame, [at + dur - 2, at + dur + 6, at + dur + 16], [1, 1.07, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.out});
  return <span style={{fontFamily: FONT_DISPLAY, fontSize: size, color, fontVariantNumeric: 'tabular-nums', display: 'inline-block', transform: `scale(${settle})`, lineHeight: 1, ...style}}>{v.toLocaleString('en-US')}{suffix}</span>;
};

// ---- glass surfaces ------------------------------------------------------------------------------
export const Glass: React.FC<{children?: React.ReactNode; style?: React.CSSProperties; pad?: number; tone?: 'plain' | 'hero'}> = ({children, style, pad = 30, tone = 'plain'}) => (
  <div style={{background: tone === 'hero' ? `linear-gradient(160deg, ${C.heroSoft}, ${C.glass})` : `linear-gradient(160deg, ${C.glass}, ${C.shade})`, border: `1.5px solid ${tone === 'hero' ? C.hero : C.glassEdge}`, borderRadius: RADIUS, padding: pad, boxShadow: SHADOW, backdropFilter: 'blur(18px)', ...style}}>{children}</div>
);

export const Chip: React.FC<{icon?: IconName; text: string; size?: number; color?: string; style?: React.CSSProperties}> = ({icon, text, size = 40, color = C.text, style}) => (
  <Glass pad={0} style={{display: 'inline-flex', alignItems: 'center', gap: 18, padding: '18px 30px', borderRadius: 999, ...style}}>
    {icon && <Icon name={icon} size={size * 1.2} color={C.accent} />}
    <span style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: size, color, whiteSpace: 'nowrap'}}>{text}</span>
  </Glass>
);

/** Thin horizontal reveal (line-mask) used for names/titles. */
export const Mask: React.FC<{at: number; dur?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({at, dur = 16, children, style}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [at, at + dur], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.out});
  return <div style={{overflow: 'hidden', ...style}}><div style={{transform: `translateY(${(1 - p) * 105}%)`}}>{children}</div></div>;
};

export const Label: React.FC<{children: React.ReactNode; size?: number; color?: string; weight?: number; align?: 'left' | 'center'; style?: React.CSSProperties}> = ({children, size = 44, color = C.textDim, weight = 600, align = 'center', style}) => (
  <div style={{fontFamily: FONT_BODY, fontSize: size, fontWeight: weight, color, textAlign: align, lineHeight: 1.2, ...style}}>{children}</div>
);
