import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, W, alpha} from '../theme';

// Layer 1: animated colour mesh (never a flat single colour)
export const Backdrop: React.FC = () => {
  const f = useCurrentFrame();
  const a = Math.sin(f / 170), b = Math.cos(f / 210);
  return (
    <AbsoluteFill style={{background: C.bgDeep}}>
      <AbsoluteFill style={{background: `radial-gradient(900px 900px at ${30 + 8 * a}% ${22 + 5 * b}%, ${alpha(C.mesh1, 0.5)}, transparent 70%), radial-gradient(1000px 1000px at ${75 - 8 * b}% ${78 + 4 * a}%, ${alpha(C.mesh2, 0.55)}, transparent 70%), radial-gradient(700px 700px at 85% 12%, ${C.accentSoft}, transparent 70%)`}} />
    </AbsoluteFill>
  );
};

const GRAIN = `url("data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='${256}' height='${256}'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.55 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>`)}")`;

// Layers 4-5: colour grade (top/bottom scrims), grain and vignette
export const Finish: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: `linear-gradient(180deg, ${alpha(C.bgDeep, 0.78)} 0%, transparent 22%, transparent 66%, ${alpha(C.bgDeep, 0.82)} 100%)`}} />
      <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 46%, transparent 52%, ${alpha(C.black, 0.55)} 100%)`}} />
      <AbsoluteFill style={{backgroundImage: GRAIN, backgroundSize: '256px 256px', backgroundPosition: `${(f * 37) % 256}px ${(f * 91) % 256}px`, opacity: 0.07, mixBlendMode: 'overlay'}} />
    </AbsoluteFill>
  );
};
export const WIDTH = W;
