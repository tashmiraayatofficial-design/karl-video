import React from 'react';
import {C} from '../theme';

export type IconName = 'cart' | 'coin' | 'home' | 'novehicle' | 'foot' | 'tree' | 'waves' | 'bars' | 'visa' | 'barrier' | 'clock' | 'snow' | 'person' | 'docs' | 'swim' | 'route' | 'calendar' | 'pin' | 'arrow' | 'check' | 'ruler';

// All icons are drawn in SVG on a 48x48 grid (stroke-based, theme colours only; no emojis)
const D: Record<IconName, React.ReactNode> = {
  cart: <><path d="M5 9h6l4 20h20l4-14H13" /><circle cx="19" cy="37" r="3" /><circle cx="33" cy="37" r="3" /></>,
  coin: <><circle cx="24" cy="24" r="17" /><path d="M29 17.5c-1-2-3-3-5-3-3 0-5 1.5-5 4 0 6.5 10 3 10 8.5 0 2.5-2 4-5 4-2.5 0-4.5-1-5.5-3M24 10.5v4M24 33.5v4" /></>,
  home: <><path d="M6 23 24 8l18 15" /><path d="M11 20v19h26V20" /><path d="M20 39V28h8v11" /></>,
  novehicle: <><path d="M7 29l4-10h26l4 10v8H7z" /><circle cx="14" cy="37" r="3" /><circle cx="34" cy="37" r="3" /><path d="M8 8l32 32" /></>,
  foot: <><ellipse cx="17" cy="30" rx="6" ry="9" /><ellipse cx="32" cy="18" rx="6" ry="9" /><circle cx="14" cy="16" r="1.6" /><circle cx="19" cy="14.5" r="1.6" /><circle cx="29" cy="34" r="1.6" /><circle cx="34" cy="32.5" r="1.6" /></>,
  tree: <><path d="M24 6 12 22h7L9 34h30L29 22h7z" /><path d="M24 34v9" /></>,
  waves: <><path d="M4 16q5-6 10 0t10 0 10 0 10 0" /><path d="M4 26q5-6 10 0t10 0 10 0 10 0" /><path d="M4 36q5-6 10 0t10 0 10 0 10 0" /></>,
  bars: <><rect x="8" y="7" width="32" height="34" rx="4" /><path d="M16 7v34M24 7v34M32 7v34" /></>,
  visa: <><rect x="11" y="5" width="26" height="38" rx="3" /><circle cx="24" cy="20" r="6" /><path d="M17 33h14M19 38h10" /></>,
  barrier: <><rect x="5" y="14" width="38" height="11" rx="2" /><path d="M13 14l-6 11M23 14l-6 11M33 14l-6 11M43 14l-6 11M11 25v16M37 25v16" /></>,
  clock: <><circle cx="24" cy="24" r="18" /><path d="M24 12v13l9 5" /></>,
  snow: <><path d="M24 5v38M7.5 14.5l33 19M7.5 33.5l33-19" /><path d="M20 8l4 4 4-4M20 40l4-4 4 4" /></>,
  person: <><circle cx="24" cy="15" r="8" /><path d="M8 42c0-9 7-15 16-15s16 6 16 15" /></>,
  docs: <><rect x="9" y="11" width="24" height="31" rx="3" /><path d="M15 6h22a3 3 0 0 1 3 3v27" /><path d="M15 21h12M15 28h12M15 35h7" /></>,
  swim: <><circle cx="31" cy="12" r="4" /><path d="M10 22l10-5 9 6" /><path d="M4 33q5-5 10 0t10 0 10 0 10 0" /><path d="M4 41q5-5 10 0t10 0 10 0 10 0" /></>,
  route: <><circle cx="11" cy="37" r="4" /><circle cx="37" cy="11" r="4" /><path d="M15 37h14a6 6 0 0 0 0-12H19a6 6 0 0 1 0-12h14" /></>,
  calendar: <><rect x="6" y="9" width="36" height="33" rx="4" /><path d="M6 19h36M15 5v8M33 5v8" /></>,
  pin: <><path d="M24 43S9 29 9 19a15 15 0 0 1 30 0c0 10-15 24-15 24z" /><circle cx="24" cy="19" r="5" /></>,
  arrow: <><path d="M6 24h34M28 12l12 12-12 12" /></>,
  check: <><path d="M8 25l10 10L40 13" /></>,
  ruler: <><rect x="4" y="16" width="40" height="16" rx="3" /><path d="M12 16v7M20 16v10M28 16v7M36 16v10" /></>,
};

export const Icon: React.FC<{name: IconName; size?: number; color?: string; stroke?: number; style?: React.CSSProperties}> = ({name, size = 64, color = C.accent, stroke = 2.6, style}) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={style}>{D[name]}</svg>
);
