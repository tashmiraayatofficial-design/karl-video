import React from 'react';
import {Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C, EASE, FONT_BODY, FONT_DISPLAY, RADIUS, SHADOW, alpha} from '../theme';
import {Chip, Counter, Enter, Glass, Label, Mask, Scene, Words, useAt, useFrames} from '../components/ui';
import {Icon} from '../components/Icons';
import {wt} from '../timing';

const Abs: React.FC<{top?: number; bottom?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({top, bottom, children, style}) => (
  <div style={{position: 'absolute', left: 0, right: 0, top, bottom, display: 'flex', flexDirection: 'column', alignItems: 'center', ...style}}>{children}</div>
);

// ===== S01 · Hook · Kinetic Typography ==================================================================
export const S01: React.FC = () => {
  const at = useAt();
  return (
    <Scene>
      <Abs top={300}><Enter at={2} dy={30}><Label size={60} color={C.textDim} weight={600}>Imagine spending</Label></Enter></Abs>
      <Abs top={430}><Enter at={at(0.6, 0)} dy={90} s0={0.7} float={5}><Counter to={28} at={at(0.55, 0)} dur={26} size={560} /></Enter></Abs>
      <Abs top={1000}><Words text="years" at={at(1.26)} size={210} /></Abs>
      <Abs top={1290}><Words text="trying to walk home." times={['trying', 'to', 'walk', 'home.'].map((w, i) => at(wt(w, 1.2)))} size={92} weight={400} font={FONT_BODY} color={C.textDim} /></Abs>
    </Scene>
  );
};

// ===== S02 · Portrait / glass ID card ========================================================================
export const S02: React.FC = () => {
  const at = useAt();
  const frame = useCurrentFrame();
  const frames = useFrames();
  const kb = interpolate(frame, [0, frames], [1.04, 1.16], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.inOut});
  const br = {position: 'absolute' as const, width: 70, height: 70, borderColor: C.hero, borderStyle: 'solid' as const, borderWidth: 0};
  return (
    <Scene>
      <Abs top={250}>
        <Enter at={0} dy={90} s0={0.9} preset="soft" float={4}>
          <div style={{position: 'relative', width: 820, height: 840, borderRadius: RADIUS, overflow: 'hidden', boxShadow: SHADOW, border: `1.5px solid ${C.glassEdge}`}}>
            <Img src={staticFile('images/portrait.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: '50% 38%', transform: `scale(${kb})`}} />
            <div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg, ${alpha(C.bg, 0.15)}, ${alpha(C.bg, 0)} 40%, ${alpha(C.bg, 0.75)})`}} />
            <div style={{position: 'absolute', inset: 0, background: C.accentSoft, mixBlendMode: 'soft-light'}} />
            <div style={{...br, left: 26, top: 26, borderLeftWidth: 5, borderTopWidth: 5, borderTopLeftRadius: 16}} />
            <div style={{...br, right: 26, top: 26, borderRightWidth: 5, borderTopWidth: 5, borderTopRightRadius: 16}} />
            <div style={{...br, left: 26, bottom: 26, borderLeftWidth: 5, borderBottomWidth: 5, borderBottomLeftRadius: 16}} />
            <div style={{...br, right: 26, bottom: 26, borderRightWidth: 5, borderBottomWidth: 5, borderBottomRightRadius: 16}} />
          </div>
        </Enter>
      </Abs>
      <Abs top={1150}><Mask at={at(wt('Karl'), 3)} dur={18}><div style={{fontFamily: FONT_DISPLAY, fontSize: 138, color: C.text, lineHeight: 1.1}}>Karl Bushby</div></Mask></Abs>
      <Abs top={1320}><Enter at={at(wt('former'))} dy={30}><Label size={48} weight={700} color={C.textDim}>Former British paratrooper</Label></Enter></Abs>
      <Abs top={1440}><Enter at={at(wt('November'))} dy={40}><Chip icon="calendar" text="November 1, 1998" size={44} /></Enter></Abs>
    </Scene>
  );
};

// ===== S03 · Route overview (Punta Arenas -> Hull) ================================================================
export const S03: React.FC = () => {
  const at = useAt();
  return (
    <Scene>
      <Abs top={1300}><Enter at={at(wt('expedition'))} dy={50}><Chip icon="cart" text="Expedition cart" size={46} /></Enter></Abs>
      <Abs top={1440}><Enter at={at(wt('few'))} dy={50}><Chip icon="coin" text="A few hundred dollars" size={46} /></Enter></Abs>
      <Abs top={300}><Enter at={at(wt('mother\u2019s'))} dy={40}><Chip icon="home" text="His mother’s home" size={46} /></Enter></Abs>
    </Scene>
  );
};

// ===== S04 · Statement cards: the two rules ========================================================================
const Rule: React.FC<{n: number; at: number; icon: 'novehicle' | 'home'; text: string}> = ({n, at, icon, text}) => (
  <Enter at={at} dy={70} dx={n === 1 ? -60 : 60} s0={0.92}>
    <Glass style={{width: 920, display: 'flex', alignItems: 'center', gap: 36}} pad={38}>
      <div style={{width: 150, height: 150, borderRadius: 30, background: C.accentSoft, border: `1.5px solid ${C.accentLine}`, display: 'grid', placeItems: 'center', flexShrink: 0}}>
        <Icon name={icon} size={92} color={C.accent} stroke={2.4} />
      </div>
      <div>
        <div style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 32, color: C.textDim, marginBottom: 10}}>Rule {n}</div>
        <div style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 56, color: C.text, lineHeight: 1.12}}>{text}</div>
      </div>
    </Glass>
  </Enter>
);
export const S04: React.FC = () => {
  const at = useAt();
  return (
    <Scene>
      <Abs top={300}><Words text="Two rules" times={[at(wt('two')), at(wt('rules:'))]} size={190} color={C.hero} /></Abs>
      <Abs top={700}><Rule n={1} at={at(wt('no'))} icon="novehicle" text="No transportation to advance his journey" /></Abs>
      <Abs top={1110}><Rule n={2} at={at(wt('and', 22))} icon="home" text="No returning home until he arrives on foot" /></Abs>
    </Scene>
  );
};

// ===== S05 · Colombia and the Darien Gap =============================================================================
export const S05: React.FC = () => {
  const at = useAt();
  const tYear = at(wt('2001,'));
  return (
    <Scene>
      <Abs top={290}><Words text="South America" at={at(wt('South'))} per={5} size={120} exitAt={tYear - 2} /></Abs>
      <Abs top={250}><Words text="2001" at={tYear} size={260} color={C.hero} /></Abs>
      <Abs top={1230}>
        <Enter at={at(wt('notorious'))} dy={70} float={4}>
          <Glass style={{width: 900, display: 'flex', alignItems: 'center', gap: 34}} pad={36}>
            <Icon name="tree" size={120} color={C.accent} stroke={2.2} />
            <div>
              <div style={{fontFamily: FONT_DISPLAY, fontSize: 112, color: C.text, lineHeight: 1}}>Darien Gap</div>
              <div style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 38, color: C.textDim, marginTop: 14, lineHeight: 1.25}}>Dangerous jungle between Colombia and Panama</div>
            </div>
          </Glass>
        </Enter>
      </Abs>
    </Scene>
  );
};
