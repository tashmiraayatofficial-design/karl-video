import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {C, EASE, FONT_BODY, FONT_DISPLAY, alpha} from '../theme';
import {Chip, Counter, Enter, Glass, Label, Scene, Words, useAt} from '../components/ui';
import {Icon, IconName} from '../components/Icons';
import {wt, we} from '../timing';

const Abs: React.FC<{top?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({top, children, style}) => (
  <div style={{position: 'absolute', left: 0, right: 0, top, display: 'flex', flexDirection: 'column', alignItems: 'center', ...style}}>{children}</div>
);

// ===== S11 · Before/after split (land vs swim), then Turkey -> Bosphorus -> Europe flow ===============================
const Panel: React.FC<{at: number; icon: IconName; title: string; sub: string; exitAt: number; dx: number; muted?: boolean}> = ({at, icon, title, sub, exitAt, dx, muted}) => (
  <Enter at={at} dx={dx} dy={30} exitAt={exitAt} style={{flex: 1}}>
    <Glass style={{height: 360, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, opacity: muted ? 0.82 : 1}} pad={24}>
      <Icon name={icon} size={120} color={muted ? C.textDim : C.accent} stroke={2.2} />
      <div style={{fontFamily: FONT_DISPLAY, fontSize: 62, color: C.text, textAlign: 'center', lineHeight: 1}}>{title}</div>
      <div style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 36, color: C.textDim, textAlign: 'center', lineHeight: 1.2}}>{sub}</div>
    </Glass>
  </Enter>
);
export const S11: React.FC = () => {
  const at = useAt();
  const frame = useCurrentFrame();
  const exit = at(wt('Turkey'), 18);
  const flow: [string, number][] = [['Turkey', at(wt('Turkey'))], ['Bosphorus', at(wt('Bosphorus'))], ['Europe', at(wt('across', 90))]];
  return (
    <Scene>
      <Abs top={250}><Words text="2024" at={at(wt('2024,'))} size={150} color={C.hero} exitAt={exit} /></Abs>
      <div style={{position: 'absolute', left: 50, right: 50, top: 450, display: 'flex', gap: 26, alignItems: 'center'}}>
        <Panel at={at(wt('land'))} icon="barrier" title="Land routes" sub="Impossible" exitAt={exit} dx={-60} muted />
        <Panel at={at(wt('swam'), 83)} icon="swim" title="Swim" sub="Caspian Sea to Azerbaijan" exitAt={exit} dx={60} />
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 330, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 20}}>
        {flow.map(([l, t], i) => (
          <React.Fragment key={l}>
            <Enter at={t} dy={30}><Chip text={l} size={42} /></Enter>
            {i < 2 && <Enter at={t + 6} dy={0} dx={-20}><Icon name="arrow" size={46} color={C.accent} stroke={3} /></Enter>}
          </React.Fragment>
        ))}
      </div>
    </Scene>
  );
};

// ===== S12 · Kinetic: the English Channel swim =============================================================================
export const S12: React.FC = () => {
  const at = useAt();
  return (
    <Scene>
      <Abs top={250}><Words text="October 5, 2026" times={[at(wt('October')), at(wt('5th,')), at(wt('2026,', 95))]} size={140} color={C.hero} /></Abs>
      <Abs top={1280}><Words text="English Channel" times={[at(wt('English', 95)), at(wt('Channel'))]} size={150} /></Abs>
      <Abs top={1520}><Enter at={at(wt('from', 95))} dy={40}><Chip icon="swim" text="France to England" size={46} /></Enter></Abs>
    </Scene>
  );
};

// ===== S13 · Bento grid: arrival in Hull ===================================================================================
export const S13: React.FC = () => {
  const at = useAt();
  return (
    <Scene>
      <Abs top={250}><Words text="Karl Bushby arrives in Hull" times={[at(wt('Karl', 105)), at(wt('Karl', 105)) + 3, at(wt('arrived', 105)), at(wt('in', 108)), at(wt('Hull', 105))]} size={92} lh={1.1} style={{padding: '0 60px', width: 1080, boxSizing: 'border-box'}} /></Abs>
      <div style={{position: 'absolute', left: 60, right: 60, top: 1180, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24}}>
        <Enter at={at(wt('November', 100))} dy={50}>
          <Glass style={{height: 190, display: 'flex', alignItems: 'center', gap: 16}} pad={24}>
            <Icon name="calendar" size={60} color={C.accent} stroke={2.4} />
            <div style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 35, color: C.text, lineHeight: 1.15, whiteSpace: 'nowrap'}}>November 2, 2026</div>
          </Glass>
        </Enter>
        <Enter at={at(wt('exactly'))} dy={50}>
          <Glass style={{height: 190, display: 'flex', alignItems: 'center', gap: 16}} pad={24}>
            <Icon name="clock" size={60} color={C.accent} stroke={2.4} />
            <div style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 35, color: C.text, lineHeight: 1.15, whiteSpace: 'nowrap'}}>28 years and 1 day</div>
          </Glass>
        </Enter>
        <Enter at={at(wt('50,000'), 10)} dy={60} s0={0.9} style={{gridColumn: '1 / span 2'}}>
          <Glass tone="hero" style={{height: 270, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 28}} pad={28}>
            <Icon name="ruler" size={110} color={C.accent} stroke={2.2} />
            <Counter to={50000} at={at(wt('50,000'), 8)} dur={30} size={190} />
            <span style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 64, color: C.text}}>km</span>
          </Glass>
        </Enter>
      </div>
    </Scene>
  );
};

// ===== S14 · Waffle chart: 15 of 28 years ===================================================================================
export const S14: React.FC = () => {
  const at = useAt();
  const frame = useCurrentFrame();
  const t15 = at(wt('15'), 2);
  const cell = 108, gap = 16;
  return (
    <Scene>
      <Abs top={250}><Enter at={at(wt('only'))} dy={50}><Counter to={15} at={t15} dur={22} size={360} color={C.text} /></Enter></Abs>
      <Abs top={650}><Words text="of 28 years walking" times={[at(wt('of', 114)), at(wt('28', 114)), at(wt('years', 114)), at(wt('walking', 114))]} size={72} weight={800} font={FONT_BODY} color={C.text} /></Abs>
      <div style={{position: 'absolute', left: (1080 - (7 * cell + 6 * gap)) / 2, top: 860, display: 'grid', gridTemplateColumns: `repeat(7, ${cell}px)`, gap}}>
        {Array.from({length: 28}, (_, i) => {
          const tIn = at(wt('He', 114)) + i * 1.5;
          const lit = interpolate(frame, [t15 + i * 3, t15 + i * 3 + 8], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.out});
          const on = i < 15 ? lit : 0;
          const p = interpolate(frame, [tIn, tIn + 12], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.out});
          return <div key={i} style={{width: cell, height: cell, borderRadius: 24, opacity: p, transform: `scale(${0.7 + 0.3 * p + 0.08 * on * (1 - on)})`, background: on > 0 ? C.hero : C.glass, border: `1.5px solid ${on > 0 ? C.hero : C.glassEdge}`, boxShadow: on > 0.5 ? `0 0 26px ${C.heroSoft}` : 'none'}} />;
        })}
      </div>
      <Abs top={1500}>
        <Enter at={at(wt('actually'))} dy={40}>
          <div style={{display: 'flex', gap: 44, fontFamily: FONT_BODY, fontWeight: 600, fontSize: 38, color: C.textDim, alignItems: 'center'}}>
            <span style={{display: 'flex', alignItems: 'center', gap: 14}}><span style={{width: 30, height: 30, borderRadius: 8, background: C.hero, display: 'inline-block'}} />Walking</span>
            <span style={{display: 'flex', alignItems: 'center', gap: 14}}><span style={{width: 30, height: 30, borderRadius: 8, background: C.glass, border: `1.5px solid ${C.glassEdge}`, display: 'inline-block'}} />Not walking</span>
          </div>
        </Enter>
      </Abs>
    </Scene>
  );
};

// ===== S15 · Recap checklist grid, then bookend close ========================================================================
const Tile: React.FC<{at: number; icon: IconName; label: string; exitAt: number}> = ({at, icon, label, exitAt}) => (
  <Enter at={at} dy={60} s0={0.88} exitAt={exitAt}>
    <Glass style={{width: 470, height: 380, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28}} pad={20}>
      <Icon name={icon} size={150} color={C.accent} stroke={2.1} />
      <div style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 56, color: C.text}}>{label}</div>
    </Glass>
  </Enter>
);
export const S15: React.FC = () => {
  const at = useAt();
  const endT = at(we('time.') + 0.35, 0);
  return (
    <Scene>
      <Abs top={270}><Words text="The rest was a battle against" times={['The', 'rest', 'was', 'a', 'battle', 'against'].map((w, i) => Math.max(at(wt(w, 120)), 2 + i * 3))} size={84} font={FONT_BODY} weight={800} lh={1.12} exitAt={endT - 2} style={{padding: '0 70px'}} /></Abs>
      <div style={{position: 'absolute', left: 60, top: 640, display: 'grid', gridTemplateColumns: '470px 470px', gap: 40}}>
        <Tile at={at(wt('borders,'))} icon="barrier" label="Borders" exitAt={endT - 2} />
        <Tile at={at(wt('bureaucracy,'))} icon="docs" label="Bureaucracy" exitAt={endT - 2} />
        <Tile at={at(wt('money,'))} icon="coin" label="Money" exitAt={endT - 2} />
        <Tile at={at(wt('time.'))} icon="clock" label="Time" exitAt={endT - 2} />
      </div>
      <Abs top={700}><Words text="28 years" at={endT} size={215} color={C.hero} /></Abs>
      <Abs top={990}><Words text="to walk home." at={endT + 12} per={5} size={110} weight={400} font={FONT_BODY} color={C.textDim} /></Abs>
    </Scene>
  );
};
