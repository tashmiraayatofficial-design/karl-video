import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {C, EASE, FONT_BODY, FONT_DISPLAY, FPS, alpha} from '../theme';
import {Chip, Counter, Enter, Glass, Label, Scene, Words, useAt} from '../components/ui';
import {Icon, IconName} from '../components/Icons';
import {SEGS} from '../map/geo';
import {wt} from '../timing';

const Abs: React.FC<{top?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({top, children, style}) => (
  <div style={{position: 'absolute', left: 0, right: 0, top, display: 'flex', flexDirection: 'column', alignItems: 'center', ...style}}>{children}</div>
);

// ===== S06 · Terrain cards -> 18 days in prison (counter) ==========================================================
const Terrain: React.FC<{at: number; icon: IconName; text: string; exitAt: number}> = ({at, icon, text, exitAt}) => (
  <Enter at={at} dy={60} exitAt={exitAt}>
    <Glass style={{width: 300, height: 330, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22}} pad={20}>
      <Icon name={icon} size={112} color={C.accent} stroke={2.2} />
      <div style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 40, color: C.text, textAlign: 'center', lineHeight: 1.12}}>{text}</div>
    </Glass>
  </Enter>
);
export const S06: React.FC = () => {
  const at = useAt();
  const ex = at(wt('imprisoned'), 14);
  return (
    <Scene>
      <div style={{position: 'absolute', top: 1250, left: 60, right: 60, display: 'flex', gap: 30, justifyContent: 'center'}}>
        <Terrain at={at(wt('dense'))} icon="tree" text="Dense forests" exitAt={ex} />
        <Terrain at={at(wt('swamps,'))} icon="waves" text="Swamps" exitAt={ex} />
        <Terrain at={at(wt('dangerous', 36))} icon="swim" text="Dangerous rivers" exitAt={ex} />
      </div>
      <Abs top={1230}>
        <Enter at={at(wt('imprisoned'))} dy={60} s0={0.85} float={4}>
          <Glass tone="hero" style={{width: 900, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 36}} pad={34}>
            <Icon name="bars" size={150} color={C.accent} stroke={2.2} />
            <div style={{display: 'flex', alignItems: 'baseline', gap: 22}}>
              <Counter to={18} at={at(wt('18'), 4)} dur={20} size={230} />
              <span style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 70, color: C.text}}>days</span>
            </div>
          </Glass>
        </Enter>
      </Abs>
      <Abs top={1570}><Enter at={at(wt('imprisoned'), 0) + 10} dy={30}><Label size={42} weight={600}>Imprisoned in Panama</Label></Enter></Abs>
    </Scene>
  );
};

// ===== S07 · Timeline rail: Central America -> Alaska ================================================================
const STOPS: [string, string, number][] = [['Central America', 'Central', 43], ['Mexico', 'Mexico,', 43], ['United States', 'United', 43], ['Canada', 'Canada,', 45], ['Alaska', 'Alaska.', 45]];
export const S07: React.FC = () => {
  const at = useAt();
  const frame = useCurrentFrame();
  const times = STOPS.map(([, w, a]) => at(wt(w, a)));
  const top = 1020, step = 118;
  const lineP = interpolate(frame, [times[0], times[4]], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.inOut});
  return (
    <Scene>
      <div style={{position: 'absolute', left: 130, top: top + 28, width: 6, height: step * 4, borderRadius: 3, background: C.glassEdge}} />
      <div style={{position: 'absolute', left: 130, top: top + 28, width: 6, height: step * 4 * lineP, borderRadius: 3, background: C.hero}} />
      {STOPS.map(([label], i) => {
        const active = frame >= times[i] && (i === 4 || frame < times[i + 1]);
        return (
          <div key={label} style={{position: 'absolute', left: 100, top: top + i * step}}>
            <Enter at={times[i]} dx={-50} dy={20}>
              <div style={{display: 'flex', alignItems: 'center', gap: 34}}>
                <div style={{width: 66, height: 66, borderRadius: 33, background: active ? C.hero : C.glass, border: `3px solid ${active ? C.hero : C.accentLine}`, boxShadow: active ? `0 0 34px ${C.heroGlow}` : 'none', display: 'grid', placeItems: 'center', transform: 'translateX(-1px)'}}>
                  <Icon name={i === 4 ? 'pin' : 'check'} size={34} color={active ? C.bg : C.accent} stroke={3.4} />
                </div>
                <span style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 60, color: active ? C.text : C.textDim}}>{label}</span>
              </div>
            </Enter>
          </div>
        );
      })}
    </Scene>
  );
};

// ===== S08 · Bering Strait: glass cards + drifting sea ice =============================================================
const FLOES = Array.from({length: 18}, (_, i) => {
  const r = (n: number) => { const x = Math.sin(i * 91.7 + n * 12.9) * 43758.5453; return x - Math.floor(x); };
  return {x: 80 + r(1) * 920, y: 560 + r(2) * 620, s: 36 + r(3) * 74, rot: r(4) * 360, ph: r(5) * 6.28, pts: [0, 1, 2, 3, 4, 5].map((k) => 0.62 + 0.38 * r(10 + k))};
});
const IceFloes: React.FC<{at: number; exitAt: number}> = ({at, exitAt}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [at, at + 20, exitAt, exitAt + 10], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.inOut});
  return (
    <svg width={1080} height={1920} style={{position: 'absolute', inset: 0, opacity: o}}>
      {FLOES.map((f, i) => {
        const dx = Math.sin(frame / 52 + f.ph) * 26 + frame * 0.35 * (i % 2 ? 1 : -1), dy = Math.cos(frame / 61 + f.ph) * 14;
        const d = f.pts.map((r, k) => { const a = (k / 6) * Math.PI * 2; return `${(Math.cos(a) * r * f.s).toFixed(1)},${(Math.sin(a) * r * f.s * 0.62).toFixed(1)}`; }).join(' ');
        return <polygon key={i} points={d} transform={`translate(${f.x + dx} ${f.y + dy}) rotate(${f.rot + frame * 0.12})`} fill={alpha(C.text, 0.2)} stroke={alpha(C.text, 0.55)} strokeWidth={2} strokeLinejoin="round" />;
      })}
    </svg>
  );
};
export const S08: React.FC = () => {
  const at = useAt();
  return (
    <Scene>
      <IceFloes at={at(wt('frozen'), 4)} exitAt={9999} />
      <Abs top={270}><Words text="March 2006" times={[at(wt('2006,'), 12), at(wt('2006,'), 8)]} size={128} /></Abs>
      <Abs top={430}><Enter at={at(wt('Dimitri'))} dy={40}><Chip icon="person" text="With Dimitri Kiefer" size={46} /></Enter></Abs>
      <Abs top={1250}>
        <Enter at={at(wt('14'))} dy={60} s0={0.88} float={4}>
          <Glass tone="hero" style={{width: 900, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 30}} pad={30}>
            <Icon name="clock" size={110} color={C.accent} stroke={2.2} />
            <Counter to={14} at={at(wt('14'), 2)} dur={18} size={210} />
            <span style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 66, color: C.text}}>days</span>
          </Glass>
        </Enter>
      </Abs>
      <Abs top={1500}><Enter at={at(wt('shifting'))} dy={40}><Chip icon="snow" text="Shifting sea ice" size={44} /></Enter></Abs>
      <Abs top={1620}><Enter at={at(wt('freezing'))} dy={40}><Chip icon="waves" text="Freezing ocean water" size={44} /></Enter></Abs>
    </Scene>
  );
};

// ===== S09 · Hub and spoke: what stopped him ======================================================================
const NODES: {icon: IconName; label: string; x: number; token: string; after: number}[] = [
  {icon: 'visa', label: 'Visa restrictions', x: 190, token: 'visa', after: 64},
  {icon: 'barrier', label: 'Border problems', x: 540, token: 'border', after: 64},
  {icon: 'coin', label: 'Financial difficulties', x: 890, token: 'financial', after: 64},
];
export const S09: React.FC = () => {
  const at = useAt();
  const frame = useCurrentFrame();
  const hubT = at(wt('repeatedly'));
  const HUB = {x: 540, y: 1130}, NY = 1440;
  return (
    <Scene>
      <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
        {NODES.map((n, i) => {
          const t0 = at(wt(n.token, n.after), 0) + 8;
          const p = interpolate(frame, [Math.max(t0, hubT - 2), Math.max(t0, hubT - 2) + 16], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.out});
          return <path key={i} d={`M${n.x} ${NY - 105} C ${n.x} ${NY - 200} ${HUB.x} ${HUB.y + 220} ${HUB.x} ${HUB.y + 112}`} fill="none" stroke={C.accentLine} strokeWidth={4} strokeDasharray="10 10" pathLength={1} style={{strokeDasharray: `${p} 2`}} strokeLinecap="round" />;
        })}
      </svg>
      <div style={{position: 'absolute', left: HUB.x - 112, top: HUB.y - 112}}>
        <Enter at={hubT} dy={30} s0={0.6}>
          <div style={{width: 224, height: 224, borderRadius: 112, border: `5px solid ${C.hero}`, background: C.heroSoft, boxShadow: `0 0 60px ${C.heroGlow}`, display: 'grid', placeItems: 'center'}}>
            <span style={{fontFamily: FONT_DISPLAY, fontSize: 60, color: C.text}}>Stopped</span>
          </div>
        </Enter>
      </div>
      {NODES.map((n, i) => (
        <div key={i} style={{position: 'absolute', left: n.x - 160, top: NY - 105, width: 320, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <Enter at={at(wt(n.token, n.after))} dy={50} float={3}>
            <Glass pad={0} style={{width: 210, height: 210, borderRadius: 105, display: 'grid', placeItems: 'center'}}><Icon name={n.icon} size={104} color={C.accent} stroke={2.2} /></Glass>
          </Enter>
          <Enter at={at(wt(n.token, n.after)) + 6} dy={20} style={{marginTop: 22}}><Label size={36} weight={800} color={C.text}>{n.label}</Label></Enter>
        </div>
      ))}
    </Scene>
  );
};

// ===== S10 · Data dashboard: 5,600 km Los Angeles -> Washington, D.C. ==============================================
export const S10: React.FC = () => {
  const at = useAt();
  const frame = useCurrentFrame();
  const F = SEGS.find((s) => s.id === 'F')!;
  const rp = interpolate(frame, [at(F.from, 0), at(F.to, 0)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.inOut});
  return (
    <Scene>
      <Abs top={1180}>
        <Enter at={at(wt('walked'))} dy={70} s0={0.9} float={3}>
          <Glass style={{width: 940}} pad={44}>
            <div style={{display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 22}}>
              <Counter to={5600} at={at(wt('5,600'), 4)} dur={32} size={215} />
              <span style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 80, color: C.text}}>km</span>
            </div>
            <div style={{position: 'relative', height: 10, borderRadius: 5, background: C.glassEdge, margin: '34px 20px 0'}}>
              <div style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: `${rp * 100}%`, borderRadius: 5, background: C.hero}} />
              <div style={{position: 'absolute', left: `${rp * 100}%`, top: -9, width: 28, height: 28, borderRadius: 14, background: C.text, transform: 'translateX(-14px)', boxShadow: `0 0 24px ${C.heroGlow}`}} />
            </div>
            <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 28, fontFamily: FONT_BODY, fontWeight: 800, fontSize: 36, color: C.textDim}}>
              <span>Los Angeles</span><span>Washington, D.C.</span>
            </div>
          </Glass>
        </Enter>
      </Abs>
    </Scene>
  );
};
