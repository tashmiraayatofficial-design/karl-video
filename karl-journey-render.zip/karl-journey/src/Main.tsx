import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Audio, Sequence, delayRender, continueRender, getRemotionEnvironment, staticFile} from 'remotion';
import {Backdrop, Finish} from './components/Backdrop';
import {MapLayer} from './map/MapLayer';
import {SceneCtx} from './components/ui';
import {loadFonts} from './fonts';
import {B} from './timeline';
import {C, FPS} from './theme';
import {SFX_EVENTS} from './sfx';
import {S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15} from './scenes';

loadFonts();

// ---- Voiceover preview: one flag. Default: on in Studio, off when rendering. -----------------------------
export const VOICEOVER_IN_RENDER = false;
const PreviewAudio: React.FC = () => {
  const rendering = getRemotionEnvironment().isRendering;
  const enabled = rendering ? VOICEOVER_IN_RENDER : true;
  const [exists, setExists] = useState(false);
  useEffect(() => {
    const h = delayRender('voiceover-check');
    fetch(staticFile('voiceover.mp3'), {method: 'HEAD'}).then((r) => setExists(r.ok)).catch(() => setExists(false)).finally(() => continueRender(h));
  }, []);
  if (!enabled || !exists) return null; // if public/voiceover.mp3 is missing, omit silently
  return <Audio src={staticFile('voiceover.mp3')} />;
};

const SCENES = [S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15];

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: C.bgDeep}}>
    <Backdrop />
    <MapLayer />
    {SCENES.map((Comp, i) => {
      const from = Math.round(B[i] * FPS);
      const frames = Math.round(B[i + 1] * FPS) - from;
      return (
        <Sequence key={i} from={from} durationInFrames={frames} name={`S${String(i + 1).padStart(2, '0')}`}>
          <SceneCtx.Provider value={{start: B[i], end: B[i + 1], frames}}>
            <Comp />
          </SceneCtx.Provider>
        </Sequence>
      );
    })}
    <Finish />
    {SFX_EVENTS.map((e, i) => (
      <Sequence key={i} from={Math.max(0, Math.round(e.t * FPS))} durationInFrames={Math.round(0.8 * FPS)}>
        <Audio src={staticFile(`sfx/${e.type}.wav`)} volume={e.vol} />
      </Sequence>
    ))}
    <PreviewAudio />
  </AbsoluteFill>
);
