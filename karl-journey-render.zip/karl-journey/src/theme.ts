import {Easing} from 'remotion';

// ---- Canvas -------------------------------------------------------------
export const W = 1080;
export const H = 1920;
export const FPS = 30;
export const SAFE_TOP = 240; // keep key content inside the middle ~75% of the frame
export const SAFE_BOTTOM = 1680;

// ---- Colour scheme: "Expedition Night" (user choice 1) -------------------
const BG = '#0B1220';
const HERO = '#F5A524';
const ACCENT = '#3FA9F5';
const TEXT = '#F4F1EA';
const PANEL = '#14213A';

const rgba = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
export const alpha = rgba;

export const C = {
  bg: BG,
  bgDeep: '#070C16',
  mesh1: '#1B3A6B',
  mesh2: '#10294D',
  black: '#000000',
  panel: PANEL,
  land: '#213866',
  hero: HERO,
  heroGlow: rgba(HERO, 0.45),
  heroSoft: rgba(HERO, 0.16),
  accent: ACCENT,
  accentSoft: rgba(ACCENT, 0.18),
  accentLine: rgba(ACCENT, 0.4),
  text: TEXT,
  textDim: rgba(TEXT, 0.66),
  textFaint: rgba(TEXT, 0.34),
  glass: rgba('#1B2C4D', 0.62),
  glassEdge: rgba(TEXT, 0.14),
  shade: rgba(BG, 0.78),
};

// ---- Fonts (all loaded from public/fonts, work offline) ------------------
export const FONT_DISPLAY = `'Hello Botuna', 'Inter', Helvetica, Arial, sans-serif`;
export const FONT_BODY = `'Inter', Helvetica, Arial, sans-serif`;

// ---- Motion presets -----------------------------------------------------
export const EASE = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  cam: Easing.bezier(0.45, 0, 0.2, 1),
  exit: Easing.bezier(0.5, 0, 0.75, 0),
};
export const SPRING = {
  soft: {damping: 200, stiffness: 90, mass: 1},
  pop: {damping: 13, stiffness: 190, mass: 0.7},
  snap: {damping: 22, stiffness: 220, mass: 0.8},
};
export const EXIT_FRAMES = 8; // exits are faster than entrances

export const RADIUS = 34; // one corner-radius language across the whole video
export const SHADOW = `0 24px 60px ${rgba('#000000', 0.45)}`;
