import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {FPS, H, W} from './theme';
import {TOTAL_SEC} from './timeline';

export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={Math.ceil(TOTAL_SEC * FPS)} fps={FPS} width={W} height={H} />
);
