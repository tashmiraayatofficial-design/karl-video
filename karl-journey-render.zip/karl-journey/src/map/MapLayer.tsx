import React from 'react';
import {interpolate, spring, useCurrentFrame} from 'remotion';
import {C, EASE, FONT_BODY, FPS, H, SPRING, W, alpha} from '../theme';
import {DARIEN, DIM, GRAT_D, KEYS, LAND_D, P, PINS, SEGS, Seg} from './geo';
import {B} from '../timeline';
import {wt} from '../timing';

const AX = W / 2; // screen anchor of the camera centre
const AY = 860;
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

// ---- camera ------------------------------------------------------------------
const KP = KEYS.map((q) => ({...q, p: P(q.lon, q.lat)}));
export const cameraAt = (t: number) => {
  if (t <= KP[0].t) return {x: KP[0].p[0], y: KP[0].p[1], z: KP[0].z};
  for (let i = 0; i < KP.length - 1; i++) {
    const a = KP[i], b = KP[i + 1];
    if (t >= a.t && t < b.t) {
      const e = EASE.cam(clamp01((t - a.t) / (b.t - a.t)));
      const dist = Math.hypot(b.p[0] - a.p[0], b.p[1] - a.p[1]) * Math.min(a.z, b.z) / W;
      const dip = Math.min(1.1, 0.32 * Math.log(1 + dist * 1.6)); // gentle zoom-out on long moves
      const lz = lerp(Math.log(a.z), Math.log(b.z), e) - dip * Math.sin(Math.PI * e);
      return {x: lerp(a.p[0], b.p[0], e), y: lerp(a.p[1], b.p[1], e), z: Math.exp(lz)};
    }
  }
  const l = KP[KP.length - 1];
  return {x: l.p[0], y: l.p[1], z: l.z};
};
const dimAt = (t: number) => {
  for (let i = 0; i < DIM.length - 1; i++) if (t >= DIM[i].t && t < DIM[i + 1].t) return lerp(DIM[i].v, DIM[i + 1].v, EASE.inOut(clamp01((t - DIM[i].t) / (DIM[i + 1].t - DIM[i].t))));
  return DIM[DIM.length - 1].v;
};

// ---- routes (smoothed polylines, drawn progressively) ----------------------------
const chaikin = (pts: [number, number][], n = 2) => {
  let p = pts;
  for (let k = 0; k < n; k++) {
    const out: [number, number][] = [p[0]];
    for (let i = 0; i < p.length - 1; i++) {
      const [a, b] = [p[i], p[i + 1]];
      out.push([0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]], [0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]]);
    }
    out.push(p[p.length - 1]);
    p = out;
  }
  return p;
};
const PREP = SEGS.map((s) => {
  const pts = chaikin(s.pts.map(([lo, la]) => P(lo, la)));
  const cum = [0];
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  return {seg: s, pts, cum, len: cum[cum.length - 1]};
});
const partial = (r: (typeof PREP)[number], p: number) => {
  const target = p * r.len;
  const out: [number, number][] = [r.pts[0]];
  let head = r.pts[0];
  for (let i = 1; i < r.pts.length; i++) {
    if (r.cum[i] <= target) { out.push(r.pts[i]); head = r.pts[i]; }
    else {
      const f = (target - r.cum[i - 1]) / (r.cum[i] - r.cum[i - 1] || 1);
      head = [lerp(r.pts[i - 1][0], r.pts[i][0], f), lerp(r.pts[i - 1][1], r.pts[i][1], f)];
      out.push(head);
      break;
    }
  }
  return {d: 'M' + out.map((q) => q[0].toFixed(1) + ' ' + q[1].toFixed(1)).join('L'), head};
};
const routeProgress = (s: Seg, t: number) => interpolate(t, [s.from, s.to], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.inOut});

// S3 "overview arc": the whole journey in one gesture, Punta Arenas -> Hull (bends over the north, like the real route)
const A0 = P(-70.9, -53.2), A1 = P(-0.34, 53.74);
const ARC_D = `M${A0[0]} ${A0[1]} Q ${(A0[0] + A1[0]) / 2} ${Math.min(A0[1], A1[1]) - 900} ${A1[0]} ${A1[1]}`;

export const MapLayer: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const cam = cameraAt(t);
  const dim = dimAt(t);
  const {x, y, z} = cam;
  const toScreen = (lon: number, lat: number): [number, number] => {
    const p = P(lon, lat);
    return [AX + (p[0] - x) * z, AY + (p[1] - y) * z];
  };
  const pulse = (frame % 45) / 45;
  const arcFrom = wt('destination'), arcTo = wt('Hull', 9) + 0.3;
  const arcP = interpolate(t, [arcFrom, arcTo], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.inOut});
  const arcOpacity = interpolate(t, [B[4] - 0.4, B[4] + 0.6], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const gratOpacity = interpolate(z, [0.6, 1.2, 3], [0, 0.07, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  return (
    <div style={{position: 'absolute', inset: 0, opacity: dim}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <g transform={`translate(${AX - x * z} ${AY - y * z}) scale(${z})`}>
          <path d={GRAT_D} fill="none" stroke={C.accent} strokeWidth={1 / z} opacity={gratOpacity} />
          <path d={LAND_D} fill={C.land} />
          <path d={LAND_D} fill="none" stroke={C.accent} strokeOpacity={0.8} strokeWidth={1.6 / z} strokeLinejoin="round" />
          {PREP.map((r) => {
            const p = routeProgress(r.seg, t);
            if (p <= 0) return null;
            const {d, head} = partial(r, p);
            const st = r.seg.style;
            const w = (st === 'walk' ? 6 : 5) / z;
            const col = st === 'walk' ? C.hero : st === 'swim' ? C.accent : C.text;
            return (
              <g key={r.seg.id}>
                {st === 'walk' && <path d={d} fill="none" stroke={C.heroGlow} strokeWidth={w * 3} strokeLinecap="round" strokeLinejoin="round" opacity={0.55} />}
                <path d={d} fill="none" stroke={col} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={st === 'walk' ? undefined : `${16 / z} ${12 / z}`} />
                {p < 1 && (
                  <>
                    <circle cx={head[0]} cy={head[1]} r={(11 + 16 * pulse) / z} fill="none" stroke={col} strokeOpacity={1 - pulse} strokeWidth={2.5 / z} />
                    <circle cx={head[0]} cy={head[1]} r={10 / z} fill={col} />
                  </>
                )}
              </g>
            );
          })}
        </g>
      </svg>
      {/* arc is drawn via its own overlay so it can use a true dash reveal */}
      <ArcReveal x={x} y={y} z={z} progress={arcP} opacity={arcOpacity} />
      {/* Darien danger zone */}
      <DangerZone toScreen={toScreen} t={t} frame={frame} z={z} />
      {/* pins */}
      {PINS.map((p, i) => {
        const [sx, sy] = toScreen(p.lon, p.lat);
        if (sx < -300 || sx > W + 300 || sy < -200 || sy > H + 200) return null;
        const f0 = p.from * FPS, f1 = p.to * FPS;
        if (frame < f0 || frame > f1 + 10) return null;
        const inn = spring({frame: frame - f0, fps: FPS, config: SPRING.pop});
        const out = interpolate(frame, [f1, f1 + 8], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.exit});
        const col = p.tone === 'hero' ? C.hero : C.text;
        const side = p.side ?? 'r';
        const chip: React.CSSProperties = {
          position: 'absolute', whiteSpace: 'nowrap', padding: '12px 24px', borderRadius: 999, background: C.glass, border: `1.5px solid ${C.glassEdge}`,
          fontFamily: FONT_BODY, color: C.text, lineHeight: 1.1, transformOrigin: side === 'l' ? 'right center' : side === 'r' ? 'left center' : 'center bottom',
          ...(side === 'r' ? {left: 30, top: -30} : side === 'l' ? {right: 30, top: -30} : {left: 0, top: -92, transform: `translateX(-50%) scale(${0.8 + 0.2 * inn})`}),
        };
        if (side !== 'u') chip.transform = `scale(${0.8 + 0.2 * inn})`;
        return (
          <div key={i} style={{position: 'absolute', left: sx, top: sy, opacity: Math.min(1, inn) * out}}>
            <div style={{position: 'absolute', left: -11, top: -11, width: 22, height: 22, borderRadius: 11, background: col, boxShadow: `0 0 0 6px ${alpha(C.black, 0.25)}, 0 0 28px ${p.tone === 'hero' ? C.heroGlow : C.accentLine}`}} />
            {p.text !== '' && <div style={chip}>
              <div style={{fontWeight: 800, fontSize: 34, letterSpacing: 0.2}}>{p.text}</div>
              {p.sub && <div style={{fontWeight: 600, fontSize: 24, color: C.textDim, marginTop: 4}}>{p.sub}</div>}
            </div>}
          </div>
        );
      })}
    </div>
  );
};

// Dash-reveal for the arc in screen space (dash size stays constant on screen); a mask reveals it progressively
const ArcReveal: React.FC<{x: number; y: number; z: number; progress: number; opacity: number}> = ({x, y, z, progress, opacity}) => {
  if (progress <= 0 || opacity <= 0) return null;
  const sx = (p: [number, number]) => `${AX + (p[0] - x) * z} ${AY + (p[1] - y) * z}`;
  const ctrl: [number, number] = [(A0[0] + A1[0]) / 2, Math.min(A0[1], A1[1]) - 900];
  const d = `M${sx(A0)} Q ${sx(ctrl)} ${sx(A1)}`;
  return (
    <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity}}>
      <mask id="arcmask" maskUnits="userSpaceOnUse" x={-W} y={-H} width={W * 3} height={H * 3}>
        <path d={d} fill="none" stroke="white" strokeWidth={30} pathLength={1} strokeDasharray={`${progress} 2`} />
      </mask>
      <path d={d} fill="none" stroke={C.accent} strokeWidth={5} strokeLinecap="round" strokeDasharray="16 14" mask="url(#arcmask)" />
    </svg>
  );
};

const DangerZone: React.FC<{toScreen: (a: number, b: number) => [number, number]; t: number; frame: number; z: number}> = ({toScreen, t, frame}) => {
  if (t < DARIEN.from - 0.1 || t > DARIEN.to + 0.4) return null;
  const [sx, sy] = toScreen(DARIEN.lon, DARIEN.lat);
  const inn = spring({frame: frame - DARIEN.from * FPS, fps: FPS, config: SPRING.pop});
  const out = interpolate(t, [DARIEN.to, DARIEN.to + 0.3], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const ph = (frame % 40) / 40;
  return (
    <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity: inn * out}}>
      <circle cx={sx} cy={sy} r={150 * inn} fill={C.heroSoft} stroke={C.hero} strokeWidth={3} strokeDasharray="10 10" />
      <circle cx={sx} cy={sy} r={150 + 70 * ph} fill="none" stroke={C.hero} strokeWidth={2.5} opacity={1 - ph} />
    </svg>
  );
};
