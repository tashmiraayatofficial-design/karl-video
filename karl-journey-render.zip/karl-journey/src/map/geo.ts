import {geoMercator, geoPath, geoGraticule10} from 'd3-geo';
import {feature} from 'topojson-client';
import land from '../data/land-50m.json';
import {wt, we} from '../timing';
import {B} from '../timeline';

// Flat Mercator map, cut in the Atlantic so the whole route (Chile -> Alaska -> Russia -> Hull) is one continuous strip.
export const projection = geoMercator().rotate([-150, 0]).scale(573).translate([0, 0]).precision(0.2);
export const P = (lon: number, lat: number): [number, number] => projection([lon, lat]) as [number, number];
const pathGen = geoPath(projection).digits(1);
export const LAND_D = pathGen(feature(land as any, (land as any).objects.land) as any) as string;
export const GRAT_D = pathGen(geoGraticule10() as any) as string;

// ---------------------------------------------------------------- routes (illustrative, approximate)
export type SegStyle = 'walk' | 'swim' | 'ice';
export type Seg = {id: string; style: SegStyle; pts: [number, number][]; from: number; to: number};
export const SEGS: Seg[] = [
  {id: 'A', style: 'walk', from: B[4] + 0.2, to: wt('Colombia', 25),
    pts: [[-70.9, -53.2], [-71.3, -41], [-70.65, -33.4], [-70.3, -23], [-71.5, -16], [-77, -12], [-79.5, -4], [-78.5, -0.2], [-74.1, 4.7]]},
  {id: 'B', style: 'walk', from: wt('In', 27.9), to: wt('Panama', 38),
    pts: [[-74.1, 4.7], [-75.8, 7], [-77.2, 8.1], [-77.9, 8.5], [-79.5, 9.0]]},
  {id: 'C', style: 'walk', from: wt('continued', 43), to: we('Alaska', 45),
    pts: [[-79.5, 9], [-84.1, 9.9], [-90.5, 14.6], [-99.1, 19.4], [-106.5, 28], [-117.1, 32.7], [-122.3, 47.6], [-130, 55], [-135, 59.5], [-149.9, 61.2], [-160, 63], [-165.4, 64.5], [-168.1, 65.6]]},
  {id: 'D', style: 'ice', from: wt('crossed', 52), to: wt('Russia', 52),
    pts: [[-168.1, 65.6], [-169, 65.9], [-169.8, 66.2]]},
  {id: 'E', style: 'walk', from: wt('Russia', 62), to: we('China', 62),
    pts: [[-169.8, 66.2], [177.5, 64.7], [160, 61], [150.8, 59.6], [129.7, 62], [104.3, 52.3], [106.9, 47.9], [112, 42], [116.4, 39.9]]},
  {id: 'F', style: 'walk', from: wt('walked', 70), to: we('D.C.', 70),
    pts: [[-118.2, 34.05], [-112, 36.5], [-104.8, 39.7], [-97, 38.5], [-90.2, 38.6], [-84, 39.5], [-77, 38.9]]},
  {id: 'G', style: 'swim', from: wt('swam', 83), to: we('Azerbaijan', 83),
    pts: [[51.2, 43.6], [50.5, 42], [49.87, 40.4]]},
  {id: 'H', style: 'walk', from: wt('continued', 88), to: we('Europe', 90),
    pts: [[49.87, 40.4], [44.8, 41.7], [41, 41], [35, 40.5], [29, 41], [23.3, 42.7], [20.5, 44.8], [16.4, 48.2], [11.6, 48.1], [2.35, 48.86], [1.9, 50.9]]},
  {id: 'I', style: 'swim', from: wt('swam', 95), to: we('England', 95),
    pts: [[1.7, 50.95], [1.5, 51.03], [1.31, 51.12]]},
  {id: 'J', style: 'walk', from: wt('Karl', 105) - 0.3, to: wt('Hull', 105) + 0.3,
    pts: [[1.31, 51.12], [1.08, 51.28], [0.3, 51.4], [-0.12, 51.5], [-0.1, 51.9], [0.12, 52.2], [-0.24, 52.57], [-0.54, 52.95], [-0.8, 53.2], [-1.13, 53.52], [-0.87, 53.7], [-0.34, 53.74]]},
];

// ---------------------------------------------------------------- pins & zones (screen-sized labels)
export type Pin = {text: string; sub?: string; lon: number; lat: number; from: number; to: number; side?: 'r' | 'l' | 'u'; tone?: 'hero' | 'accent'};
const pin = (text: string, lon: number, lat: number, from: number, to: number, side: Pin['side'] = 'r', tone: Pin['tone'] = 'accent', sub?: string): Pin => ({text, sub, lon, lat, from, to, side, tone});
export const PINS: Pin[] = [
  pin('Punta Arenas', -70.9, -53.2, wt('Punta') - 0.2, B[4] - 0.4, 'u', 'hero', 'Chile'),
  pin('Hull', -0.34, 53.74, wt('Hull', 9) - 0.2, B[4] - 0.4, 'u', 'hero', 'England'),
  pin('Colombia', -74.1, 4.7, wt('Colombia', 25) - 0.1, B[5] - 7, 'r'),
  pin('Panama', -79.5, 9.0, wt('Panama', 38) - 0.1, B[6] + 1.5, 'l'),
  pin('Alaska', -149.9, 61.2, wt('Alaska', 45) - 0.2, B[7] + 0.5, 'l'),
  pin('Bering Strait', -169, 65.8, wt('Bering') - 0.3, B[8] - 0.3, 'u'),
  pin('Russia', 125, 62, wt('Russia', 64) - 0.1, B[9] - 0.2, 'u'),
  pin('Mongolia', 103.8, 46.9, wt('Mongolia') - 0.1, B[9] - 0.2, 'l'),
  pin('China', 103, 35, wt('China', 62) - 0.1, B[9] - 0.2, 'l'),
  pin('Los Angeles', -118.2, 34.05, wt('Los') - 0.2, B[10] - 0.4, 'u'),
  pin('Washington, D.C.', -77, 38.9, wt('Washington') - 0.1, B[10] - 0.4, 'u'),
  pin('Caspian Sea', 51.3, 42.0, wt('Caspian') - 0.2, wt('Turkey') - 0.3, 'r'),
  pin('Azerbaijan', 49.87, 40.4, wt('Azerbaijan') - 0.4, wt('Turkey') - 0.3, 'l'),
  pin('', 35, 39.8, wt('Turkey') - 0.1, wt('Bosphorus') + 0.3, 'u'),
  pin('', 29, 41.1, wt('Bosphorus') - 0.1, wt('across', 90) - 0.2, 'u'),
  pin('', 14, 47.2, wt('across', 90), B[11] - 0.1, 'u'),
  pin('France', 2.1, 50.6, B[11] + 0.6, B[12] - 0.3, 'r'),
  pin('England', 0.85, 51.25, B[11] + 0.9, B[12] - 0.3, 'l'),
  pin('Hull', -0.34, 53.74, wt('Hull', 105) - 0.2, B[13] + 2.5, 'r', 'hero', 'His mother’s home'),
];
export const DARIEN = {lon: -77.5, lat: 8.25, from: wt('Darien') - 0.3, to: B[6] - 0.2};

// ---------------------------------------------------------------- camera (lon/lat of centre + zoom)
export type Key = {t: number; lon: number; lat: number; z: number};
const k = (t: number, lon: number, lat: number, z: number): Key => ({t, lon, lat, z});
export const KEYS: Key[] = [
  k(0, -70, -22, 0.55), k(B[1], -72, -42, 0.7), k(B[2], -71, -50, 0.9),
  k(B[2] + 0.5, -70.9, -53.2, 5.5), k(wt('Hull', 9) - 2.2, -70.9, -53.2, 5.5),
  k(B[3] - 1.6, 144, 14, 0.29), k(B[4] - 1.2, 144, 14, 0.29),
  k(B[4] + 1.0, -69, -26, 1.35), k(wt('Colombia', 25) + 0.4, -77, -4, 1.5),
  k(wt('Darien') + 0.8, -77.3, 7.6, 9), k(B[6] - 1.5, -78.3, 8.6, 9),
  k(B[6] + 0.2, -82, 12, 2.6), k(wt('Central', 43) + 0.4, -90, 16, 2.2), k(wt('Mexico', 43) + 0.4, -100, 27, 1.5),
  k(wt('Canada', 45) + 0.2, -126, 46, 1.1), k(wt('Alaska', 45), -146, 58, 1.2), k(B[7], -158, 62, 1.8),
  k(B[7] + 2.2, -168.9, 65.8, 16), k(B[8] - 0.5, -170.4, 66.0, 14),
  k(wt('Russia', 64) - 0.5, 175, 64, 2.6), k(wt('Mongolia') - 0.6, 130, 56, 1.5), k(B[9] - 0.8, 112, 46, 2.0),
  k(wt('Los') - 1.0, -97.5, 36.5, 2.4), k(B[10] - 0.3, -97.5, 36.5, 2.4),
  k(B[10] + 2.0, 50.3, 42.0, 8), k(wt('Azerbaijan') + 0.4, 47.5, 41.5, 6), k(wt('Turkey') - 0.4, 38, 40.2, 4.4),
  k(wt('Bosphorus') + 0.2, 29, 41.0, 9), k(wt('across', 90), 18, 46, 3.0), k(B[11] - 0.4, 3, 49.5, 5),
  k(B[11] + 0.9, 1.5, 51.0, 36), k(B[12] - 0.3, 1.5, 51.0, 36),
  k(B[12] + 1.2, 0.2, 52.4, 14), k(wt('Hull', 105) - 1.0, -0.34, 53.3, 15), k(B[14] - 1.2, -0.34, 53.3, 15),
  k(B[15], 144, 14, 0.29),
];
// How visible the map is behind each scene (calm scenes dim it so foreground reads clearly).
export const DIM: {t: number; v: number}[] = [
  {t: 0, v: 0.55}, {t: B[1], v: 0.5}, {t: B[1] + 0.5, v: 0.28}, {t: B[2] - 0.2, v: 0.28}, {t: B[2] + 0.4, v: 1},
  {t: B[3] - 0.2, v: 1}, {t: B[3] + 0.4, v: 0.34}, {t: B[4] - 0.6, v: 0.34}, {t: B[4] + 0.4, v: 1},
  {t: B[13] - 0.2, v: 1}, {t: B[13] + 0.6, v: 0.22}, {t: B[15], v: 0.22},
];
