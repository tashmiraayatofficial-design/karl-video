// Usage: node scripts/stills.mjs 3.0 8.5 ...   (seconds) -> out/stills/t_<sec>.jpg
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path';
import fs from 'fs';
const browserExecutable = process.env.BROWSER || '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const secs = process.argv.slice(2).map(Number);
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const comp = await selectComposition({serveUrl, id: 'Main', browserExecutable});
fs.mkdirSync('out/stills', {recursive: true});
for (const s of secs) {
  const frame = Math.min(comp.durationInFrames - 1, Math.round(s * comp.fps));
  await renderStill({composition: comp, serveUrl, frame, output: `out/stills/t_${s.toFixed(1)}.jpg`, imageFormat: 'jpeg', jpegQuality: 92, browserExecutable});
  console.log('ok', s);
}
