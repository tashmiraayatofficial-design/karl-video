// Parses public/script.srt into per-word timings (words split evenly inside each cue; approximate).
import fs from 'fs';
const toSec = (t) => { const [h, m, rest] = t.split(':'); const [s, ms] = rest.split(','); return +h * 3600 + +m * 60 + +s + +ms / 1000; };
const raw = fs.readFileSync('public/script.srt', 'utf8').replace(/\r/g, '').trim().split(/\n\n+/);
const words = []; const cues = [];
for (const block of raw) {
  const lines = block.split('\n'); const [a, b] = lines[1].split(' --> ');
  const start = toSec(a), end = toSec(b);
  const text = lines.slice(2).join(' ').trim();
  cues.push({ start, end, text });
  const ws = text.split(/\s+/).filter((w) => w && !/^\[.*\]$/.test(w));
  ws.forEach((w, i) => words.push({ w, start: +(start + ((end - start) * i) / ws.length).toFixed(3), end: +(start + ((end - start) * (i + 1)) / ws.length).toFixed(3) }));
}
fs.writeFileSync('src/data/words.json', JSON.stringify({ cues, words }, null, 1));
console.log(cues.length, 'cues', words.length, 'words', 'end', cues.at(-1).end);
